from gurobipy import *
import numpy as np
import time

# --------参数---------------------------------------------------------------------------------------------------------
Bays = 6
Rows = 10
jobs = 5

SerSlots = [
    [1, 0],
    [2, 5],
    [5, 7],
    [4, 8],
    [3, 2],
    [5, 2],
    [6, 0]]
TR = [0, 10, 17, 11, 8, 15, 0]
J = list(range(0, jobs + 2))
S = [2, 4, 5]
U = [1, 3]

P = list(range(0, 2 * Bays))
Pzuobiao = np.zeros((2 * Bays, 2))
Pzuobiao[0:Bays, 0] = range(0, Bays)
Pzuobiao[Bays:2 * Bays, 0] = range(0, Bays)
Pzuobiao[Bays:2 * Bays, 1] = Rows + 1

Tx = Ty = 1
TH_1 = TH_2 = 5
Es = 1
El = 1.5
Eu = 0.5

JPT = np.zeros((len(J), len(P)))
for j in range(0, len(J)):
    for p in range(0, len(P)):
        JPT[j, p] = max(abs(Pzuobiao[p][0] - SerSlots[j][0]), abs(Pzuobiao[p][1] - SerSlots[j][1]))

JJT = np.zeros((len(J), len(J)))
for a in J:
    for b in J:
        if a != b:
            JJT[a, b] = max(abs(SerSlots[a][0] - SerSlots[b][0]), abs(SerSlots[a][1] - SerSlots[b][1]))

PPT = np.zeros((len(P), len(P)))
for a in P:
    for b in P:
        if a != b:
            PPT[a, b] = max(abs(Pzuobiao[a][0] - Pzuobiao[b][0]), abs(Pzuobiao[a][1] - Pzuobiao[b][1]))

# ==============================================================================
# AUGMECON 模型构建 (只建一次模)
# ==============================================================================
MaxRunTime = 900
model = Model('YCs')
model.setParam('OutputFlag', False)  # 循环调用时不打印过量求解日志，以提高效率
model.setParam('TimeLimit', MaxRunTime)
model.setParam(GRB.Param.MIPFocus, 1)

# ------决策变量定义------
x = {}
s = {}
tj_1 = {}
tj_2 = {}

for j in J:
    for p in P:
        x[j, p] = model.addVar(vtype=GRB.BINARY, name='X[%s %s]' % (j, p))

for j_1 in J:
    for j_2 in J:
        s[j_1, j_2] = model.addVar(vtype=GRB.BINARY, name='s[%s %s]' % (j_1, j_2))

for j in J[1:-1]:
    tj_1[j] = model.addVar(lb=0, vtype=GRB.INTEGER, name=f's_{j}')
    tj_2[j] = model.addVar(lb=0, vtype=GRB.INTEGER, name=f's_{j}')

te = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name='te')

delta = {}
lamb = {}
erfa = {}
bata = {}
w = {}
w_jdz = {}
w_pos = {}
w_neg = {}
y_1 = {}

for j_1 in J:
    for j_2 in J:
        if j_1 != j_2:
            delta[j_1, j_2] = model.addVar(lb=0, ub=1, vtype=GRB.BINARY, name=f'delta_{j_1}_{j_2}')
            erfa[j_1, j_2] = model.addVar(lb=0, vtype=GRB.INTEGER, name=f'erfa_{j_1}_{j_2}')

for j in J:
    bata[j] = model.addVar(lb=0, vtype=GRB.INTEGER, name=f'bata_{j}')

for j in J:
    for p in P:
        y_1[j, p] = model.addVar(vtype=GRB.BINARY, name='y_1[%s %s]' % (j, p))
        w_jdz[j, p] = model.addVar(lb=0, ub=GRB.INFINITY, vtype=GRB.CONTINUOUS, name='w_jdz[%s %s]' % (j, p))
        w_pos[j, p] = model.addVar(lb=0, ub=GRB.INFINITY, vtype=GRB.CONTINUOUS, name=f'w_pos{j, p}')
        w_neg[j, p] = model.addVar(lb=0, ub=GRB.INFINITY, vtype=GRB.CONTINUOUS, name=f'w_neg{j, p}')
        lamb[j, p] = model.addVar(lb=0, ub=1, vtype=GRB.BINARY, name=f'lamb_{j, p}')

u_jdz = {}
y_2 = {}
u_pos = {}
u_neg = {}
for j_1 in J:
    for j_2 in J:
        for p in P:
            y_2[j_1, j_2, p] = model.addVar(vtype=GRB.BINARY, name='y_2[%s %s %s]' % (j_1, j_2, p))
            u_jdz[j_1, j_2, p] = model.addVar(lb=0, ub=GRB.INFINITY, vtype=GRB.CONTINUOUS,
                                              name='u_jdz[%s %s %s]' % (j_1, j_2, p))
            u_pos[j_1, j_2, p] = model.addVar(lb=0, ub=GRB.INFINITY, vtype=GRB.CONTINUOUS, name=f'u_pos{j_1, j_2, p}')
            u_neg[j_1, j_2, p] = model.addVar(lb=0, ub=GRB.INFINITY, vtype=GRB.CONTINUOUS, name=f'u_neg{j_1, j_2, p}')
            delta[j_1, j_2, p] = model.addVar(lb=0, ub=1, vtype=GRB.BINARY, name=f'delta_{j_1, j_2, p}')

model.update()

# --- 约束条件 ---
M = 600
model.addConstr(quicksum(s[0, j] for j in J[1:-1]) == 1, name='c2')
model.addConstr(quicksum(s[j, J[-1]] for j in J[1:-1]) == 1, name='c3_end')

for j1 in J[1:-1]:
    model.addConstr(quicksum(s[j1, j2] for j2 in J[1:] if j1 != j2) == 1, name='c3_1')
for j2 in J[1:-1]:
    model.addConstr(quicksum(s[j1, j2] for j1 in J[:-1] if j1 != j2) == 1, name='c4')

for j_1 in J[1:-1]:
    for j_2 in J[1:-1]:
        if j_1 != j_2:
            model.addConstr(s[j_1, j_2] + s[j_2, j_1] <= 1, name='c5')
for j in J:
    model.addConstr(s[j, j] == 0, name='c6')

for j in J[1:-1]:
    model.addConstr(quicksum(x[j, p] for p in P) == 1, name='c7')
model.addConstr(quicksum(x[j, p] for j in J[1:-1] for p in P) == jobs)

for p in P:
    model.addConstr(quicksum(x[j, p] for j in J[1:-1]) <= 1, name='c8')

for j in J[1:-1]:
    for p in P:
        model.addConstr(tj_1[j] + TH_1 + JPT[j, p] + TH_2 <= tj_2[j] + M * (1 - x[j, p]), name='c9')

for j in S:
    model.addConstr(tj_1[j] >= TR[j], name='c10')
for j in U:
    for p in P:
        model.addConstr(tj_2[j] + M * (1 - x[j, p]) >= TR[j] + TH_2, name='c11')

for j_1 in S:
    for j_2 in S:
        if j_1 != j_2:
            for p in P:
                model.addConstr(tj_2[j_1] + JPT[j_1, p] <= tj_1[j_2] + M * (2 - s[j_1, j_2] - x[j_2, p]), name='c12')
                model.addConstr(JPT[j_1, p] - M * (2 - s[j_1, j_2] - x[j_2, p]) <= erfa[j_1, j_2], name='c13')

for j_1 in S:
    for j_2 in U:
        for p in P:
            model.addConstr(tj_2[j_1] + JJT[j_1, j_2] <= tj_1[j_2] + M * (1 - s[j_1, j_2]), name='c14')
            model.addConstr(JJT[j_1, j_2] - M * (1 - s[j_1, j_2]) <= erfa[j_1, j_2], name='c15')

for j_1 in U:
    for j_2 in U:
        if j_1 != j_2:
            for p in P:
                model.addConstr(tj_2[j_1] + JPT[j_2, p] <= tj_1[j_2] + M * (2 - s[j_1, j_2] - x[j_1, p]), name='c16')
                model.addConstr(JPT[j_2, p] - M * (2 - s[j_1, j_2] - x[j_1, p]) <= erfa[j_1, j_2], name='c17')

for j_1 in U:
    for j_2 in S:
        for p_1 in P:
            for p_2 in P:
                if p_1 != p_2:
                    model.addConstr(
                        tj_2[j_1] + PPT[p_1, p_2] <= tj_1[j_2] + M * (3 - s[j_1, j_2] - x[j_1, p_1] - x[j_2, p_2]),
                        name='c18')
                    model.addConstr(PPT[p_1, p_2] - M * (3 - s[j_1, j_2] - x[j_1, p_1] - x[j_2, p_2]) <= erfa[j_1, j_2],
                                    name='c19')

for j in S:
    for p in P:
        model.addConstr(tj_1[j] + M * (2 - s[0, j] - x[j, p]) >= JPT[0, p], name='c20')
        model.addConstr(JPT[0, p] - M * (2 - s[0, j] - x[j, p]) <= erfa[0, j], name='c21')

for j in U:
    model.addConstr(tj_1[j] + M * (1 - s[0, j]) >= JJT[0, j], name='c22')
    model.addConstr(JJT[0, j] - M * (1 - s[0, j]) <= erfa[0, j], name='c23')

for j in S:
    model.addConstr(tj_2[j] + JJT[j, J[-1]] <= te + M * (1 - s[j, J[-1]]), name='c24')
    model.addConstr(JJT[j, J[-1]] - M * (1 - s[j, J[-1]]) <= erfa[j, J[-1]], name='c25')

for j in U:
    for p in P:
        model.addConstr(tj_2[j] + JPT[J[-1], p] - M * (2 - s[j, J[-1]] - x[j, p]) <= te, name='c26')
        model.addConstr(JPT[J[-1], p] - M * (2 - s[j, J[-1]] - x[j, p]) <= erfa[j, J[-1]], name='c27')

for j in J[1:-1]:
    for p in P:
        model.addConstr(lamb[j, p] <= x[j, p], name=f'jcc281')
        model.addConstr(w_pos[j, p] >= p * x[j, p] - SerSlots[j][0], name=f'jc281')
        model.addConstr(w_neg[j, p] >= SerSlots[j][0] - p * x[j, p], name=f'jc282')
        model.addConstr(w_jdz[j, p] == w_pos[j, p] + w_neg[j, p], name=f'jc283')
        model.addConstr(w_pos[j, p] <= M * y_1[j, p], name=f'jc284')
        model.addConstr(w_neg[j, p] <= M * (1 - y_1[j, p]), name=f'jc285')
        model.addConstr(w_jdz[j, p] >= 1 - lamb[j, p], name=f'jc29')
        model.addConstr(w_jdz[j, p] <= M * (1 - lamb[j, p]), name=f'jc30')

for j_1 in U:
    for j_2 in U:
        if j_1 != j_2:
            for p in P:
                model.addConstr(delta[j_1, j_2, p] <= s[j_1, j_2], name=f'jc31')
                model.addConstr(delta[j_1, j_2, p] <= x[j_1, p], name=f'jcc31')
                model.addConstr(u_pos[j_1, j_2, p] >= p * x[j_1, p] - SerSlots[j_2][0], name=f'jc321')
                model.addConstr(u_neg[j_1, j_2, p] >= SerSlots[j_2][0] - p * x[j_1, p], name=f'jc322')
                model.addConstr(u_jdz[j_1, j_2, p] == u_pos[j_1, j_2, p] + u_neg[j_1, j_2, p], name=f'jc323')
                model.addConstr(u_pos[j_1, j_2, p] <= M * y_2[j_1, j_2, p], name=f'jc324')
                model.addConstr(u_neg[j_1, j_2, p] <= M * (1 - y_2[j_1, j_2, p]), name=f'jc325')
                model.addConstr(s[j_1, j_2] - M * u_jdz[j_1, j_2, p] <= delta[j_1, j_2, p], name=f'jc33')
                model.addConstr(u_jdz[j_1, j_2, p] <= M * (1 - delta[j_1, j_2, p]), name=f'jc34')

for j_1 in S:
    for j_2 in S:
        if j_1 != j_2:
            for p in P:
                model.addConstr(delta[j_1, j_2, p] <= s[j_1, j_2], name=f'jc31_s')
                model.addConstr(u_pos[j_1, j_2, p] >= p * x[j_2, p] - SerSlots[j_1][0], name=f'jc351')
                model.addConstr(u_neg[j_1, j_2, p] >= SerSlots[j_1][0] - p * x[j_2, p], name=f'jc352')
                model.addConstr(u_jdz[j_1, j_2, p] == u_pos[j_1, j_2, p] + u_neg[j_1, j_2, p], name=f'jc353')
                model.addConstr(u_pos[j_1, j_2, p] <= M * y_2[j_1, j_2, p], name=f'jc354')
                model.addConstr(u_neg[j_1, j_2, p] <= M * (1 - y_2[j_1, j_2, p]), name=f'jc355')
                model.addConstr(s[j_1, j_2] - M * u_jdz[j_1, j_2, p] <= delta[j_1, j_2, p], name=f'jc36')
                model.addConstr(u_jdz[j_1, j_2, p] <= M * (1 - delta[j_1, j_2, p]), name=f'jc37')

for j_1 in S:
    for j_2 in U:
        for p in P:
            model.addConstr(delta[j_1, j_2, p] == 0, name=f'jc38')
            model.addConstr(delta[j_2, j_1, p] == 0, name=f'jc39')

for j in J[1:-1]:
    model.addConstr(bata[j] == quicksum(JPT[j, p] * x[j, p] for p in P), name=f'jc40')

# ==============================================================================
# AUGMECON 方法的目标函数与 epsilon 约束
# ==============================================================================

# 定义三个目标：Cmax, TFT, TEC
objective_exp1 = te
objective_exp2 = quicksum(tj_2[j] for j in J[1:-1])

objective_exp3_1 = ((2 * (len(J) - 2) + 1) - quicksum(lamb[j, p] for j in J[1:-1] for p in P) -
                    quicksum(delta[j_1, j_2, p] for j_1 in J[1:-1] for j_2 in J[1:-1] for p in P if j_1 != j_2)) * Es
objective_exp3_2 = (quicksum(erfa[j_1, j_2] for j_1 in J for j_2 in J if j_1 != j_2)) * Eu
objective_exp3_3 = (quicksum(bata[j] for j in J[1:-1])) * El
objective_exp3 = objective_exp3_1 + objective_exp3_2 + objective_exp3_3

# === 设定根据结果估算出的 epsilon 网格范围 ===
min_TFT, max_TFT, step_TFT = 245, 260, 1  # 基于你 txt 文件中估算的 TFT 极值区间
min_TEC, max_TEC, step_TEC = 40.0, 55.0, 1  # 基于你 txt 文件中估算的 TEC 极值区间

# 生成网格点 (从大到小排列，确保约束逐步收紧)
eps_TFT_list = np.arange(max_TFT, min_TFT - step_TFT, -step_TFT)
eps_TEC_list = np.arange(max_TEC, min_TEC - step_TEC, -step_TEC)

# 添加初始的 epsilon 约束
eps_constr_TFT = model.addConstr(objective_exp2 <= max_TFT, name="eps_TFT_constr")
eps_constr_TEC = model.addConstr(objective_exp3 <= max_TEC, name="eps_TEC_constr")

# AUGMECON 增强目标：以 Cmax 为主，同时附加微小的 TFT 和 TEC 惩罚权重防止“弱最优解”
aug_weight = 1e-4
model.setObjective(objective_exp1 + aug_weight * objective_exp2 + aug_weight * objective_exp3, GRB.MINIMIZE)

# ==============================================================================
# 循环求解并记录实验指标 (满足审稿人要求)
# ==============================================================================

total_scalarizations = 0
feasible_solutions = 0
start_time = time.time()

# 覆盖写入表头
with open("FinalResult_AUGMECON.txt", 'w') as fw:
    fw.write("eps_TFT, eps_TEC, Cmax, TFT, TEC, Runtime(s), Gap, Status\n")

for eps_TFT in eps_TFT_list:
    for eps_TEC in eps_TEC_list:
        total_scalarizations += 1

        # 只更新 RHS (相比每次重新建图效率提升极大)
        eps_constr_TFT.RHS = eps_TFT
        eps_constr_TEC.RHS = eps_TEC

        model.optimize()

        # 如果找到可行解
        if model.status == GRB.status.OPTIMAL or model.status == GRB.status.TIME_LIMIT:
            feasible_solutions += 1

            # 提取真实目标值
            cmax_val = te.X
            tft_val = objective_exp2.getValue()
            E_val = objective_exp3.getValue()

            # 抓取审稿人要求报告的 Gurobi 运行指标
            solve_time = model.Runtime
            gap = model.MIPGap if hasattr(model, "MIPGap") else 0.0
            status_str = "OPTIMAL" if model.status == GRB.status.OPTIMAL else "TIME_LIMIT"

            print(
                f"#{total_scalarizations}: Found Pareto point -> Cmax: {cmax_val:.2f}, TFT: {tft_val:.2f}, TEC: {E_val:.2f} | Time: {solve_time:.2f}s, Gap: {gap:.2%}")

            with open("FinalResult_AUGMECON.txt", 'a') as fw:
                fw.write(
                    f'{eps_TFT}, {eps_TEC}, {cmax_val:.2f}, {tft_val:.2f}, {E_val:.2f}, {solve_time:.2f}, {gap:.4%}, {status_str}\n')

        elif model.status == GRB.status.INFEASIBLE:
            # 当前约束太过苛刻，无解。因为网格是单调递减的，在某些算法实现中内循环可以直接 break 以节省时间
            # 但此处我们选择让程序继续执行穷举完，确保结果万无一失
            pass

total_time = time.time() - start_time

print("\n" + "=" * 50)
print(f"Total Actual CPU Time: {total_time:.2f} seconds")
print(f"Total Number of Scalarizations: {total_scalarizations}")
print(f"Feasible Pareto Points Found: {feasible_solutions}")
print("=" * 50)