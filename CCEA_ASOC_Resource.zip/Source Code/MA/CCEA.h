#pragma once
#include "Heu.h"
class CCEA :
	public Heu
{
public:
	CCEA();
	virtual ~CCEA();
	void RunEvolution_OneConf(int CPUFactor, int Rep);	

private:
	vector<vector<int>> m_RefJobSeqArray;
	vector<vector<int>> m_RefSparkSeqArray;
	vector<vector<double>> m_RefObjectArray;
	vector<double> m_RefFitnessArray;
	
	vector<vector<int>> m_JobSeqArray;
	vector<vector<int>> m_SparkSeqArray;
	vector<vector<double>> m_ObjectArray1;
	vector<double> m_FitnessArray1;
	vector<vector<double>> m_ObjectArray2;
	vector<double> m_FitnessArray2;
	
	int m_RefSize;
	int m_DesLen;
	int m_PS1;
	int m_PS2;
	vector<int> m_Map1;
	vector<int> m_Map2;
	vector<bool> m_bFlag1;// for the reference jobb sequence updated
	vector<bool> m_bFlag2;// for the reference park sequence updated
	vector<int> m_Age1;
	vector<int> m_Age2;
	int m_AgeLimit;
	long m_InitTime;
	long m_TimeLimit;
	//double m_Rate_FamOp;
	vector<int> m_RecordSpan;

	vector<Solution> m_solutions;
	vector<Solution> m_uniquesolutions;
	vector<vector<double>>m_AllSolObjects;
	vector<Solution> m_nonDominatedSolutions;

private:
	void InitPop();
	void RefPointEst();
	void ReInitPop();	
	void SetParameters(int RefSize, int PS1, int PS2, int AgeLimit,int DesLen,long TimeLimit);
	vector<Solution> GetNondominatedSet();
	int Destruction_Construction(int Len, vector<int>& JobSeq, vector<int> SparkSeq, vector<double>& Objects);
	void Evolution();
	void SaveNS(int CPUFactor, int ins, int Rep);
	void SaveRefPoint(vector<vector<int>> RefPoints);
	void LocalSearch_I(vector <int>&JobSeq, vector <int> SparkSeq, vector <double>& Objects);
	void LocalSearch_II(vector <int>& JobSeq, vector <int> SparkSeq, vector <double>& Objects);
	void RandomSlide(vector <int>& JobSeq, vector <int> SparkSeq, vector <double>& Objects);
	
};

