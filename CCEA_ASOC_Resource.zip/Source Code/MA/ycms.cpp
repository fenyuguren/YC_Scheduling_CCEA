#include "stdafx.h"
#include "Problem.h"
#include "Heu.h"
#include "IG.h"
//#include "CCEARef.h"
//#include "CCEAnM.h"
//#include "CCEAB.h"
#pragma comment(lib,"ws2_32.lib") // ��̬��


using namespace Base;
const int Rand_Base = 5;

int _tmain(int argc, _TCHAR* argv[])
{

	//CCEA(10);
	IG ig;
	ig.RunEvolution_OneConf(10,5);
	
	return 0;
}

