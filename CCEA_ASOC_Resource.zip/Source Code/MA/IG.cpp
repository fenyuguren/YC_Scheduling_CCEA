#include "stdafx.h"
#include "IG.h"
IG::IG()
{
}

IG::~IG()
{
}
void IG::SetParameters(int DesLen, long TimeLimit) //PS1>RefSize; PS2>RefSize;
{

	m_DesLen = DesLen;
	m_TimeLimit = TimeLimit;
	m_InitTime = GetElapsedProcessTime();
	m_RefPoints.clear();
	m_RefPoints.resize(3);

	m_solutions.clear();
	m_uniquesolutions.clear();
	m_AllSolObjects.clear();
	m_nonDominatedSolutions.clear();
}



void IG::RefPointEst()
{
	vector<int>JobSeq(m_Jobs), SparkSeq(m_Jobs);
	vector<double>Objects(3, 0);
	vector<vector<int>> JCTime(m_Jobs);
	for (int j = 0; j < JCTime.size(); j++)
		JCTime[j].resize(2, 0);



	int RefObject_0 = INT_MAX;
	int RefObject_1 = INT_MAX;
	int RefObject_2 = INT_MAX;

	int Pos, TempBestPos, TempBestTFT, TempBestCmax, TempBestEC;
	vector<int>TempJobSeq, TempSparkSeq;
	int popsize = 100;
	int Counter = 10;
	vector<vector<int>> pop_I, pop_II;
	for (int cishu = 0; cishu < popsize; cishu++)
	{
		if (cishu == 0) {
			SortJob(1, JobSeq);
		}
		else {
			RandSwap(JobSeq);
		}
		/*if (cishu == 50)
			cout << "ting";*/
		double r = double(rand()) / RAND_MAX;
		if (r < 0.5) {
			AssignSpark_I(JobSeq, SparkSeq);
		}
		else {
			AssignSpark_II(JobSeq, SparkSeq);
		}
		CheckSparks(SparkSeq);
		pop_I.push_back(JobSeq);
		pop_II.push_back(SparkSeq);
	}

	vector<vector<int>> cpop_I = pop_I, cpop_II = pop_II;
	//first extreme point
	int cmaxindex = -1; int improve = 0;
	for (int i = 0; i < popsize; i++)
	{
		JobSeq = cpop_I[i];
		SparkSeq = cpop_II[i];
		int zuixiaozhi = INT_MAX;
		for (int CurJob = 0; CurJob < m_Jobs; CurJob++) {
			TempJobSeq = JobSeq;
			TempSparkSeq = SparkSeq;
			FindJobPos(TempJobSeq, CurJob, Pos);
			TempJobSeq.erase(TempJobSeq.begin() + Pos);
			TempBestCmax = FindBestCmaxPosToInsertJob_InSeq(TempJobSeq, TempSparkSeq, CurJob, TempBestPos);
			TempJobSeq.insert(TempJobSeq.begin() + TempBestPos, CurJob);
			if (TempBestCmax < zuixiaozhi)
			{
				zuixiaozhi = TempBestCmax;
				JobSeq = TempJobSeq;
				SparkSeq = TempSparkSeq;
			}
		}

		GetObjects(JobSeq, SparkSeq, JCTime, Objects);
		cpop_I[i] = JobSeq;
		cpop_II[i] = SparkSeq;

		if (Objects[0] < RefObject_0) {
			cmaxindex = i;
			RefObject_0 = Objects[0];
		}
	}

	JobSeq = cpop_I[cmaxindex];
	SparkSeq = cpop_II[cmaxindex];
	GetObjects(JobSeq, SparkSeq, JCTime, Objects);
	for (int i = 0; i < Counter; i++)
	{
		double preobj = Objects[0];
		ExtremeLocalSearch_I(JobSeq, SparkSeq, Objects);
		double afterobj = Objects[0];
		if (afterobj < preobj)improve++;
		if (m_Jobs <= 5)break;
	}
	RefObject_0 = Objects[0];
	//GetObjects(cpop_I[cmaxindex], cpop_II[cmaxindex], JCTime, Objects);
	m_solutions.push_back(Solution(Objects, JobSeq, SparkSeq));
	m_AllSolObjects.push_back(Objects);


	cout << "�ֲ�����I�Ľ������� * **********************" << improve << endl;

	//second extreme point
	vector<vector<int>> ccpop_I = pop_I, ccpop_II = pop_II;
	int tftindex = -1;
	improve = 0;
	for (int i = 0; i < popsize; i++)
	{
		JobSeq = ccpop_I[i];
		SparkSeq = ccpop_II[i];
		int zuixiaozhi = INT_MAX;
		for (int CurJob = 0; CurJob < m_Jobs; CurJob++) {
			TempJobSeq = JobSeq;
			TempSparkSeq = SparkSeq;

			FindJobPos(TempJobSeq, CurJob, Pos);
			TempJobSeq.erase(TempJobSeq.begin() + Pos);
			TempBestTFT = FindBestTFTPosToInsertJob_InSeq(TempJobSeq, TempSparkSeq, CurJob, TempBestPos);
			TempJobSeq.insert(TempJobSeq.begin() + TempBestPos, CurJob);
			if (TempBestTFT < zuixiaozhi)
			{
				zuixiaozhi = TempBestTFT;
				JobSeq = TempJobSeq;
				SparkSeq = TempSparkSeq;
			}
		}

		GetObjects(JobSeq, SparkSeq, JCTime, Objects);
		ccpop_I[i] = JobSeq;
		ccpop_II[i] = SparkSeq;

		if (Objects[1] < RefObject_1) {
			tftindex = i;
			RefObject_1 = Objects[1];
		}
	}

	JobSeq = ccpop_I[tftindex];
	SparkSeq = ccpop_II[tftindex];
	GetObjects(JobSeq, SparkSeq, JCTime, Objects);
	for (int i = 0; i < Counter; i++)
	{
		int preobj = Objects[1];
		ExtremeLocalSearch_II(JobSeq, SparkSeq, Objects);
		int afterobj = Objects[1];
		if (afterobj < preobj)improve++;
		if (m_Jobs <= 5)break;
	}
	RefObject_1 = Objects[1];
	m_solutions.push_back(Solution(Objects, JobSeq, SparkSeq));
	m_AllSolObjects.push_back(Objects);

	cout << "�ֲ�����II�Ľ�������***********************" << improve << endl;

	vector<vector<int>> cccpop_I = pop_I, cccpop_II = pop_II;
	int ECindex = -1;
	for (int i = 0; i < popsize; i++)
	{
		JobSeq = cccpop_I[i];
		SparkSeq = cccpop_II[i];
		AlignmentAllSpark(JobSeq, SparkSeq);
		CheckSparks(SparkSeq);
		int zuixiaozhi = INT_MAX;

		for (int CurJob = 0; CurJob < m_Jobs; CurJob++) {
			TempJobSeq = JobSeq;
			TempSparkSeq = SparkSeq;

			FindJobPos(TempJobSeq, CurJob, Pos);
			TempJobSeq.erase(TempJobSeq.begin() + Pos);
			TempBestEC = FindBestECPosToInsertJob_InSeq(TempJobSeq, TempSparkSeq, CurJob, TempBestPos);
			TempJobSeq.insert(TempJobSeq.begin() + TempBestPos, CurJob);
			if (TempBestEC < zuixiaozhi)
			{
				zuixiaozhi = TempBestEC;
				JobSeq = TempJobSeq;
				SparkSeq = TempSparkSeq;
			}
		}
		cccpop_I[i] = JobSeq;
		cccpop_II[i] = SparkSeq;

		if (zuixiaozhi < RefObject_2) {
			RefObject_2 = zuixiaozhi;
			ECindex = i;
		}
	}

	GetObjects(cccpop_I[ECindex], cccpop_II[ECindex], JCTime, Objects);
	m_solutions.push_back(Solution(Objects, cccpop_I[ECindex], cccpop_II[ECindex]));
	m_AllSolObjects.push_back(Objects);

	m_RefPoints[0] = RefObject_0;
	m_RefPoints[1] = RefObject_1;
	m_RefPoints[2] = RefObject_2;
	cout << "�ο��㣺" << endl;
	cout << RefObject_0 << " " << RefObject_1 << " " << RefObject_2 << endl;
}

void IG::ExtremeLocalSearch_I(vector <int>& JobSeq, vector <int> SparkSeq, vector <double>& Objects)
{
	int H = 5;
	//���й����ľ������
	vector<vector<int>>CostMatrix(m_Jobs + 1);
	for (int j = 0; j < m_Jobs + 1; j++) {
		CostMatrix[j].resize(m_Jobs + 1);
	}
	GetCostMatrix(CostMatrix, SparkSeq);

	vector <int>TempJobSeq = JobSeq;
	vector<vector<int>> TempJCTime(m_Jobs);
	for (int j = 0; j < TempJCTime.size(); j++)
		TempJCTime[j].resize(2, 0);
	vector<double>TemObjects = Objects;

	if (m_Jobs > H)
	{
		//���ֹ�������
		vector<int> PartialJobSeq;
		PartialJobSeq.clear();
		int RandPoint = rand() % (m_Jobs - H + 1);
		for (int j = RandPoint; j < RandPoint + H; j++) {
			PartialJobSeq.push_back(TempJobSeq[j]);
		}
		int len = PartialJobSeq.size() + 1;
		vector<vector<int>>PartialCostMatrix(len);
		for (int j = 0; j < len; j++) {
			PartialCostMatrix[j].resize(len);
		}

		//���ֹ������е�ͷ����β��
		int head, tail;
		if (RandPoint == 0) {
			head = -1;
		}
		else {
			head = TempJobSeq[RandPoint - 1];
		}
		if (RandPoint == m_Jobs - H) {
			tail = m_Jobs;
		}
		else {
			tail = TempJobSeq[RandPoint + H];
		}

		for (int i = 0; i < len; i++)PartialCostMatrix[i][i] = RAND_MAX;
		//����famseq�е�fam����head�ľ���
		for (int i = 1; i < len; i++) {
			if (head == -1) {
				PartialCostMatrix[0][i] = CostMatrix[0][PartialJobSeq[i - 1] + 1];
			}
			else {
				PartialCostMatrix[0][i] = CostMatrix[head + 1][PartialJobSeq[i - 1] + 1];
			}
		}
		//����famseq�е�fam���ص�head�ľ���
		for (int i = 1; i < len; i++) {
			if (tail == m_Jobs) {
				PartialCostMatrix[i][0] = CostMatrix[PartialJobSeq[i - 1] + 1][0];
			}
			else {
				PartialCostMatrix[i][0] = CostMatrix[PartialJobSeq[i - 1] + 1][tail + 1];
			}
		}
		//����famseq�е�һ��fam����һ��fam�ľ���
		for (int i = 0; i < len - 1; i++) {
			for (int j = 0; j < len - 1; j++) {
				if (i != j) {
					PartialCostMatrix[i + 1][j + 1] = CostMatrix[PartialJobSeq[i] + 1][PartialJobSeq[j] + 1];
				}
			}
		}

		vector<int>OptimalRing = ATSP(PartialCostMatrix);
		OptimalRing.erase(OptimalRing.begin());
		for (int i = 0; i < len - 1; i++)OptimalRing[i]--;
		int start = 0;
		for (int j = RandPoint; j < RandPoint + H; j++) {
			TempJobSeq[j] = PartialJobSeq[OptimalRing[start]];
			start++;
		}
		GetObjects(TempJobSeq, SparkSeq, TempJCTime, TemObjects);

	}
	else {

		vector<int>OptimalRing = ATSP(CostMatrix);
		OptimalRing.erase(OptimalRing.begin());
		for (int i = 0; i < m_Jobs; i++)OptimalRing[i]--;
		TempJobSeq = OptimalRing;
		GetObjects(TempJobSeq, SparkSeq, TempJCTime, TemObjects);

	}

	if (TemObjects[0] < Objects[0])
	{
		JobSeq = TempJobSeq;
		Objects = TemObjects;

	}

}

void IG::ExtremeLocalSearch_II(vector <int>& JobSeq, vector <int> SparkSeq, vector <double>& Objects)
{

	int H = 5;
	//���й����ľ������
	vector<vector<int>>CostMatrix(m_Jobs + 1);
	for (int j = 0; j < m_Jobs + 1; j++) {
		CostMatrix[j].resize(m_Jobs + 1);
	}
	GetCostMatrix(CostMatrix, SparkSeq);

	for (int i = 0; i < m_Jobs + 1; i++)
	{
		for (int j = 0; j < m_Jobs + 1; j++)
			cout << CostMatrix[i][j] << " ";
		cout << endl;
	}

	vector <int>TempJobSeq = JobSeq;
	vector<vector<int>> TempJCTime(m_Jobs);
	for (int j = 0; j < TempJCTime.size(); j++)
		TempJCTime[j].resize(2, 0);
	vector<double>TemObjects = Objects;

	if (m_Jobs > H)
	{
		//���ֹ�������
		vector<int> PartialJobSeq;
		PartialJobSeq.clear();
		int RandPoint = rand() % (m_Jobs - H + 1);
		for (int j = RandPoint; j < RandPoint + H; j++) {
			PartialJobSeq.push_back(TempJobSeq[j]);
		}
		int len = PartialJobSeq.size() + 1;
		vector<vector<int>>PartialCostMatrix(len);
		for (int j = 0; j < len; j++) {
			PartialCostMatrix[j].resize(len);
		}

		//���ֹ������е�ͷ����β��
		int head, tail;
		if (RandPoint == 0) {
			head = -1;
		}
		else {
			head = TempJobSeq[RandPoint - 1];
		}
		if (RandPoint == m_Jobs - H) {
			tail = m_Jobs;
		}
		else {
			tail = TempJobSeq[RandPoint + H];
		}

		for (int i = 0; i < len; i++)PartialCostMatrix[i][i] = RAND_MAX;
		//����famseq�е�fam����head�ľ���
		for (int i = 1; i < len; i++) {
			if (head == -1) {
				PartialCostMatrix[0][i] = CostMatrix[0][PartialJobSeq[i - 1] + 1];
			}
			else {
				PartialCostMatrix[0][i] = CostMatrix[head + 1][PartialJobSeq[i - 1] + 1];
			}
		}
		//����famseq�е�fam���ص�head�ľ���
		for (int i = 1; i < len; i++) {
			if (tail == m_Jobs) {
				PartialCostMatrix[i][0] = CostMatrix[PartialJobSeq[i - 1] + 1][0];
			}
			else {
				PartialCostMatrix[i][0] = CostMatrix[PartialJobSeq[i - 1] + 1][tail + 1];
			}
		}
		//����famseq�е�һ��fam����һ��fam�ľ���
		for (int i = 0; i < len - 1; i++) {
			for (int j = 0; j < len - 1; j++) {
				if (i != j) {
					PartialCostMatrix[i + 1][j + 1] = CostMatrix[PartialJobSeq[i] + 1][PartialJobSeq[j] + 1];
				}
			}
		}

		vector<int>OptimalRing = ATSPT(PartialCostMatrix);
		OptimalRing.erase(OptimalRing.begin());
		for (int i = 0; i < len - 1; i++)OptimalRing[i]--;
		int start = 0;
		for (int j = RandPoint; j < RandPoint + H; j++) {
			TempJobSeq[j] = PartialJobSeq[OptimalRing[start]];
			start++;
		}
		GetObjects(TempJobSeq, SparkSeq, TempJCTime, TemObjects);

	}
	else {

		vector<int>OptimalRing = ATSPT(CostMatrix);
		OptimalRing.erase(OptimalRing.begin());
		for (int i = 0; i < m_Jobs; i++)OptimalRing[i]--;
		TempJobSeq = OptimalRing;
		GetObjects(TempJobSeq, SparkSeq, TempJCTime, TemObjects);

	}

	if (TemObjects[1] < Objects[1])
	{
		JobSeq = TempJobSeq;
		Objects = TemObjects;

	}

}

void IG::FitLocalSearch_I(vector <int>& JobSeq, vector <int> SparkSeq, vector <double>& Objects,double& Fitness)
{
	int H = m_H;
	//���й����ľ������
	vector<vector<int>>CostMatrix(m_Jobs + 1);
	for (int j = 0; j < m_Jobs + 1; j++) {
		CostMatrix[j].resize(m_Jobs + 1);
	}
	GetCostMatrix(CostMatrix, SparkSeq);

	vector <int>TempJobSeq = JobSeq;
	double TempFitness =Fitness;
	vector<vector<int>> TempJCTime(m_Jobs);
	for (int j = 0; j < TempJCTime.size(); j++)
		TempJCTime[j].resize(2, 0);
	vector<double>TemObjects = Objects;

	if (m_Jobs > H)
	{
		//���ֹ�������
		vector<int> PartialJobSeq;
		PartialJobSeq.clear();
		int RandPoint = rand() % (m_Jobs - H + 1);
		for (int j = RandPoint; j < RandPoint + H; j++) {
			PartialJobSeq.push_back(TempJobSeq[j]);
		}
		int len = PartialJobSeq.size() + 1;
		vector<vector<int>>PartialCostMatrix(len);
		for (int j = 0; j < len; j++) {
			PartialCostMatrix[j].resize(len);
		}

		//���ֹ������е�ͷ����β��
		int head, tail;
		if (RandPoint == 0) {
			head = -1;
		}
		else {
			head = TempJobSeq[RandPoint - 1];
		}
		if (RandPoint == m_Jobs - H) {
			tail = m_Jobs;
		}
		else {
			tail = TempJobSeq[RandPoint + H];
		}

		for (int i = 0; i < len; i++)PartialCostMatrix[i][i] = RAND_MAX;
		//����famseq�е�fam����head�ľ���
		for (int i = 1; i < len; i++) {
			if (head == -1) {
				PartialCostMatrix[0][i] = CostMatrix[0][PartialJobSeq[i - 1] + 1];
			}
			else {
				PartialCostMatrix[0][i] = CostMatrix[head + 1][PartialJobSeq[i - 1] + 1];
			}
		}
		//����famseq�е�fam���ص�head�ľ���
		for (int i = 1; i < len; i++) {
			if (tail == m_Jobs) {
				PartialCostMatrix[i][0] = CostMatrix[PartialJobSeq[i - 1] + 1][0];
			}
			else {
				PartialCostMatrix[i][0] = CostMatrix[PartialJobSeq[i - 1] + 1][tail + 1];
			}
		}
		//����famseq�е�һ��fam����һ��fam�ľ���
		for (int i = 0; i < len - 1; i++) {
			for (int j = 0; j < len - 1; j++) {
				if (i != j) {
					PartialCostMatrix[i + 1][j + 1] = CostMatrix[PartialJobSeq[i] + 1][PartialJobSeq[j] + 1];
				}
			}
		}

		vector<int>OptimalRing = ATSP(PartialCostMatrix);
		OptimalRing.erase(OptimalRing.begin());
		for (int i = 0; i < len - 1; i++)OptimalRing[i]--;
		int start = 0;
		for (int j = RandPoint; j < RandPoint + H; j++) {
			TempJobSeq[j] = PartialJobSeq[OptimalRing[start]];
			start++;
		}
		GetSpan(TempJobSeq, SparkSeq, TempJCTime, TemObjects, TempFitness);

	}
	else {

		vector<int>OptimalRing = ATSP(CostMatrix);
		OptimalRing.erase(OptimalRing.begin());
		for (int i = 0; i < m_Jobs; i++)OptimalRing[i]--;
		TempJobSeq = OptimalRing;
		GetSpan(TempJobSeq, SparkSeq, TempJCTime, TemObjects, TempFitness);

	}
	m_solutions.push_back(Solution(TemObjects, TempJobSeq, SparkSeq));
	m_AllSolObjects.push_back(TemObjects);

	if (TempFitness < Fitness)
	{
		JobSeq = TempJobSeq;
		Objects = TemObjects;
		Fitness = TempFitness;
	}

}

void IG::FitLocalSearch_II(vector <int>& JobSeq, vector <int> SparkSeq, vector <double>& Objects,double& Fitness)
{

	int H = m_H;
	//���й����ľ������
	vector<vector<int>>CostMatrix(m_Jobs + 1);
	for (int j = 0; j < m_Jobs + 1; j++) {
		CostMatrix[j].resize(m_Jobs + 1);
	}
	GetCostMatrix(CostMatrix, SparkSeq);

	//for (int i = 0; i < m_Jobs + 1; i++)
	//{
	//	for (int j = 0; j < m_Jobs + 1; j++)
	//		cout << CostMatrix[i][j] << " ";
	//	cout << endl;
	//}

	vector <int>TempJobSeq = JobSeq;
	double TempFitness = Fitness;
	vector<vector<int>> TempJCTime(m_Jobs);
	for (int j = 0; j < TempJCTime.size(); j++)
		TempJCTime[j].resize(2, 0);
	vector<double>TemObjects = Objects;

	if (m_Jobs > H)
	{
		//���ֹ�������
		vector<int> PartialJobSeq;
		PartialJobSeq.clear();
		int RandPoint = rand() % (m_Jobs - H + 1);
		for (int j = RandPoint; j < RandPoint + H; j++) {
			PartialJobSeq.push_back(TempJobSeq[j]);
		}
		int len = PartialJobSeq.size() + 1;
		vector<vector<int>>PartialCostMatrix(len);
		for (int j = 0; j < len; j++) {
			PartialCostMatrix[j].resize(len);
		}

		//���ֹ������е�ͷ����β��
		int head, tail;
		if (RandPoint == 0) {
			head = -1;
		}
		else {
			head = TempJobSeq[RandPoint - 1];
		}
		if (RandPoint == m_Jobs - H) {
			tail = m_Jobs;
		}
		else {
			tail = TempJobSeq[RandPoint + H];
		}

		for (int i = 0; i < len; i++)PartialCostMatrix[i][i] = RAND_MAX;
		//����famseq�е�fam����head�ľ���
		for (int i = 1; i < len; i++) {
			if (head == -1) {
				PartialCostMatrix[0][i] = CostMatrix[0][PartialJobSeq[i - 1] + 1];
			}
			else {
				PartialCostMatrix[0][i] = CostMatrix[head + 1][PartialJobSeq[i - 1] + 1];
			}
		}
		//����famseq�е�fam���ص�head�ľ���
		for (int i = 1; i < len; i++) {
			if (tail == m_Jobs) {
				PartialCostMatrix[i][0] = CostMatrix[PartialJobSeq[i - 1] + 1][0];
			}
			else {
				PartialCostMatrix[i][0] = CostMatrix[PartialJobSeq[i - 1] + 1][tail + 1];
			}
		}
		//����famseq�е�һ��fam����һ��fam�ľ���
		for (int i = 0; i < len - 1; i++) {
			for (int j = 0; j < len - 1; j++) {
				if (i != j) {
					PartialCostMatrix[i + 1][j + 1] = CostMatrix[PartialJobSeq[i] + 1][PartialJobSeq[j] + 1];
				}
			}
		}

		vector<int>OptimalRing = ATSPT(PartialCostMatrix);
		OptimalRing.erase(OptimalRing.begin());
		for (int i = 0; i < len - 1; i++)OptimalRing[i]--;
		int start = 0;
		for (int j = RandPoint; j < RandPoint + H; j++) {
			TempJobSeq[j] = PartialJobSeq[OptimalRing[start]];
			start++;
		}		
		GetSpan(TempJobSeq, SparkSeq, TempJCTime, TemObjects, TempFitness);

	}
	else {

		vector<int>OptimalRing = ATSPT(CostMatrix);
		OptimalRing.erase(OptimalRing.begin());
		for (int i = 0; i < m_Jobs; i++)OptimalRing[i]--;
		TempJobSeq = OptimalRing;
		GetSpan(TempJobSeq, SparkSeq, TempJCTime, TemObjects, TempFitness);

	}
	m_solutions.push_back(Solution(TemObjects, TempJobSeq, SparkSeq));
	m_AllSolObjects.push_back(TemObjects);

	if (TempFitness < Fitness)
	{
		JobSeq = TempJobSeq;
		Objects = TemObjects;
		Fitness = TempFitness;
	}

}

void IG::InitSolution()
{
	vector<int>JobSeq(m_Jobs), SparkSeq(m_Jobs);
	vector<double>Objects(3, 0);
	vector<vector<int>> JCTime(m_Jobs);
	for (int j = 0; j < JCTime.size(); j++)
		JCTime[j].resize(2, 0);
	double fitness = 0;
	SortJob(1, JobSeq);
	double r = double(rand()) / RAND_MAX;
	if (r < 0.5) {
		AssignSpark_I(JobSeq, SparkSeq);
	}
	else {
		AssignSpark_II(JobSeq, SparkSeq);
	}
	CheckSparks(SparkSeq);
	GetSpan(JobSeq, SparkSeq, JCTime, Objects, fitness);

	m_JobSeq = JobSeq;
	m_SparkSeq = SparkSeq;
	m_Objects = Objects;
	m_Fitness = fitness;

	m_BestJobSeq = m_JobSeq;
	m_BestSparkSeq = m_SparkSeq;
	m_BestObjects = m_Objects;
	m_BestFitness = m_Fitness;

}

int IG::Destruction_Construction(vector<int>& JobSeq, vector<int> SparkSeq, vector<double>& Objects)
{
	//Extract Len jobs from jobseq
	vector<int> ExtractFamSeq;
	do {


		int Pos = rand() % JobSeq.size();
		ExtractFamSeq.push_back(JobSeq[Pos]);
		JobSeq.erase(JobSeq.begin() + Pos);

	} while (ExtractFamSeq.size() < m_DesLen);
	int bestPos = -1;
	double fitness = -1;
	//construction
	for (int CurJob : ExtractFamSeq) {
		fitness = FindBestPosToInsertJob_InSeq(JobSeq, SparkSeq, CurJob, bestPos, Objects);
		JobSeq.insert(JobSeq.begin() + bestPos, CurJob);
	}

	return fitness;

}

double IG::FromObjToFit(vector <double>Objects) 
{
	double fitness = (Objects[0] - m_RefPoints[0]) / 3 + (Objects[1] - m_RefPoints[1]) / 3 + (Objects[2] - m_RefPoints[2]) / 3;
	return fitness;
}

void IG::IGreedyInsert(vector <int>& JobSeq, vector <int> SparkSeq, vector <double>& Objects, double& fitness)
{
	int Pos, TempBestPos, TempBestFit;
	vector<double>TempBestObjects(3, 0);
	vector<int>TempJobSeq;

	for (int CurJob = 0; CurJob < m_Jobs; CurJob++) {
		TempJobSeq = JobSeq;
		FindJobPos(TempJobSeq, CurJob, Pos);
		TempJobSeq.erase(TempJobSeq.begin() + Pos);
		TempBestFit = FindBestPosToInsertJob_InSeq(TempJobSeq, SparkSeq, CurJob, TempBestPos, TempBestObjects);
		TempJobSeq.insert(TempJobSeq.begin() + TempBestPos, CurJob);

		m_solutions.push_back(Solution(TempBestObjects, TempJobSeq, SparkSeq));
		m_AllSolObjects.push_back(TempBestObjects);

		if (TempBestFit < fitness)
		{
			fitness = TempBestFit;
			JobSeq = TempJobSeq;
			Objects = TempBestObjects;

		}

	}
}

void IG::IGreedySwap(vector <int>& JobSeq, vector <int> SparkSeq, vector <double>& Objects, double& fitness)
{

	int x = -1, y = -1;
	vector<double> TempObjects(3);
	double tempfit = 0;

	vector<vector<int>> JCTime(m_Jobs);
	for (int j = 0; j < JCTime.size(); j++)
		JCTime[j].resize(2, 0);

	double MinFit = fitness;
	for (int i = 0; i < m_Jobs - 1; i++) {
		for (int j = i + 1; j < m_Jobs; j++) {
			vector <int> TemJobSeq = JobSeq;
			int Job = TemJobSeq[i];
			TemJobSeq[i] = TemJobSeq[j];
			TemJobSeq[j] = Job;
			GetSpan(TemJobSeq, SparkSeq, JCTime, TempObjects, tempfit);

			m_solutions.push_back(Solution(TempObjects, TemJobSeq, SparkSeq));
			m_AllSolObjects.push_back(TempObjects);

			if (tempfit < MinFit) {
				MinFit = tempfit;
				x = i;
				y = j;
			}
		}
	}
	if (x != -1 && y != -1) {
		int Job = JobSeq[x];
		JobSeq[x] = JobSeq[y];
		JobSeq[y] = Job;
		GetSpan(JobSeq, SparkSeq, JCTime, Objects, fitness);
	}

}

void IG::Evolution()//Evolution2 without ReInitPop;
{

	m_RecordSpan.clear();
	int Record = 1;

	vector<int>JobSeq(m_Jobs), SparkSeq(m_Jobs), TempJobSeq(m_Jobs), TempSparkSeq(m_Jobs);
	vector<double>Objects(3, 0), TempObjects(3, 0);
	double fitness = 0, tempfit = 0;

	vector<vector<int>> JCTime(m_Jobs);
	for (int j = 0; j < JCTime.size(); j++)
		JCTime[j].resize(2, 0);

	JobSeq = m_JobSeq;
	SparkSeq = m_SparkSeq;
	Objects = m_Objects;
	fitness = m_Fitness;


	int round = 0;
	while (true)
	{
		if (round % 50 == 0)
		{
			double r = double(rand()) / RAND_MAX;
			if (r < 0.5) {
				AssignSpark_I(JobSeq, SparkSeq);
			}
			else {
				AssignSpark_II(JobSeq, SparkSeq);
			}
			CheckSparks(SparkSeq);
			GetSpan(JobSeq, SparkSeq, JCTime, Objects, fitness);

		}

		TempJobSeq = JobSeq;
		TempSparkSeq = SparkSeq;
		TempObjects = Objects;
		tempfit = fitness;

		m_solutions.push_back(Solution(Objects, JobSeq, SparkSeq));
		m_AllSolObjects.push_back(Objects);

		tempfit =Destruction_Construction(TempJobSeq, TempSparkSeq, TempObjects);
		
		m_solutions.push_back(Solution(TempObjects, TempJobSeq, TempSparkSeq));
		m_AllSolObjects.push_back(TempObjects);
		
		IGreedyInsert(TempJobSeq, TempSparkSeq, TempObjects, tempfit);
		IGreedySwap(TempJobSeq, TempSparkSeq, TempObjects, tempfit);

		double p = double(rand()) / RAND_MAX;
		if (p < 0.1) 
		{
			for (int H = 3; H <= 5; H++) {
				m_H = H;
				FitLocalSearch_I(TempJobSeq, TempSparkSeq, TempObjects, tempfit);
				FitLocalSearch_II(TempJobSeq, TempSparkSeq, TempObjects, tempfit);			
			}
			
		}

		if (tempfit < fitness)
		{
			fitness= tempfit;
			JobSeq= TempJobSeq;
			SparkSeq= TempSparkSeq;
			Objects= TempObjects;		
		}
		else {
			double q = double(rand()) / RAND_MAX;
			if (p < 0.1)
			{
				fitness = tempfit;
				JobSeq = TempJobSeq;
				SparkSeq = TempSparkSeq;
				Objects = TempObjects;
			}		
		}

		long CurTime = GetElapsedProcessTime();
		long ElapsedTime = CurTime - m_InitTime;
		if (ElapsedTime >= m_TimeLimit) break;

		m_solutions.push_back(Solution(Objects, JobSeq, SparkSeq));
		m_AllSolObjects.push_back(Objects);
		round++;

	}
	cout << round << endl;
	vector<int>indexs = removeDuplicateRows(m_AllSolObjects);
	for (int i = 0; i < indexs.size(); i++)
	{
		m_uniquesolutions.push_back(m_solutions[indexs[i]]);
	}
	m_nonDominatedSolutions = findNonDominatedSolutions(m_uniquesolutions);
}

void IG::SaveNS(int CPUFactor, int ins, int Rep)
{

	ofstream ofile;
	ostringstream ostr;

	ofstream ofile_I;
	ostringstream ostr_I;

	ostr.str("");
	ostr_I.str("");
	ostr.clear();
	ostr_I.clear();

	ostr << ".\\Results\\DetailIG_" << CPUFactor << "_" << ins << "_" << Rep + 1 << ".txt";
	ofile.open(ostr.str());

	if (!ofile.is_open()) {
		std::cerr << "Failed to open file: " << ostr.str() << std::endl;

	}

	ostr_I << ".\\Results\\TwoIG_" << CPUFactor << "_" << ins << "_" << Rep + 1 << ".txt";
	ofile_I.open(ostr_I.str());

	if (!ofile_I.is_open()) {
		std::cerr << "Failed to open file: " << ostr_I.str() << std::endl;

	}
	vector<vector<int>> JCTime(m_Jobs);
	for (int j = 0; j < JCTime.size(); j++)
		JCTime[j].resize(2, 0);
	vector<double>objects(3, 0), tmepobjects(3, 0);
	vector<int>seq1, seq2;
	cout << "Non-dominated solutions: \n";
	for (const auto& sol : m_nonDominatedSolutions) {

		objects = sol.objectives;
		seq1 = sol.jobseq;
		seq2 = sol.sparkseq;
		/*seq1 = { 0, 3, 4, 1, 2};
		seq2 = { 2, 5, 8, 1, 3 };*/
		GetObjects(seq1, seq2, JCTime, tmepobjects);
		for (int i : seq1) {
			cout << i << " ";
			ofile << i << " ";
		}
		cout << "\t";
		ofile << "\t";

		for (int i : seq2) {
			cout << i << " ";
			ofile << i << " ";
		}
		cout << "\t";
		ofile << "\t";

		cout << "(" << objects[0] << ", " << objects[1] << ", " << objects[2] << ")\n";
		ofile << "(" << objects[0] << ", " << objects[1] << ", " << objects[2] << ")\n";
		ofile_I << objects[0] << " " << objects[1] << " " << objects[2] << "\n";
	}
	ofile.flush();
	ofile_I.flush();


	ofile.close();
	ofile_I.close();

}


void IG::RunEvolution_OneConf(int CPUFactor, int Reps) //the same as Evolution2 except only one Reference, 
{
	/*ofstream ofile;
	ostringstream ostr;
	ostr.str("");
	ostr.clear();
	ostr << "������ģ.txt";
	ofile.open(ostr.str());*/
	//double Rate = 1.0;
	int Instances = 100;
	for (int ins = 0; ins <= Instances; ins++)
	{
		ReadInstance(ins);
		//ofile << m_Bays << ", " << m_Rows << ", " << m_Jobs <<"\n";
		int DesLen = 4;
		for (int Rep = 0; Rep < Reps; Rep++) {
			srand(ins * 100 + Rep);
			long StartTime_Ins = ::GetElapsedProcessTime();
			SetParameters(DesLen, CPUFactor * m_Bays * m_Rows * m_Jobs);
			RefPointEst();
			InitSolution();
			Evolution();
			SaveNS(CPUFactor, ins, Rep);
		}

	}

}

