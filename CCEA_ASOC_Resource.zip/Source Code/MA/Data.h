#pragma once
#include "stdafx.h"
class Solution {
public:
	//double objective1; // Ŀ��1
	//double objective2; // Ŀ��2
	//double objective3; // Ŀ��3
	vector<int> jobseq;
	vector<int> sparkseq;
	vector<double>objectives;
	// ���캯��
	Solution(vector<double>objs,vector<int> seq1, vector<int> seq2) :  objectives(objs),jobseq(seq1), sparkseq(seq2){}
};