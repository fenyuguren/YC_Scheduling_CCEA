#pragma once
#include "Heu.h"
class TS :
	public Heu
{
public:
	TS();
	virtual ~TS();
	void RunEvolution_OneConf(int CPUFactor, int Rep);

private:
	vector<int>m_JobSeq;
	vector<int>m_SparkSeq;
	vector<double>m_Objects;
	double m_Fitness;

	vector<int>m_BestJobSeq;
	vector<int>m_BestSparkSeq;
	vector<double>m_BestObjects;
	double m_BestFitness;

	int m_TSLen;
	vector<vector<int>>m_TabuList;
	long m_InitTime;
	long m_TimeLimit;
	vector<int> m_RecordSpan;
	

	vector<Solution> m_solutions;
	vector<Solution> m_uniquesolutions;
	vector<vector<double>>m_AllSolObjects;
	vector<Solution> m_nonDominatedSolutions;

private:
	void InitSolution();	
	void SetParameters(int DesLen, long TimeLimit);
	vector<Solution> GetNondominatedSet();	
	void Evolution();
	void SaveNS(int CPUFactor, int ins, int Rep);
};