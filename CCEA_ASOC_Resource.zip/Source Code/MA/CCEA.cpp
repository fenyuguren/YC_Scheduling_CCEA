#include "stdafx.h"
#include "CCEA.h"

CCEA::CCEA()
{
}

CCEA::~CCEA()
{
}

void CCEA::SetParameters(int RefSize, int PS1, int PS2, int AgeLimit,int DesLen, long TimeLimit) //PS1>RefSize; PS2>RefSize;
{
	m_RefSize = RefSize;
	m_PS1 = PS1;
	m_PS2 = PS2;

	m_AgeLimit = AgeLimit;
	m_DesLen = DesLen;
	
	m_TimeLimit = TimeLimit;
	m_InitTime = GetElapsedProcessTime();


	/*--------------------------Reference set----------------------------*/
	m_RefJobSeqArray.clear();
	m_RefJobSeqArray.resize(m_RefSize);

	m_RefSparkSeqArray.clear();
	m_RefSparkSeqArray.resize(m_RefSize);

	m_RefObjectArray.clear();
	m_RefObjectArray.resize(m_RefSize);

	m_RefFitnessArray.clear();
	m_RefFitnessArray.resize(m_RefSize);

	m_bFlag1.clear(); // Flag: the RefJob changed;
	m_bFlag1.resize(m_RefSize);

	m_bFlag2.clear();// Flag: the RefPark changed;
	m_bFlag2.resize(m_RefSize);

	/*--------------------------Job sequence population--------------------*/
	m_JobSeqArray.clear();
	m_JobSeqArray.resize(m_PS1);

	m_ObjectArray1.clear();
	m_ObjectArray1.resize(m_PS1);

	m_FitnessArray1.clear();
	m_FitnessArray1.resize(m_PS1);

	m_Map1.clear(); // the corresponding RefPark
	m_Map1.resize(m_PS1);

	m_Age1.clear();
	m_Age1.resize(m_PS1);

	
	/*--------------------------Spark sequence population--------------------*/
	m_SparkSeqArray.clear();
	m_SparkSeqArray.resize(m_PS2);

	m_ObjectArray2.clear();
	m_ObjectArray2.resize(m_PS2);

	m_FitnessArray2.clear();
	m_FitnessArray2.resize(m_PS2);	

	m_Map2.clear();// the corresponding RefJob
	m_Map2.resize(m_PS2);

	m_Age2.clear();
	m_Age2.resize(m_PS2);	

	m_RefPoints.clear();
	m_RefPoints.resize(3);

	m_solutions.clear();
	m_uniquesolutions.clear();
	m_AllSolObjects.clear();
	m_nonDominatedSolutions.clear();



}
void CCEA::RefPointEst()
{
	vector<int>JobSeq(m_Jobs), SparkSeq(m_Jobs);
	vector<double>Objects(3, 0);	
	vector<vector<int>> JCTime(m_Jobs);
	for (int j = 0; j < JCTime.size(); j++)
		JCTime[j].resize(2, 0);
	


	int RefObject_0 = INT_MAX;
	int RefObject_1 = INT_MAX;
	int RefObject_2 = INT_MAX;

	int Pos, TempBestPos, TempBestTFT,TempBestCmax,TempBestEC;
	vector<int>TempJobSeq, TempSparkSeq;
	int popsize = 500;
	int Counter = 10;
	vector<vector<int>> pop_I,pop_II;
	for (int cishu = 0; cishu < popsize; cishu++)
	{
		if (cishu == 0) {
			SortJob(1, JobSeq);
		}
		else {
			RandSwap(JobSeq);
		}
		/*if (cishu == 50)
			cout << "ting";*/
		double r = double(rand()) / RAND_MAX;
		if (r < 0.5) {
			AssignSpark_I(JobSeq, SparkSeq);
		}
		else {
			AssignSpark_II(JobSeq, SparkSeq);
		}
		CheckSparks(SparkSeq);
		pop_I.push_back(JobSeq);
		pop_II.push_back(SparkSeq);
	}

	vector<vector<int>> cpop_I= pop_I, cpop_II= pop_II;
	//first extreme point
	int cmaxindex = -1; int improve = 0;
	for (int i = 0; i < popsize; i++)
	{
		JobSeq= cpop_I[i];
		SparkSeq= cpop_II[i];
		int zuixiaozhi = INT_MAX;
		for (int CurJob = 0; CurJob < m_Jobs; CurJob++) {
			TempJobSeq = JobSeq;
			TempSparkSeq=SparkSeq;
			FindJobPos(TempJobSeq, CurJob, Pos);
			TempJobSeq.erase(TempJobSeq.begin() + Pos);
			TempBestCmax = FindBestCmaxPosToInsertJob_InSeq(TempJobSeq, TempSparkSeq, CurJob, TempBestPos);
			TempJobSeq.insert(TempJobSeq.begin() + TempBestPos, CurJob);
			if (TempBestCmax < zuixiaozhi)
			{
				zuixiaozhi = TempBestCmax;
				JobSeq = TempJobSeq;
				SparkSeq = TempSparkSeq;
			}
		}
		
		GetObjects(JobSeq, SparkSeq, JCTime, Objects);		
		cpop_I[i] = JobSeq;
		cpop_II[i] = SparkSeq;

		if (Objects[0] < RefObject_0) {
			cmaxindex = i;
			RefObject_0 = Objects[0];			
		}		
	}

	JobSeq = cpop_I[cmaxindex];
	SparkSeq=cpop_II[cmaxindex];
	GetObjects(JobSeq, SparkSeq, JCTime, Objects);
	for (int i = 0; i < Counter; i++)
	{
		double preobj = Objects[0];
		LocalSearch_I(JobSeq, SparkSeq, Objects);
		double afterobj = Objects[0];
		if (afterobj < preobj)improve++;
		if (m_Jobs <= 5)break;
	}
	RefObject_0 = Objects[0];
	//GetObjects(cpop_I[cmaxindex], cpop_II[cmaxindex], JCTime, Objects);
	m_solutions.push_back(Solution(Objects, JobSeq, SparkSeq));
	m_AllSolObjects.push_back(Objects);
	

	cout << "�ֲ�����I�Ľ������� * **********************" << improve << endl;

	//second extreme point
	vector<vector<int>> ccpop_I = pop_I, ccpop_II = pop_II;
	int tftindex = -1;
	improve = 0;
	for (int i = 0; i < popsize; i++)
	{
		JobSeq = ccpop_I[i];
		SparkSeq = ccpop_II[i];
		int zuixiaozhi = INT_MAX;
		for (int CurJob = 0; CurJob < m_Jobs; CurJob++) {
			TempJobSeq = JobSeq;
			TempSparkSeq = SparkSeq;

			FindJobPos(TempJobSeq, CurJob, Pos);
			TempJobSeq.erase(TempJobSeq.begin() + Pos);
			TempBestTFT = FindBestTFTPosToInsertJob_InSeq(TempJobSeq, TempSparkSeq, CurJob, TempBestPos);
			TempJobSeq.insert(TempJobSeq.begin() + TempBestPos, CurJob);
			if (TempBestTFT < zuixiaozhi)
			{
				zuixiaozhi = TempBestTFT;
				JobSeq = TempJobSeq;
				SparkSeq = TempSparkSeq;
			}
		}

		GetObjects(JobSeq, SparkSeq, JCTime, Objects);
		ccpop_I[i] = JobSeq;
		ccpop_II[i] = SparkSeq;

		if (Objects[1] < RefObject_1) {
			tftindex = i;
			RefObject_1 = Objects[1];			
		}
	}

	JobSeq = ccpop_I[tftindex];
	SparkSeq = ccpop_II[tftindex];
	GetObjects(JobSeq, SparkSeq, JCTime, Objects);
	for (int i = 0; i < Counter; i++)
	{
		int preobj = Objects[1];
		LocalSearch_II(JobSeq, SparkSeq, Objects);
		int afterobj = Objects[1];
		if (afterobj < preobj)improve++;
		if (m_Jobs <= 5)break;
	}
	RefObject_1 = Objects[1];
    m_solutions.push_back(Solution(Objects, JobSeq, SparkSeq));
	m_AllSolObjects.push_back(Objects);
	
	cout << "�ֲ�����II�Ľ�������***********************" << improve << endl;

	vector<vector<int>> cccpop_I = pop_I, cccpop_II = pop_II;
	int ECindex = -1;
	for (int i = 0; i < popsize; i++)
	{
		JobSeq = cccpop_I[i];
		SparkSeq = cccpop_II[i];
		AlignmentAllSpark(JobSeq, SparkSeq);
		CheckSparks(SparkSeq);
		int zuixiaozhi = INT_MAX;

		for (int CurJob = 0; CurJob < m_Jobs; CurJob++) {
			TempJobSeq = JobSeq;
			TempSparkSeq = SparkSeq;

			FindJobPos(TempJobSeq, CurJob, Pos);
			TempJobSeq.erase(TempJobSeq.begin() + Pos);
			TempBestEC = FindBestECPosToInsertJob_InSeq(TempJobSeq, TempSparkSeq, CurJob, TempBestPos);
			TempJobSeq.insert(TempJobSeq.begin() + TempBestPos, CurJob);
			if (TempBestEC < zuixiaozhi)
			{
				zuixiaozhi = TempBestEC;
				JobSeq = TempJobSeq;
				SparkSeq = TempSparkSeq;
			}
		}
		cccpop_I[i] = JobSeq;
		cccpop_II[i] = SparkSeq;

		if (zuixiaozhi < RefObject_2) {
			RefObject_2 = zuixiaozhi;
			ECindex = i;
		}
	}

	GetObjects(cccpop_I[ECindex], cccpop_II[ECindex], JCTime, Objects);
	m_solutions.push_back(Solution(Objects, cccpop_I[ECindex], cccpop_II[ECindex]));
	m_AllSolObjects.push_back(Objects);

	m_RefPoints[0] = RefObject_0;
	m_RefPoints[1] = RefObject_1;
	m_RefPoints[2] = RefObject_2;
	cout << "�ο��㣺" << endl;
	cout << RefObject_0 << " " << RefObject_1 << " " << RefObject_2 << endl;
}

vector<Solution> CCEA::GetNondominatedSet()
{
	vector<Solution> solutions;
	for (int i = 0; i < m_PS1; i++)
		solutions.push_back(Solution(m_ObjectArray1[i], m_JobSeqArray[i], m_RefSparkSeqArray[m_Map1[i]]));

	for (int i = 0; i < m_PS2; i++)
		solutions.push_back(Solution(m_ObjectArray2[i], m_RefJobSeqArray[m_Map2[i]], m_SparkSeqArray[i]));

	vector<Solution> nonDominatedSolutions = findNonDominatedSolutions(solutions);
	vector<int>seq1, seq2;
	cout << "Non-dominated solutions: \n";
	for (const auto& sol : nonDominatedSolutions) {
		seq1 = sol.jobseq;
		seq2 = sol.sparkseq;
		for (int j : seq1)cout << j << " ";
		cout << "\t";
		for (int j : seq2)cout << j << " ";
		cout << "(" << sol.objectives[0] << ", " << sol.objectives[1] << ", " << sol.objectives[2] << ")\n";
	}
	return nonDominatedSolutions;
}


void CCEA::InitPop()
{
	vector<int>JobSeq(m_Jobs), SparkSeq(m_Jobs);
	vector<double>Objects(3,0);
	vector<vector<int>> JCTime(m_Jobs);
	for (int j = 0; j < JCTime.size(); j++)
		JCTime[j].resize(2, 0);	
	double fitness = 0;
	
	for (int PS = 0; PS < m_RefSize; PS++) 
	{
		if (PS == 0) {
			SortJob(1, JobSeq);				
		}
		else {
			RandSwap(JobSeq);		
		}
		
		double r = double(rand()) / RAND_MAX;
		if (r < 0.5) {
			AssignSpark_I(JobSeq, SparkSeq);
		}
		else{
			AssignSpark_II(JobSeq, SparkSeq);
		}
		CheckSparks(SparkSeq);
		m_RefJobSeqArray[PS] = JobSeq;
		m_RefSparkSeqArray[PS] = SparkSeq;		
		GetSpan(JobSeq, SparkSeq, JCTime, Objects, fitness);
		m_RefObjectArray[PS] = Objects;
		m_RefFitnessArray[PS] = fitness;
		
	}	

	//Initilize job-sequence population, i.e., PS1
	for (int PS = 0; PS < min(m_PS1, m_RefSize); PS++)
	{
		m_JobSeqArray[PS] = m_RefJobSeqArray[PS];
		m_ObjectArray1[PS] = m_RefObjectArray[PS];
		m_FitnessArray1[PS] = m_RefFitnessArray[PS];
		m_Map1[PS] = PS;		
	}

	for (int PS = min(m_PS1, m_RefSize); PS < m_PS1; PS++)
	{
		//randomly select a job sequence from reference set and swap
		int r = rand() % m_RefSize;
		m_JobSeqArray[PS] = m_RefJobSeqArray[r];
		RandSwap(m_JobSeqArray[PS]);
		
		//randomly select a sparking seqence from reference set
		m_Map1[PS] = rand() % m_RefSize;		
		GetSpan(m_JobSeqArray[PS], m_RefSparkSeqArray[m_Map1[PS]], JCTime, Objects, fitness);
		m_ObjectArray1[PS] = Objects;
		m_FitnessArray1[PS] = fitness;	
		//cout << Objects[0] << " " << Objects[1] << " " << Objects[2] << endl;
	}

	//Initialize spark-sequence population, i.e., PS2
	for (int PS = 0; PS < min(m_PS2, m_RefSize); PS++)
	{
		m_SparkSeqArray[PS] = m_RefSparkSeqArray[PS];
		m_ObjectArray2[PS] = m_RefObjectArray[PS];
		m_FitnessArray2[PS] = m_RefFitnessArray[PS];
		m_Map2[PS] = PS;
		
	}

	for (int PS = min(m_PS2, m_RefSize); PS < m_PS2; PS++)
	{
		//randomly select a spark sequence from reference set and swap
		int r = rand() % m_RefSize;
		m_SparkSeqArray[PS] = m_RefSparkSeqArray[r];
		
		
		//randomly select a job seqence from reference set
		m_Map2[PS] = rand() % m_RefSize;
		AlignmentSpark(m_RefJobSeqArray[m_Map2[PS]], m_SparkSeqArray[PS]);
		CheckSparks(m_SparkSeqArray[PS]);
		GetSpan(m_RefJobSeqArray[m_Map2[PS]], m_SparkSeqArray[PS], JCTime, Objects, fitness);
		m_ObjectArray2[PS] = Objects;
		m_FitnessArray2[PS] = fitness;		
	}
	/*vector<Solution>NDSet=GetNondominatedSet();
	cout << endl;*/
}

int CCEA::Destruction_Construction(int Len, vector<int>& JobSeq, vector<int> SparkSeq, vector<double>& Objects)
{
	//Extract Len jobs from jobseq
	vector<int> ExtractFamSeq;
	do {
		
		
			int Pos = rand() % JobSeq.size();
			ExtractFamSeq.push_back(JobSeq[Pos]);
			JobSeq.erase(JobSeq.begin() + Pos);
		
	} while (ExtractFamSeq.size() < Len);
	int bestPos = -1;
	double fitness = -1;
	//construction
	for (int CurJob : ExtractFamSeq) {	
		fitness= FindBestPosToInsertJob_InSeq(JobSeq, SparkSeq, CurJob, bestPos, Objects);
		JobSeq.insert(JobSeq.begin() + bestPos, CurJob);
	}
	
	return fitness;	
	
}



void CCEA::ReInitPop() //reproduce a solution if age Limit is met
{
	vector<vector<int>> JCTime(m_Jobs);
	for (int j = 0; j < JCTime.size(); j++)
		JCTime[j].resize(2, 0);

	for (int PS = 0; PS < m_PS1; PS++)
	{
		if (m_Age1[PS] < m_AgeLimit) continue;
		m_JobSeqArray[PS] = m_RefJobSeqArray[m_Map1[PS]];		
		m_FitnessArray1[PS] = Destruction_Construction(m_DesLen, m_JobSeqArray[PS], m_RefSparkSeqArray[m_Map1[PS]], m_ObjectArray1[PS]);
		m_Age1[PS] = 0;
	}

	for (int PS = 0; PS < m_PS2; PS++)
	{
		if (m_Age2[PS] < m_AgeLimit) continue;
		m_SparkSeqArray[PS] = m_RefSparkSeqArray[m_Map2[PS]];

		double r = double(rand()) / RAND_MAX;
		if (r < 0.5) {
			AssignSpark_I(m_RefJobSeqArray[m_Map2[PS]], m_SparkSeqArray[PS]);
		}
		else {
			AssignSpark_II(m_RefJobSeqArray[m_Map2[PS]], m_SparkSeqArray[PS]);
		}
		CheckSparks(m_SparkSeqArray[PS]);
		GetSpan(m_RefJobSeqArray[m_Map2[PS]], m_SparkSeqArray[PS], JCTime, m_ObjectArray2[PS], m_FitnessArray2[PS]);
		m_Age2[PS] = 0;
	}
	
}

void CCEA::RandomSlide(vector <int>& JobSeq, vector <int> SparkSeq, vector <double>& Objects)
{

	//int H = 5;
	////���й����ľ������
	//vector<vector<int>>CostMatrix(m_Jobs + 1);
	//for (int j = 0; j < m_Jobs + 1; j++) {
	//	CostMatrix[j].resize(m_Jobs + 1);
	//}
	//GetCostMatrix(CostMatrix, SparkSeq);
	////���ֹ�������
	//vector<int> PartialJobSeq;
	//PartialJobSeq.clear();
	//int RandPoint = rand() % (m_Jobs - H + 1);
	//for (int j = RandPoint; j < RandPoint + H; j++) {
	//	PartialJobSeq.push_back(JobSeq[j]);
	//}
	//int len = PartialJobSeq.size() + 1;

	//vector<vector<int>>PartialCostMatrix(len);
	//for (int j = 0; j < len; j++) {
	//	PartialCostMatrix[j].resize(len);
	//}

}

void CCEA::LocalSearch_I(vector <int>&JobSeq, vector <int> SparkSeq, vector <double>& Objects) 
{
	int H = 5;
	//���й����ľ������
	vector<vector<int>>CostMatrix(m_Jobs+1);
	for (int j = 0; j < m_Jobs+1; j++) {
		CostMatrix[j].resize(m_Jobs+1);
	}
	GetCostMatrix(CostMatrix, SparkSeq);
	
	vector <int>TempJobSeq = JobSeq;
	vector<vector<int>> TempJCTime(m_Jobs);
	for (int j = 0; j < TempJCTime.size(); j++)
		TempJCTime[j].resize(2, 0);
	vector<double>TemObjects = Objects;
	
	if (m_Jobs > H) 
	{
		//���ֹ�������
		vector<int> PartialJobSeq;
		PartialJobSeq.clear();
		int RandPoint = rand() % (m_Jobs - H + 1);
		for (int j = RandPoint; j < RandPoint + H; j++) {
			PartialJobSeq.push_back(TempJobSeq[j]);
		}
		int len = PartialJobSeq.size() + 1;
		vector<vector<int>>PartialCostMatrix(len);
		for (int j = 0; j < len; j++) {
			PartialCostMatrix[j].resize(len);
		}

		//���ֹ������е�ͷ����β��
		int head, tail;
		if (RandPoint == 0) {
			head = -1;
		}
		else {
			head = TempJobSeq[RandPoint - 1];
		}
		if (RandPoint == m_Jobs - H) {
			tail = m_Jobs;
		}
		else {
			tail = TempJobSeq[RandPoint + H];
		}

		for (int i = 0; i < len; i++)PartialCostMatrix[i][i] = RAND_MAX;
		//����famseq�е�fam����head�ľ���
		for (int i = 1; i < len; i++) {
			if (head == -1) {
				PartialCostMatrix[0][i] = CostMatrix[0][PartialJobSeq[i - 1] + 1];
			}
			else {
				PartialCostMatrix[0][i] = CostMatrix[head + 1][PartialJobSeq[i - 1] + 1];
			}
		}
		//����famseq�е�fam���ص�head�ľ���
		for (int i = 1; i < len; i++) {
			if (tail == m_Jobs) {
				PartialCostMatrix[i][0] = CostMatrix[PartialJobSeq[i - 1] + 1][0];
			}
			else {
				PartialCostMatrix[i][0] = CostMatrix[PartialJobSeq[i - 1] + 1][tail + 1];
			}
		}
		//����famseq�е�һ��fam����һ��fam�ľ���
		for (int i = 0; i < len - 1; i++) {
			for (int j = 0; j < len - 1; j++) {
				if (i != j) {
					PartialCostMatrix[i + 1][j + 1] = CostMatrix[PartialJobSeq[i] + 1][PartialJobSeq[j] + 1];
				}
			}
		}

		vector<int>OptimalRing = ATSP(PartialCostMatrix);
		OptimalRing.erase(OptimalRing.begin());
		for (int i = 0; i < len-1; i++)OptimalRing[i]--;
		int start = 0;
		for (int j = RandPoint; j < RandPoint + H; j++) {
			TempJobSeq[j] = PartialJobSeq[OptimalRing[start]];
			start++;
		}
		GetObjects(TempJobSeq, SparkSeq, TempJCTime, TemObjects);
	
	}
	else {
	
		vector<int>OptimalRing = ATSP(CostMatrix);
		OptimalRing.erase(OptimalRing.begin());
		for (int i = 0; i < m_Jobs; i++)OptimalRing[i]--;	
		TempJobSeq = OptimalRing;
		GetObjects(TempJobSeq, SparkSeq, TempJCTime, TemObjects);
	
	}

	if (TemObjects[0] < Objects[0])
	{
		JobSeq = TempJobSeq;
		Objects = TemObjects;
		
	}
	
}

void CCEA::LocalSearch_II(vector <int>& JobSeq, vector <int> SparkSeq, vector <double>& Objects)
{

	int H = 5;
	//���й����ľ������
	vector<vector<int>>CostMatrix(m_Jobs + 1);
	for (int j = 0; j < m_Jobs + 1; j++) {
		CostMatrix[j].resize(m_Jobs + 1);
	}
	GetCostMatrix(CostMatrix, SparkSeq);

	for (int i = 0; i < m_Jobs + 1; i++) 
	{
		for (int j = 0; j < m_Jobs + 1; j++)
			cout << CostMatrix[i][j] << " ";
		cout << endl;
	}

	vector <int>TempJobSeq = JobSeq;
	vector<vector<int>> TempJCTime(m_Jobs);
	for (int j = 0; j < TempJCTime.size(); j++)
		TempJCTime[j].resize(2, 0);
	vector<double>TemObjects = Objects;

	if (m_Jobs > H)
	{
		//���ֹ�������
		vector<int> PartialJobSeq;
		PartialJobSeq.clear();
		int RandPoint = rand() % (m_Jobs - H + 1);
		for (int j = RandPoint; j < RandPoint + H; j++) {
			PartialJobSeq.push_back(TempJobSeq[j]);
		}
		int len = PartialJobSeq.size() + 1;
		vector<vector<int>>PartialCostMatrix(len);
		for (int j = 0; j < len; j++) {
			PartialCostMatrix[j].resize(len);
		}

		//���ֹ������е�ͷ����β��
		int head, tail;
		if (RandPoint == 0) {
			head = -1;
		}
		else {
			head = TempJobSeq[RandPoint - 1];
		}
		if (RandPoint == m_Jobs - H) {
			tail = m_Jobs;
		}
		else {
			tail = TempJobSeq[RandPoint + H];
		}

		for (int i = 0; i < len; i++)PartialCostMatrix[i][i] = RAND_MAX;
		//����famseq�е�fam����head�ľ���
		for (int i = 1; i < len; i++) {
			if (head == -1) {
				PartialCostMatrix[0][i] = CostMatrix[0][PartialJobSeq[i - 1] + 1];
			}
			else {
				PartialCostMatrix[0][i] = CostMatrix[head + 1][PartialJobSeq[i - 1] + 1];
			}
		}
		//����famseq�е�fam���ص�head�ľ���
		for (int i = 1; i < len; i++) {
			if (tail == m_Jobs) {
				PartialCostMatrix[i][0] = CostMatrix[PartialJobSeq[i - 1] + 1][0];
			}
			else {
				PartialCostMatrix[i][0] = CostMatrix[PartialJobSeq[i - 1] + 1][tail+1];
			}
		}
		//����famseq�е�һ��fam����һ��fam�ľ���
		for (int i = 0; i < len - 1; i++) {
			for (int j = 0; j < len - 1; j++) {
				if (i != j) {
					PartialCostMatrix[i + 1][j + 1] = CostMatrix[PartialJobSeq[i] + 1][PartialJobSeq[j] + 1];
				}
			}
		}

		vector<int>OptimalRing = ATSPT(PartialCostMatrix);
		OptimalRing.erase(OptimalRing.begin());
		for (int i = 0; i < len - 1; i++)OptimalRing[i]--;
		int start = 0;
		for (int j = RandPoint; j < RandPoint + H; j++) {
			TempJobSeq[j] = PartialJobSeq[OptimalRing[start]];
			start++;
		}
		GetObjects(TempJobSeq, SparkSeq, TempJCTime, TemObjects);

	}
	else {

		vector<int>OptimalRing = ATSPT(CostMatrix);
		OptimalRing.erase(OptimalRing.begin());
		for (int i = 0; i < m_Jobs; i++)OptimalRing[i]--;
		TempJobSeq = OptimalRing;
		GetObjects(TempJobSeq, SparkSeq, TempJCTime, TemObjects);

	}

	if (TemObjects[1] < Objects[1])
	{
		JobSeq = TempJobSeq;
		Objects = TemObjects;
		
	}

}







//20190519-
void CCEA::Evolution()//Evolution2 without ReInitPop;
{

	m_RecordSpan.clear();
	int Record = 1;

	vector<int>JobSeq(m_Jobs), SparkSeq(m_Jobs);
	vector<double>Objects(3,0);
	double fitness = 0;

	vector<vector<int>> JCTime(m_Jobs);
	for (int j = 0; j < JCTime.size(); j++)
		JCTime[j].resize(2, 0);

	while (true)
	{
		//----------Evolution for job Populaiton------------
		for (int PS = 0; PS < m_PS1; PS++) 
		{
		
			JobSeq = m_JobSeqArray[PS];
			int Map1 = rand() % m_RefSize;			
			GetSpan(JobSeq, m_RefSparkSeqArray[Map1], JCTime, Objects, fitness);
			GreedyInsert(JobSeq, m_RefSparkSeqArray[Map1], Objects, fitness);			
			GreedySwap(JobSeq, m_RefSparkSeqArray[Map1], Objects, fitness);

			/*double r = double(rand()) / RAND_MAX;
			if (r < 0.1)
				LocalSearch_I(JobSeq, m_RefSparkSeqArray[Map1], Objects, fitness);*/

			if (((!m_bFlag2[m_Map1[PS]]) && (fitness < m_FitnessArray1[PS])) || (m_bFlag2[m_Map1[PS]]))
			{
				m_FitnessArray1[PS] = fitness;
				m_ObjectArray1[PS] = Objects;
				m_JobSeqArray[PS] = JobSeq;
				m_Map1[PS] = Map1;				
				m_Age1[PS] = 0;			
			}
			//Update RefSet;
			if (fitness < m_RefFitnessArray[Map1])
			{
				m_RefFitnessArray[Map1] = fitness;
				m_RefObjectArray[Map1] = Objects;
				m_RefJobSeqArray[Map1] = JobSeq;
				m_bFlag1[Map1] = true;
			}
			m_Age1[PS]++;		
		}
		/*int MinTFTEC = INT_MAX, TempTFTEC,index=-1;
		for (int PS = 0; PS < m_PS1; PS++)
		{
			TempTFTEC=m_ObjectArray1[PS][1] + m_ObjectArray1[PS][2];
			if (TempTFTEC < MinTFTEC) 
			{
				MinTFTEC = TempTFTEC;
				index = PS;			
			}
		}
		LocalSearch(m_JobSeqArray[index], m_RefSparkSeqArray[m_Map1[index]], m_ObjectArray1[index], m_FitnessArray1[index]);*/


		//Reset m_bFlag2; 
		for (int PS = 0; PS < m_RefSize; PS++)
			m_bFlag2[PS] = false;

		//------------Evolution for spark populaiton -----------
		for (int PS = 0; PS < m_PS2; PS++)
		{
			SparkSeq = m_SparkSeqArray[PS];
			int Map2 = rand() % m_RefSize;//form a solution by randomly selecting a ReFacFamseq	
			double r = double(rand()) / RAND_MAX;
			if(r<0.5)
				RandAssignSpark(m_RefJobSeqArray[Map2], SparkSeq);
			else
				AlignmentSpark(m_RefJobSeqArray[Map2], SparkSeq);
			CheckSparks(SparkSeq);
			GetSpan(m_RefJobSeqArray[Map2], SparkSeq, JCTime, Objects, fitness);
			

			//1: The original Maping Reference FamSeq is not changed; 2. Changed. reset corresponding relations
			if (((!m_bFlag1[m_Map2[PS]]) && (fitness < m_FitnessArray2[PS])) || (m_bFlag1[m_Map1[PS]]))//Update solution
			{
				m_FitnessArray2[PS] = fitness;
				m_ObjectArray2[PS] = Objects;
				m_SparkSeqArray[PS] = SparkSeq;
				m_Map2[PS] = Map2;							
				m_Age2[PS] = 0;
			}
			m_Age2[PS]++;

			//Update RefSet;
			if (fitness < m_RefFitnessArray[Map2])
			{
				m_RefFitnessArray[Map2] = fitness;
				m_RefObjectArray[Map2] = Objects;
				m_RefSparkSeqArray[Map2] = SparkSeq;
				m_bFlag2[Map2] = true;
			}
			m_Age2[PS]++;

		}
		//Reset m_bFlag1;
		for (int PS = 0; PS < m_RefSize; PS++)
			m_bFlag1[PS] = false;
		
		ReInitPop();

		long CurTime = GetElapsedProcessTime();
		long ElapsedTime = CurTime - m_InitTime;
		if (ElapsedTime >= m_TimeLimit) break;
		/*cout << "Ŀ��ֵ��" << endl;
		printobject(m_RefObjectArray);*/

		for (int i = 0; i < m_PS1; i++)
		{
			m_solutions.push_back(Solution(m_ObjectArray1[i], m_JobSeqArray[i], m_RefSparkSeqArray[m_Map1[i]]));
			m_AllSolObjects.push_back(m_ObjectArray1[i]);
		}

		for (int i = 0; i < m_PS2; i++)
		{
			m_solutions.push_back(Solution(m_ObjectArray2[i], m_RefJobSeqArray[m_Map2[i]], m_SparkSeqArray[i]));
			m_AllSolObjects.push_back(m_ObjectArray2[i]);
		}

		for (int i = 0; i < m_RefSize; i++) 
		{
			m_solutions.push_back(Solution(m_RefObjectArray[i], m_RefJobSeqArray[i], m_RefSparkSeqArray[i]));
			m_AllSolObjects.push_back(m_RefObjectArray[i]);
		}
		
	}

	vector<int>indexs=removeDuplicateRows(m_AllSolObjects);
	for (int i=0;i<indexs.size();i++)
	{	
		m_uniquesolutions.push_back(m_solutions[indexs[i]]);
	}
	m_nonDominatedSolutions = findNonDominatedSolutions(m_uniquesolutions);
	
}

void CCEA::SaveNS(int CPUFactor,int ins,int Rep)
{

	ofstream ofile;
	ostringstream ostr;

	ofstream ofile_I;
	ostringstream ostr_I;

	ostr.str("");
	ostr_I.str("");
	ostr.clear();
	ostr_I.clear();

	ostr << ".\\Results\\DetailCCEA_" << CPUFactor << "_" << ins << "_" << Rep + 1 << ".txt";
	ofile.open(ostr.str());

	if (!ofile.is_open()) {
		std::cerr << "Failed to open file: " << ostr.str() << std::endl;

	}

	ostr_I << ".\\Results\\ATSPCCEA_" << CPUFactor << "_" << ins << "_" << Rep + 1 << ".txt";
	ofile_I.open(ostr_I.str());

	if (!ofile_I.is_open()) {
		std::cerr << "Failed to open file: " << ostr_I.str() << std::endl;

	}
	vector<vector<int>> JCTime(m_Jobs);
	for (int j = 0; j < JCTime.size(); j++)
		JCTime[j].resize(2, 0);
	vector<double>objects(3, 0), tmepobjects(3, 0);
	vector<int>seq1, seq2;
	cout << "Non-dominated solutions: \n";
	for (const auto& sol : m_nonDominatedSolutions) {

		objects = sol.objectives;
		seq1 = sol.jobseq;
		seq2 = sol.sparkseq;
		/*seq1 = { 0, 3, 4, 1, 2};
		seq2 = { 2, 5, 8, 1, 3 };*/
		GetObjects(seq1, seq2, JCTime, tmepobjects);
		for (int i : seq1) {
			cout << i << " ";
			ofile << i << " ";
		}
		cout << "\t";
		ofile << "\t";

		for (int i : seq2) {
			cout << i << " ";
			ofile << i << " ";
		}
		cout << "\t";
		ofile << "\t";

		cout << "(" << objects[0] << ", " << objects[1] << ", " << objects[2] << ")\n";
		ofile << "(" << objects[0] << ", " << objects[1] << ", " << objects[2] << ")\n";
		ofile_I << objects[0] << " " << objects[1] << " " << objects[2] << "\n";
	}
	ofile.flush();
	ofile_I.flush();


	ofile.close();
	ofile_I.close();

}



void CCEA::RunEvolution_OneConf(int CPUFactor, int Reps) //the same as Evolution2 except only one Reference, 
{
	
	int RefSize = 5; 
	int PS1 = 10;
	int PS2 = 10;
	int AgeLimit = 5;
	int DesLen = 4;
	//double Rate = 1.0;
	int Instances = 100;
	vector<vector<int>> RefPoints;
	RefPoints.clear();
	for (int ins = 0; ins <= Instances; ins++)
	{
		ReadInstance(ins);
		for(int Rep=0; Rep< Reps; Rep++){
			srand(ins * 100 + Rep);		
			long StartTime_Ins = ::GetElapsedProcessTime();
			SetParameters(RefSize, PS1, PS2, AgeLimit, DesLen, CPUFactor*m_Bays* m_Rows*m_Jobs);
			RefPointEst();
			
			//RefPoints.push_back(m_RefPoints);
			InitPop();
			Evolution();
			SaveNS(CPUFactor, ins, Rep);			
		}	
		
	}
	//SaveRefPoint(RefPoints);
	
}

void CCEA::SaveRefPoint(vector<vector<int>> RefPoints) {

	ofstream ofile;
	ostringstream ostr;
	ostr.str("");
	ostr.clear();
	//ostr << ".\\Results\\û�м�ֵ�����Ĳο���.txt";
	ostr << ".\\Results\\�ο���.txt";
	ofile.open(ostr.str());
	for (int i = 0; i < RefPoints.size(); i++) {
		for (int j = 0; j < 3; j++) {		
			ofile << RefPoints[i][j] << " ";
		}
		ofile << endl;
	}
}


