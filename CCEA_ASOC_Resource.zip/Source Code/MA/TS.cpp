#include "stdafx.h"
#include "TS.h"
const int INF = 0x3f3f3f3f;
#define sqr(x) ((x)*(x))
#define eps 1e-8
#define percent 0.99
#define MAX_ITERATION 10000
TS::TS()
{
}

TS::~TS()
{
}
void TS::SetParameters(int DesLen, long TimeLimit) //PS1>RefSize; PS2>RefSize;
{
	
	m_TSLen = DesLen;
	m_TimeLimit = TimeLimit;
	m_InitTime = GetElapsedProcessTime();	
	m_solutions.clear();
	m_uniquesolutions.clear();
	m_AllSolObjects.clear();
	m_nonDominatedSolutions.clear();
}

void TS::InitSolution()
{
	//��ʼ�����ɱ�
	m_TabuList.resize(m_Jobs);
	for (int i = 0; i < m_Jobs; ++i) {
		m_TabuList[i].resize(m_Jobs); 
		for (int j = 0; j < m_Jobs; ++j) {
			m_TabuList[i][j] = -m_TSLen; 
		}
	}
	
	
	vector<int>JobSeq(m_Jobs), SparkSeq(m_Jobs);
	vector<double>Objects(3, 0);
	vector<vector<int>> JCTime(m_Jobs);
	for (int j = 0; j < JCTime.size(); j++)
		JCTime[j].resize(2, 0);
	double fitness = 0;
	SortJob(1, JobSeq);
	double r = double(rand()) / RAND_MAX;
	if (r < 0.5) {
		AssignSpark_I(JobSeq, SparkSeq);
	}
	else {
		AssignSpark_II(JobSeq, SparkSeq);
	}
	CheckSparks(SparkSeq);
	GetSpanWithoutRefPoint(JobSeq, SparkSeq, JCTime, Objects, fitness);

	m_JobSeq=JobSeq;
	m_SparkSeq= SparkSeq;
	m_Objects= Objects;
	m_Fitness=fitness;
	
	m_BestJobSeq= m_JobSeq;
	m_BestSparkSeq= m_SparkSeq;
	m_BestObjects= m_Objects;
	m_BestFitness = m_Fitness;

}

//20190519-
void TS::Evolution()//Evolution2 without ReInitPop;
{

	m_RecordSpan.clear();
	int Record = 1;

	vector<int>JobSeq(m_Jobs), SparkSeq(m_Jobs);
	vector<double>Objects(3, 0), TempObjects(3, 0);
	double fitness = 0, tempfit=0;

	vector<vector<int>> JCTime(m_Jobs);
	for (int j = 0; j < JCTime.size(); j++)
		JCTime[j].resize(2, 0);
	
	JobSeq = m_JobSeq;
	SparkSeq = m_SparkSeq;
	Objects = m_Objects;
	fitness = m_Fitness;
	int round = 0;
	while (true)
	{
		if (round % 50 == 0) 
		{
			double r = double(rand()) / RAND_MAX;
			if (r < 0.5) {
				AssignSpark_I(JobSeq, SparkSeq);
			}
			else {
				AssignSpark_II(JobSeq, SparkSeq);
			}
			GetSpanWithoutRefPoint(JobSeq, SparkSeq, JCTime, Objects, fitness);
		
		}
		
	
		double delta = 0, MIN = INF;
		int r = 0, s = 0;
		for (int i = 0; i < m_Jobs; i++) 
		{
			for (int j = 0; j < m_Jobs; j++) 
			{
				if (i != j)	
				{
					vector <int> TemJobSeq = JobSeq;
					int Job = TemJobSeq[i];
					TemJobSeq[i] = TemJobSeq[j];
					TemJobSeq[j] = Job;
					GetSpanWithoutRefPoint(TemJobSeq, SparkSeq, JCTime, TempObjects, tempfit);
					if (m_TabuList[i][j] + m_TSLen > round && tempfit >= m_BestFitness) continue;
					if (tempfit < MIN) {
						MIN = tempfit;
						r = i;
						s = j;
					}				
				}		
			}	
		}
		m_TabuList[r][s] = round;//���½��ɱ� 
		int Job = JobSeq[r];
		JobSeq[r] = JobSeq[s];
		JobSeq[s] = Job;
		GetSpanWithoutRefPoint(JobSeq, SparkSeq, JCTime, Objects, fitness);
		if (fitness < m_BestFitness) 
		{
			m_BestFitness = fitness;
			m_BestJobSeq = JobSeq;
			m_BestSparkSeq = SparkSeq;
			m_BestObjects = Objects;
			m_BestFitness = fitness;
		}

		long CurTime = GetElapsedProcessTime();
		long ElapsedTime = CurTime - m_InitTime;
		if (ElapsedTime >= m_TimeLimit) break;
				
		m_solutions.push_back(Solution(Objects, JobSeq, SparkSeq));
		m_AllSolObjects.push_back(Objects);
		round++;

	}
	cout << round<<endl;
	vector<int>indexs = removeDuplicateRows(m_AllSolObjects);
	for (int i = 0; i < indexs.size(); i++)
	{
		m_uniquesolutions.push_back(m_solutions[indexs[i]]);
	}
	m_nonDominatedSolutions = findNonDominatedSolutions(m_uniquesolutions);
}

void TS::RunEvolution_OneConf(int CPUFactor, int Reps) //the same as Evolution2 except only one Reference, 
{
	/*ofstream ofile;
	ostringstream ostr;
	ostr.str("");	
	ostr.clear();
	ostr << "������ģ.txt";
	ofile.open(ostr.str());*/
	//double Rate = 1.0;
	int Instances = 100;	
	for (int ins = 60; ins <= Instances; ins++)
	{
		ReadInstance(ins);
		//ofile << m_Bays << ", " << m_Rows << ", " << m_Jobs <<"\n";
		int DesLen = (int)(m_Jobs * percent);
		for (int Rep = 0; Rep < Reps; Rep++) {
			srand(ins * 100 + Rep);
			long StartTime_Ins = ::GetElapsedProcessTime();
			SetParameters(DesLen, CPUFactor * m_Bays * m_Rows * m_Jobs);
			InitSolution();
			Evolution();
			SaveNS(CPUFactor, ins, Rep);
		}

	}

}

void TS::SaveNS(int CPUFactor, int ins, int Rep)
{

	ofstream ofile;
	ostringstream ostr;

	ofstream ofile_I;
	ostringstream ostr_I;

	ostr.str("");
	ostr_I.str("");
	ostr.clear();
	ostr_I.clear();

	ostr << ".\\Results\\DetailTS_" << CPUFactor << "_" << ins << "_" << Rep + 1 << ".txt";
	ofile.open(ostr.str());

	if (!ofile.is_open()) {
		std::cerr << "Failed to open file: " << ostr.str() << std::endl;

	}

	ostr_I << ".\\Results\\TwoTS_" << CPUFactor << "_" << ins << "_" << Rep + 1 << ".txt";
	ofile_I.open(ostr_I.str());

	if (!ofile_I.is_open()) {
		std::cerr << "Failed to open file: " << ostr_I.str() << std::endl;

	}
	vector<vector<int>> JCTime(m_Jobs);
	for (int j = 0; j < JCTime.size(); j++)
		JCTime[j].resize(2, 0);
	vector<double>objects(3, 0), tmepobjects(3, 0);
	vector<int>seq1, seq2;
	cout << "Non-dominated solutions: \n";
	for (const auto& sol : m_nonDominatedSolutions) {

		objects = sol.objectives;
		seq1 = sol.jobseq;
		seq2 = sol.sparkseq;
		/*seq1 = { 0, 3, 4, 1, 2};
		seq2 = { 2, 5, 8, 1, 3 };*/
		GetObjects(seq1, seq2, JCTime, tmepobjects);
		for (int i : seq1) {
			cout << i << " ";
			ofile << i << " ";
		}
		cout << "\t";
		ofile << "\t";

		for (int i : seq2) {
			cout << i << " ";
			ofile << i << " ";
		}
		cout << "\t";
		ofile << "\t";

		cout << "(" << objects[0] << ", " << objects[1] << ", " << objects[2] << ")\n";
		ofile << "(" << objects[0] << ", " << objects[1] << ", " << objects[2] << ")\n";
		ofile_I << objects[0] << " " << objects[1] << " " << objects[2] << "\n";
	}
	ofile.flush();
	ofile_I.flush();


	ofile.close();
	ofile_I.close();

}
