#pragma once
#include "Heu.h"
class IG :
	public Heu
{
public:
	IG();
	virtual ~IG();
	void RunEvolution_OneConf(int CPUFactor, int Rep);

private:
	vector<int>m_JobSeq;
	vector<int>m_SparkSeq;
	vector<double>m_Objects;
	double m_Fitness;

	vector<int>m_BestJobSeq;
	vector<int>m_BestSparkSeq;
	vector<double>m_BestObjects;
	double m_BestFitness;

	int m_DesLen;
	int m_H;
	vector<vector<int>>m_TabuList;
	long m_InitTime;
	long m_TimeLimit;
	vector<int> m_RecordSpan;


	vector<Solution> m_solutions;
	vector<Solution> m_uniquesolutions;
	vector<vector<double>>m_AllSolObjects;
	vector<Solution> m_nonDominatedSolutions;

private:
	void SetParameters(int DesLen, long TimeLimit); 
	void RefPointEst();
	void ExtremeLocalSearch_I(vector <int>& JobSeq, vector <int> SparkSeq, vector <double>& Objects);
	void ExtremeLocalSearch_II(vector <int>& JobSeq, vector <int> SparkSeq, vector <double>& Objects);
	
	void FitLocalSearch_I(vector <int>& JobSeq, vector <int> SparkSeq, vector <double>& Objects,double& Fitness);
	void FitLocalSearch_II(vector <int>& JobSeq, vector <int> SparkSeq, vector <double>& Objects, double& Fitness);
	
	void IGreedyInsert(vector <int>& JobSeq, vector <int> SparkSeq, vector <double>& Objects, double& fitness);
	void IGreedySwap(vector <int>& JobSeq, vector <int> SparkSeq, vector <double>& Objects, double& fitness);
	
	void InitSolution();
	double FromObjToFit(vector <double>Objects);
	int Destruction_Construction(vector<int>& JobSeq, vector<int> SparkSeq, vector<double>& Objects);
	vector<Solution> GetNondominatedSet();
	void Evolution();
	void SaveNS(int CPUFactor, int ins, int Rep);
};
