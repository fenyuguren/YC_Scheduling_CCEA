#pragma once
#include "stdafx.h"
class Problem
{
public:
	//void GenerateInstance();
	//void ReadInstanceFileNameList(string Dir);
	void ReadInstance(int InsNo);
	Problem();
	virtual ~Problem();
	
public:
	int numObjectives;
	int p_boundary;
	double* idealpoint;
	// Nadir point used normalization
	double* nadirpoint;

	int m_Bays;
	int m_Rows;
	int m_Jobs;
	
	vector<int> m_RT;
	vector<char> m_Type;
	vector<vector<int>> m_JobCoord;

	vector<int> m_Startbay;
	vector<int> m_Finalbay;
	vector<vector<int>> m_BayCoord;
	vector<int> overflag;

	int m_Records;
	vector<vector<int>> m_JPT;
	vector<vector<int>> m_JJT;
	vector<vector<int>> m_PPT;
	
	// A Solution
	vector <vector <int>> m_JobSeq; //Family sequence
	vector <vector <int>> m_ParkSeq;//Job sequence in each Family
	vector<int> m_RefPoints;
	//Best Solution;
	//vector <int> m_bestSeqofSet;
	vector<int> m_bestJobSeq;
	vector<int> m_bestParkSeq;
	int m_bestSpan,m_bestTFT,m_bestEC;
	
	void Getm_BayCoord();
	void Getm_JPT();
	void Getm_JJT();
	void Getm_PPT();
	
	//vector<vector<int>> m_JobsinEachFamily; // Jobs in each Family
	//vector<vector<int>> m_JobOperPTime; // operation time for each job
	//vector<vector<vector<int>>> m_SetupTime; //setup time between Families
	//vector<string> m_InstanceFileNameList;
	//vector<int> m_JobTotalPTime; //all the operation times for a job;
	//vector<int> m_JobWeightTotalPTime; //all the operation times for a job;


	//vector<int> m_FamTotalPTime; // all the operation times for the jobs in a Family
	//vector<int> m_FamWeightTotalPTime; // all the operation times for the jobs in a Family
	//vector<int> m_FamTotalPTimeOnFirstMachine;
	//vector<int> m_FamTotalPTimeOnLastMachine;

	//vector<vector<int>> m_FammaxSetupTime; //setup time between Families
	//vector<double> m_FamAvgSetupTime; //average all the setup times for Families
	//vector<double> m_FamAvgmaxSetupTime;//average all the max setup times for Families
	//
	//									// A Solution
	//vector <vector <int>> m_FamSeq; //Family sequence
	//vector <vector <int>> m_JobSeqinFam;//Job sequence in each Family

	////Best Solution;
	//vector <int> m_bestSeqofSet;
	//vector<vector<int>> m_bestFamSeq;
	//vector<vector<int>> m_bestJobSeqinFam;
	//int m_bestSpan;

	/*void GetJobTotalPTime();
	void GetJobWeightTotalPTime();
	void GetFamTotalPTime();
	void GetFamWeightTotalPTime();
	void GetFamTotalPTimeOnFirstMachine();
	void GetFamTotalPTimeOnLastMachine();
	void GetFamAvgSetupTime();
	void GetFammaxSetupTime();
	void GetFamAvgmaxSetupTime();*/
};

