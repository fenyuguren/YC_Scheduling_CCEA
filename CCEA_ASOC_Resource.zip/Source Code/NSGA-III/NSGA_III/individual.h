#ifndef INDIVIDUAL_H_
#define INDIVIDUAL_H_
#include "Heu.h"
//#include "global.h"
//#include "fobjective.h"
#include "stdafx.h"

class TIndividual 
{
public:
	vector<int>JobSeqIndividual;
	vector<int>SparkSeqIndividual;
	vector<double> objectives;	
	vector<double> n_obj; // normalized objectives

	TIndividual();
	virtual ~TIndividual();
	TIndividual(vector <int>JobSeq, vector <int>SparkSeq, vector <double>& Objects);
	/*void init_individual();
	void eval_objective();
	void norm_objective();*/

	bool operator<(const TIndividual &ind2);
	bool operator==(const TIndividual &ind2);
	void operator=(const TIndividual &ind2);

	void show_objective();
	void show_variable();	
	
};


/* ******************************************************************
 * TParetofronts class
 * ******************************************************************/

class TParetofront
{
public:
	TParetofront() {};
	virtual ~TParetofront() {};

	typedef vector<int> TPFront;
	typedef vector<TPFront> TPfronts;
};

#endif /* INDIVIDUAL_H_ */
