
#include "Problem.h"


Problem::Problem()
{
	m_Records = 10;
}

Problem::~Problem()
{
}


void Problem::ReadInstance(int InsNo)
{
	ostringstream FileName;
	FileName << "Instances\\" <<"YC_" << InsNo<< ".txt";	
	ifstream infile;
	infile.open(FileName.str());
	if (!infile)
	{
		cout << "open instance file is error!\t" << FileName.str();
		exit(0);
	}
	
	infile >> m_Bays >> m_Rows>> m_Jobs;
	
	m_RT.clear();
	m_RT.resize(m_Jobs);
	for (int i = 0; i < m_Jobs; i++)
		infile >> m_RT[i];
	
	m_Type.clear();
	m_Type.resize(m_Jobs);
	for(int i = 0; i < m_Jobs; i++)
		infile >> m_Type[i];

	m_JobCoord.clear();
	m_JobCoord.resize(m_Jobs);
	for (int i = 0; i < m_Jobs; i++)
		m_JobCoord[i].resize(2);

	for (int i = 0; i < m_Jobs; i++)
		for(int j=0;j<2;j++)
			infile >> m_JobCoord[i][j];

	infile.close();


	//�����һ�к͵ڶ��л���һ��
	for (int i = 0; i < m_Jobs; i++) 
	{
		int temp = m_JobCoord[i][0];
		m_JobCoord[i][0] = m_JobCoord[i][1];
		m_JobCoord[i][1] = temp;	
	}
		

	Getm_BayCoord();
	Getm_JPT();
	Getm_JJT();
	Getm_PPT();
	
}
//�õ���λ����
void Problem::Getm_BayCoord()
{
	m_BayCoord.clear();
	m_BayCoord.resize(2*m_Bays);
	for (int i = 0; i < 2 * m_Bays; i++)
		m_BayCoord[i].resize(2);

	for (int i = 0; i < m_Bays; i++)
	{
		m_BayCoord[i][0] = i;
		m_BayCoord[i][1] = 0;
	}
	for (int i = m_Bays; i < 2*m_Bays; i++)
	{
		m_BayCoord[i][0] = i- m_Bays;
		m_BayCoord[i][1] = m_Rows+1;
	}
	m_Startbay.clear();
	m_Startbay.resize(2);
	m_Startbay[0] = 1;
	m_Startbay[1] = 0;
	m_Finalbay.clear();
	m_Finalbay.resize(2);
	m_Finalbay[0] =m_Bays;
	m_Finalbay[1] = 0;
	/*cout << "��λ���꣺" << endl;
	for (int i = 0; i < 2 * m_Bays; i++)
		cout << m_BayCoord[i][0] << " " << m_BayCoord[i][1] << endl;*/
}

//������ͣ������ʱ��
void Problem::Getm_JPT() 
{
	m_JPT.clear();
	m_JPT.resize(m_Jobs);
	for (int j = 0; j < m_Jobs; j++)
		m_JPT[j].resize(2 * m_Bays);
	
	for (int j = 0; j < m_Jobs; j++) 
	{
		for (int p = 0; p < 2 * m_Bays; p++) 
		{
			//cout<< max(abs(m_JobCoord[j][0] - m_BayCoord[p][0]), abs(m_JobCoord[j][1] - m_BayCoord[p][1]));
			m_JPT[j][p] = max(abs(m_JobCoord[j][0] - m_BayCoord[p][0]), abs(m_JobCoord[j][1] - m_BayCoord[p][1]));
		}
	
	}

}
//������������ʱ��
void Problem::Getm_JJT() 
{
	m_JJT.clear();
	m_JJT.resize(m_Jobs);
	for (int j = 0; j < m_Jobs; j++)
		m_JJT[j].resize(m_Jobs);

	for (int i= 0; i < m_Jobs; i++)
	{
		for (int j= 0; j < m_Jobs; j++)
		{
			if (i != j)
				m_JJT[i][j] = max(abs(m_JobCoord[i][0] - m_JobCoord[j][0]), abs(m_JobCoord[i][1] - m_JobCoord[j][1]));
			else
				m_JJT[i][j] = 0;
		
		}

	}

}
//ͣ������ͣ������ʱ��
void Problem::Getm_PPT() 
{
	m_PPT.clear();
	m_PPT.resize(2*m_Bays);
	for (int j = 0; j < 2 * m_Bays; j++)
		m_PPT[j].resize(2 * m_Bays);


	for (int i = 0; i < 2 * m_Bays; i++)
	{
		for (int j = 0; j < 2 * m_Bays; j++)
		{
			if (i != j)
				m_PPT[i][j] = max(abs(m_BayCoord[i][0] - m_BayCoord[j][0]), abs(m_BayCoord[i][1] - m_BayCoord[j][1]));
			else
				m_PPT[i][j] = 0;			

		}

	}

}


