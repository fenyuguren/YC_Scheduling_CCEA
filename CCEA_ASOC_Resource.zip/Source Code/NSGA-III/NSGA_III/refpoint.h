#ifndef REFPOINT_H_
#define REFPOINT_H_


//#include "global.h"
#include "stdafx.h"
class TRefpoint {
private:
	size_t num_members;			// number of members associated to the point
	vector<pair<size_t, double> > candidate_members; // candidate members

public:
	TRefpoint();
	TRefpoint(size_t M);
	virtual ~TRefpoint();

	vector<double> refpoint; 	// consider to move this to private section

	size_t member_size();
	bool has_candidate_members();
	int get_nearest_member();
	int get_random_member();

	void sum_member();
	void add_member(size_t idx, double distance);
	void remove_member(size_t idx);
	void clear_refpoint();

	void show_rpoint();
};

#endif /* REFPOINT_H_ */
