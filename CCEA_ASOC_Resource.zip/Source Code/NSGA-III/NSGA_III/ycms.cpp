#include "stdafx.h"
#include "Problem.h"
#include "Heu.h"
#include "CCEA.h"
#include "NSGA_III.h"


#pragma comment(lib,"ws2_32.lib") // ��̬��


using namespace Base;
const int Rand_Base = 5;

int _tmain(int argc, _TCHAR* argv[])
{

	/*TNSGA3 NSGA3;
	NSGA3.run(max_gen, run);*/
	//CCEA(10);
	
	NSGA_III nsga_III;
	nsga_III.RunEvolution(10, 5);
	/*CCEA ccea;
	ccea.RunEvolution_OneConf(10,5);*/
	
	return 0;
}

