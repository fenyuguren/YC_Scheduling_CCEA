#include "stdafx.h"
#include "NSGA_III.h"
inline double square(double n) {
	return n * n;
}
NSGA_III::NSGA_III()
{
	popsize = 0;
	idealpoint = new double[numObjectives];
	nadirpoint = new double[numObjectives];
	for (int i = 0; i < numObjectives; i++) {
		idealpoint[i] = MAX_DOUBLE;
		nadirpoint[i] = MIN_DOUBLE;
	}
}

NSGA_III::~NSGA_III()
{
	delete[] idealpoint;
}

void NSGA_III::gen_refpointsND(vector<TRefpoint>* rps, TRefpoint* rp, size_t left, size_t count)
{
	if (count == numObjectives - 1) {
		rp->refpoint[count] = 1.0 * left / p_boundary;
		rps->push_back(*rp);
	}
	else {
		for (size_t i = 0; i <= left; ++i) {
			rp->refpoint[count] = 1.0 * i / p_boundary;
			gen_refpointsND(rps, rp, left - i, count + 1);
		}
	}
}

void NSGA_III::init_refpointsND()
{
	TRefpoint rpoint(numObjectives);
	gen_refpointsND(&refepoints, &rpoint, p_boundary, 0);	
}


void NSGA_III::init_population()
{
	vector<int>JobSeq(m_Jobs), SparkSeq(m_Jobs);
	vector<double>Objects(3, 0);
	for (int PS = 0; PS < popsize; PS++)
	{
		if (PS == 0) {
			SortJob(1, JobSeq);
		}
		else {
			RandSwap(JobSeq);
		}

		double r = double(rand()) / RAND_MAX;
		if (r < 0.5) {
			AssignSpark_I(JobSeq, SparkSeq);
		}
		else {
			AssignSpark_II(JobSeq, SparkSeq);
		}
		CheckSparks(SparkSeq);
		GetObjects(JobSeq, SparkSeq, Objects);
		TIndividual indv(JobSeq, SparkSeq, Objects);
		parent_pop.push_back(indv);
	}
	
}

void NSGA_III::merge_populations()
{
	for (size_t i = 0; i < popsize; ++i)
		mixed_pop.push_back(parent_pop[i]);

	for (size_t i = 0; i < popsize; ++i)
		mixed_pop.push_back(child_pop[i]);

}

TParetofront::TPfronts NSGA_III::nondominatedsort()
{
	int rank = 1, count = 0;
	vector<int> ranks(mixed_pop.size(), 0);
	TParetofront::TPfronts fronts;

	while (count < mixed_pop.size()) {
		TParetofront::TPFront cfront;
		for (size_t i = 0; i < mixed_pop.size(); ++i) {
			if (ranks[i] > 0)
				continue;
			bool isdominated = false;
			for (size_t j = 0; j < cfront.size(); ++j) {
				if (mixed_pop[cfront[j]] < mixed_pop[i]) {
					isdominated = true;
					break;
				}
				else if (mixed_pop[i] < mixed_pop[cfront[j]]) {
					cfront.erase(cfront.begin() + j);
					j = j - 1;
				}
			}
			if (!isdominated) cfront.push_back(i);
		}
		for (size_t i = 0; i < cfront.size(); ++i) ranks[cfront[i]] = rank;
		fronts.push_back(cfront);
		count += cfront.size();
		rank++;
	}

	// identify the last front index (fidx)
	int fidx = 0, block = 0;
	while (block < popsize) block += fronts[fidx++].size();

	// remove useless fronts
	fronts.erase(fronts.begin() + fidx, fronts.end());

	return fronts;
}

void NSGA_III::norm_objective(TIndividual & indv)
{
	for (size_t i = 0; i < numObjectives; ++i) {
		if (fabs(nadirpoint[i] - idealpoint[i]) > 10e-10)
			indv.n_obj[i] = (indv.objectives[i] - idealpoint[i]) / (nadirpoint[i] - idealpoint[i]);
		else
			indv.n_obj[i] = (indv.objectives[i] - idealpoint[i]) / 10e-10;
	}
}



void NSGA_III::normalize(TParetofront::TPfronts Fronts) {
	// compute the ideal point
	for (size_t i = 0; i < Fronts[0].size(); ++i) {
		size_t idx = Fronts[0][i];
		for (size_t j = 0; j < numObjectives; ++j) {
			if (mixed_pop[idx].objectives[j] < idealpoint[j])
				idealpoint[j] = mixed_pop[idx].objectives[j];
		}
	}
	// compute the Nadir point
	for (size_t i = 0; i < Fronts.size(); ++i) {
		for (size_t j = 0; j < Fronts[i].size(); ++j) {
			size_t idx = Fronts[i][j];
			for (size_t k = 0; k < numObjectives; ++k) {
				if (mixed_pop[idx].objectives[k] > nadirpoint[k])
					nadirpoint[k] = mixed_pop[idx].objectives[k];
			}
		}
	}
	// Normalize objectives
	for (size_t i = 0; i < Fronts.size(); ++i)
		for (size_t j = 0; j < Fronts[i].size(); ++j)
			norm_objective(mixed_pop[Fronts[i][j]]);
}

double NSGA_III::perpendicular_distance(vector<double> rpoint, vector<double> solution)
{
	double numerator = 0, denominator = 0;
	for (int i = 0; i < rpoint.size(); i++) {
		numerator += rpoint[i] * solution[i];
		denominator += square(rpoint[i]);
	}
	double k = numerator / denominator;

	double dist = 0;
	for (int i = 0; i < rpoint.size(); i++) {
		dist += square(k * rpoint[i] - solution[i]);
	}
	return sqrt(dist);
}


void NSGA_III::associate(TParetofront::TPfronts Fronts)
{
	for (size_t i = 0; i < refepoints.size(); ++i)
		refepoints[i].clear_refpoint();

	for (size_t i = 0; i < Fronts.size(); ++i) {
		for (size_t j = 0; j < Fronts[i].size(); ++j) {

			double mindist = MAX_DOUBLE;
			size_t idx = refepoints.size();
			for (size_t r = 0; r < refepoints.size(); ++r) {
				double pdist = perpendicular_distance(refepoints[r].refpoint,
					mixed_pop[Fronts[i][j]].n_obj);
				if (pdist < mindist) {
					mindist = pdist;
					idx = r;
				}
			}
			if (i + 1 == Fronts.size())
				refepoints[idx].add_member(Fronts[i][j], mindist);
			else
				refepoints[idx].sum_member();
		}
	}
}

size_t NSGA_III::find_refpoint(vector<TRefpoint> rpoints, vector<bool> rp_isable)
{
	size_t min_size = MAX_INT;
	for (size_t i = 0; i < rpoints.size(); ++i) {
		if (rp_isable[i]) // if the reference point is has members in last front
			min_size = min(min_size, rpoints[i].member_size());
	}

	vector<size_t> min_rpoints;
	for (size_t i = 0; i < rpoints.size(); ++i)
		if (rpoints[i].member_size() == min_size)
			min_rpoints.push_back(i);

	// return a random reference point
	return min_rpoints[rand() % min_rpoints.size()];
}

int NSGA_III::select_member(TRefpoint rpoint)
{
	int idx = -1;
	if (rpoint.has_candidate_members()) {
		if (rpoint.member_size() == 0)
			idx = rpoint.get_nearest_member();
		else
			idx = rpoint.get_random_member();
	}
	return idx;
}


void NSGA_III::niching()
{
	vector<bool> rp_isable(refepoints.size(), true);
	while (parent_pop.size() < popsize) {

		size_t rp_idx = find_refpoint(refepoints, rp_isable);
		int ind_idx = select_member(refepoints[rp_idx]);

		if (ind_idx < 0) rp_isable[rp_idx] = false;
		else {
			refepoints[rp_idx].sum_member();
			refepoints[rp_idx].remove_member(ind_idx);
			parent_pop.push_back(mixed_pop[ind_idx]);
		}
	}
}



void NSGA_III::evolution()
{
	while (true)
	{
		child_pop.clear(); // clear the child population
		for (size_t i = 0; i < popsize; ++i) {
			TIndividual indi = parent_pop[i];

			vector<int>JobSeq = indi.JobSeqIndividual;
			vector<int>SparkSeq = indi.SparkSeqIndividual;
			vector<double>Objects(3, 0);
			double rr = double(rand()) / RAND_MAX;
			if (rr < 0.5) {
				RandShift(JobSeq);
			}
			else {
				RandSwap(JobSeq);
			}


			double r = double(rand()) / RAND_MAX;
			if (r < 0.5) {
				AssignSpark_I(JobSeq, SparkSeq);
			}
			else {
				AssignSpark_II(JobSeq, SparkSeq);
			}
			CheckSparks(SparkSeq);
			GetObjects(JobSeq, SparkSeq, Objects);

			TIndividual child(JobSeq, SparkSeq, Objects);
			child_pop.push_back(child);
		}

		// mixed_pop: combination of parents and child population
		mixed_pop.clear();
		merge_populations();

		// non-dominated sorting algorithm
		TParetofront::TPfronts Fronts = nondominatedsort();

		//// copy the first F-1 fronts to the next population
		parent_pop.clear();
		for (int i = 0; i < Fronts.size() - 1; ++i)
			for (int j = 0; j < Fronts[i].size(); ++j)
				parent_pop.push_back(mixed_pop[Fronts[i][j]]);

		// finish if the population is complete
		if (parent_pop.size() == popsize) return;

		// normalization of objectives (algorithm 2:normalize function)
		normalize(Fronts);

		//// association of members (algorithm 3: associate function)
		associate(Fronts);

		//// selection of k individual (algorithm 4: niching function)
		niching();
		long CurTime = GetElapsedProcessTime();
		long ElapsedTime = CurTime - m_InitTime;
		if (ElapsedTime >= m_TimeLimit) break;
	}
}
void NSGA_III::save_front(char file_name[512])
{
	std::fstream fout;
	fout.open(file_name, std::ios::out);
	for (size_t i = 0; i < parent_pop.size(); i++) {
		for (int j = 0; j < numObjectives; j++)
			fout << parent_pop[i].objectives[j] << "  ";
		fout << "\n";
	}
	fout.close();
}



void NSGA_III::SaveNS(int CPUFactor, int ins, int Rep)
{
	ofstream ofile;
	ostringstream ostr;
	ostr.str("");
	ostr.clear();
		
	ostr << ".\\Results\\NSGAIII_" << CPUFactor << "_" << ins << "_" << Rep + 1 << ".txt";
	ofile.open(ostr.str());

	if (!ofile.is_open()) {
		std::cerr << "Failed to open file: " << ostr.str() << std::endl;

	}
	vector<double>objects(3, 0), tmepobjects(3, 0);
	vector<int>seq1, seq2;
	//cout << "Non-dominated solutions: \n";
	for (const auto& sol : parent_pop) {

		objects = sol.objectives;
		seq1 = sol.JobSeqIndividual;
		seq2 = sol.SparkSeqIndividual;
		GetObjects(seq1, seq2, tmepobjects);
		if ((tmepobjects[0] == objects[0]) && (tmepobjects[1] == objects[1]) && (tmepobjects[2] == objects[2])) {

			cout << "��ȷ" << endl;
		}
		else {
			cout << "����" << endl;
		}
		
		ofile << objects[0] << " " << objects[1] << " " << objects[2] << "\n";
	}
	
	ofile.flush();
	ofile.close();

}




void NSGA_III::RunEvolution(int CPUFactor, int Reps) //the same as Evolution2 except only one Reference, 
{
	int Instances = 100;
	numObjectives=3;
	p_boundary=12;
	for (int ins = 0; ins <= Instances; ins++)
	{
		ReadInstance(ins);
		for (int Rep = 0; Rep < Reps; Rep++) {
			srand(100 * ins + Rep);
			long StartTime_Ins = ::GetElapsedProcessTime();
			refepoints.clear();
			init_refpointsND();
			popsize = refepoints.size();
			while (popsize % 4) popsize++;
			m_TimeLimit = CPUFactor * m_Bays * m_Rows * m_Jobs;
			m_InitTime = GetElapsedProcessTime();
			init_population();
			evolution();	
			SaveNS(CPUFactor, ins, Rep);
			parent_pop.clear();

		
		}

	}


}
