#include "individual.h"

TIndividual::TIndividual(vector <int>JobSeq, vector <int>SparkSeq, vector <double>& Objects) {
	JobSeqIndividual = JobSeq;
	SparkSeqIndividual = SparkSeq;
	objectives = Objects;
	for (size_t i = 0; i < 3; i++) {
		n_obj.push_back(0.0);
	}
	
}
TIndividual::TIndividual()
{	
	
}

TIndividual::~TIndividual() {}



void TIndividual::operator=(const TIndividual& ind2)
{
	JobSeqIndividual = ind2.JobSeqIndividual;
	SparkSeqIndividual = ind2.SparkSeqIndividual;
	objectives = ind2.objectives;
	n_obj = ind2.n_obj;
}

bool TIndividual::operator<(const TIndividual& ind2)
{
	bool dominated = true;
	for (size_t i = 0; i < 3; i++) {
		if (ind2.objectives[i] < objectives[i])
			return false;
	}
	if (ind2.objectives == objectives)
		return false;
	return dominated;
	
}

bool TIndividual::operator==(const TIndividual& ind2)
{
	if (ind2.objectives == objectives)
		return true;
	else
		return false;
}

void TIndividual::show_objective()
{
	for (size_t i = 0; i < 3; i++)
		printf("%f ", objectives[i]);
	printf("\n");
}

//void TIndividual::show_variable() {
//	for (size_t i = 0; i < m_Jobs; i++)
//		cout << JobSeqIndividual[i] <<" ";
//
//	cout << "  ";
//	for (size_t i = 0; i < m_Jobs; i++)
//		cout << SparkSeqIndividual[i] << " ";
//
//	cout << endl;
//}
