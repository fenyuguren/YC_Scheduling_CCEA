#pragma once
#include "Heu.h"
#include "individual.h"
#include "refpoint.h"
class NSGA_III : Heu
{
public:
	int popsize;	
	long m_InitTime;
	long m_TimeLimit;

	vector<TIndividual> parent_pop;	// parent population
	vector<TIndividual> child_pop;	// child population
	vector<TIndividual> mixed_pop;	// combined population
	vector<TRefpoint> refepoints;

	NSGA_III();
	virtual ~NSGA_III();
	void init_refpointsND();
	void gen_refpointsND(vector<TRefpoint>* rps, TRefpoint* rp, size_t left, size_t count);
	void init_population();
	void evolution();
	void merge_populations();
	TParetofront::TPfronts nondominatedsort();
	void normalize(TParetofront::TPfronts Fronts);
	void norm_objective(TIndividual& indv);
	void associate(TParetofront::TPfronts Fronts);
	double perpendicular_distance(vector<double> rpoint, vector<double> solution);
	void niching();
	void save_front(char file_name[512]);
	void SaveNS(int CPUFactor, int ins, int Rep);
	size_t find_refpoint(vector<TRefpoint> rpoints, vector<bool> rp_isable);
	int select_member(TRefpoint rpoint);
	void RunEvolution(int CPUFactor, int Rep);
};