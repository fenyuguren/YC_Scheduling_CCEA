// Base.h

#pragma once

namespace Base
{
	template <typename T>
	struct Pair
	{
		int dim;
		T value;
	};

	template <typename T>
	struct PairGreater {
		bool operator () (Pair <T> a, Pair <T> b)
		{
			return a.value > b.value;
		}
	};

	template <typename T>
	struct PairLess {
		bool operator () (Pair <T> a, Pair <T> b)
		{
			return a.value < b.value;
		}
	};

	/*void GetInstances_TaiE(int &Jobs, int &Machines, int &Factories, vector<vector<int>> &PTime, string FileName);
	void GetInstances(int& rows, int& bays, int& jobs, vector<int>& RT, vector<vector<int>>& Coordinates, string FileName);*/
	long GetElapsedProcessTime();
	vector<int> removeDuplicateRows(vector<vector<double>>& vec2D);
}


