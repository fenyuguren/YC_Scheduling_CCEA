#include "stdafx.h"
#include "NOperators.h"
#include "Data.h"
#include "gurobi_c++.h"
NOperators::NOperators()
{
}

NOperators::~NOperators()
{
}

bool NOperators::dominates(const Solution& a, const Solution& b) {
	return (a.objectives[0] <= b.objectives[0] && a.objectives[1] <= b.objectives[1] && a.objectives[2] <= b.objectives[2]) &&
		(a.objectives[0] < b.objectives[0] || a.objectives[1] < b.objectives[1] || a.objectives[2] < b.objectives[2]);
}

vector<Solution> NOperators::findNonDominatedSolutions(const vector<Solution>& solutions) {
	vector<Solution> nonDominatedSolutions;

	for (const auto& sol : solutions) {
		bool isDominated = false;

		// ���ý��Ƿ������κν�֧��
		for (const auto& other : solutions) {
			if (dominates(other, sol)) {
				isDominated = true;
				break;
			}
		}

		// ���û�б�֧�䣬������֧��⼯��
		if (!isDominated) {
			nonDominatedSolutions.push_back(sol);
		}
	}

	return nonDominatedSolutions;
}






void NOperators::printobject(vector<vector<int>>pop) {

	for (int i = 0; i < pop.size(); i++) {
		for (int j = 0; j < pop[i].size(); j++) {
			cout << pop[i][j] << " ";
		}
		cout << endl;		
	}	
}


void NOperators::printcanshu() {
	cout << m_Jobs <<"\t"<< m_Bays<<"\t"<<m_Jobs;
	
	for (int i = 0; i < m_Jobs; i++) {
		cout << m_RT[i] << endl;
	}

	for (int i = 0; i < m_Jobs; i++) {
		cout << m_Type[i] << endl;
	}


	for (int i = 0; i < m_Jobs; i++) {
		for (int j = 0; j < 2; j++) {
			cout << m_JobCoord[i][j] << "\t";
		}
		cout << endl;
	}
}

void NOperators::RandSwap(vector<int>& Sol)
{
	int Pos1, Pos2;
	do {
		Pos1 = rand() % Sol.size();
		Pos2 = rand() % Sol.size();
	} while (Pos1 == Pos2);
	int Job = Sol[Pos1];
	Sol[Pos1] = Sol[Pos2];
	Sol[Pos2] = Job;	
}

void NOperators::RandShift(vector<int>& Sol)
{
	int OrigPos, InsPos;
	do {
		OrigPos = rand() % Sol.size();
		InsPos = rand() % Sol.size();
	} while (OrigPos == InsPos);

	int Job = Sol[OrigPos];
	Sol.erase(Sol.begin() + OrigPos);
	Sol.insert(Sol.begin() + InsPos, Job);
	
}

void NOperators::AlignmentSpark(vector<int>JobSeq, vector<int>& SparkSeq)
{
	int pos = rand() % JobSeq.size();
	SparkSeq[JobSeq[pos]] = m_JobCoord[JobSeq[pos]][0];
}

void NOperators::RandAssignSpark(vector<int>JobSeq, vector<int>& SparkSeq)
{
	int pos,CurJob, AfterJob, PreMinBay, p, Upce, Lowce, Ceb, kuadu;
	pos = rand() % (JobSeq.size() - 1);
	CurJob = JobSeq[pos];
	AfterJob= JobSeq[pos+1];

	PreMinBay = min(m_JobCoord[CurJob][0], m_JobCoord[AfterJob][0]);
	kuadu = abs(m_JobCoord[CurJob][0] - m_JobCoord[AfterJob][0]);
	if (kuadu == 0)
		p = PreMinBay + kuadu;
	else
		p = PreMinBay + rand() % kuadu;
	Upce = abs(m_JobCoord[CurJob][1] - m_Rows - 1);
	Lowce = abs(m_JobCoord[CurJob][1] - 0);
	//Ceb = Upce > Lowce ? p : p + m_Bays;
	double r;
	if (Upce > Lowce) {
		r = double(rand()) / RAND_MAX;
		if (r < 0.8) {
			Ceb = p;
		}
		else {

			Ceb = p + m_Bays;
		}	
	}
	else {
	
		r = double(rand()) / RAND_MAX;
		if (r < 0.8) {			
			Ceb = p + m_Bays;
		}
		else {
			Ceb = p;
		}	
	}
	/*if (Ceb == 12)
		cout << "fenpeiyouwu";*/
	SparkSeq[CurJob] = Ceb;

}

void NOperators::AlignmentAllSpark(vector<int>JobSeq, vector<int>& SparkSeq)
{
	for(int pos=0;pos< JobSeq.size();pos++)
		SparkSeq[JobSeq[pos]] = m_JobCoord[JobSeq[pos]][0];
}
//before
void NOperators::AssignSpark_I(vector<int>JobSeq, vector<int>& SparkSeq)
{
	int CurJob, PreJob, PreMinBay, p, Upce, Lowce, Ceb, kuadu;
	for (int i = 0; i < m_Jobs; i++)
	{
		// 5 4 0 2 1 3
		CurJob = JobSeq[i];
		if (i == 0)
		{
			kuadu = abs(m_JobCoord[CurJob][0] - m_Startbay[0]);
			if (kuadu == 0)
				SparkSeq[CurJob] = m_Startbay[0] + kuadu;
			else
				SparkSeq[CurJob] = m_Startbay[0] + rand() % kuadu;
			continue;
		}
	/*	if (i == m_Jobs - 1)
		{
			kuadu = abs(m_JobCoord[CurJob][0] - m_Finalbay[0]);
			if (kuadu == 0)
				SparkSeq[CurJob] = m_Startbay[0] + kuadu - 1;
			else
				SparkSeq[CurJob] = m_Finalbay[0] + rand() % kuadu - 1;
			break;
		}*/
		PreJob = JobSeq[i - 1];
		PreMinBay = min(m_JobCoord[CurJob][0], m_JobCoord[PreJob][0]);
		kuadu = abs(m_JobCoord[CurJob][0] - m_JobCoord[PreJob][0]);
		if (kuadu == 0)
			p = PreMinBay + kuadu;
		else
			p = PreMinBay + rand() % kuadu;
		Upce = abs(m_JobCoord[CurJob][1] - m_Rows - 1);
		Lowce = abs(m_JobCoord[CurJob][1] - 0);
		Ceb = Upce > Lowce ? p : p + m_Bays;

		/*if (Ceb == 12)
			cout << "fenpeiyouwu";*/
		SparkSeq[CurJob] = Ceb;
	}
	
}

//after
void NOperators::AssignSpark_II(vector<int>JobSeq, vector<int>& SparkSeq)
{
	int CurJob, AfterJob, PreMinBay, p, Upce, Lowce, Ceb, kuadu;
	
	for (int i = 0; i < m_Jobs; i++)
	{
		// 5 4 0 2 1 3
		CurJob = JobSeq[i];
		/*	if (i == 0)
			{
				kuadu = abs(m_JobCoord[CurJob][0] - m_Startbay[0]);
				if (kuadu == 0)
					SparkSeq[CurJob] = m_Startbay[0] + kuadu - 1;
				else
					SparkSeq[CurJob] = m_Startbay[0] + rand() % kuadu - 1;
				continue;
			}*/
		if (i == m_Jobs - 1)
		{
			kuadu = abs(m_JobCoord[CurJob][0] - m_Finalbay[0]);
			if (kuadu == 0)
				SparkSeq[CurJob] = m_Startbay[0] + kuadu;
			else
				SparkSeq[CurJob] = m_Finalbay[0] + rand() % kuadu;
			break;
		}

		AfterJob = JobSeq[i + 1];
		PreMinBay = min(m_JobCoord[CurJob][0], m_JobCoord[AfterJob][0]);
		kuadu = abs(m_JobCoord[CurJob][0] - m_JobCoord[AfterJob][0]);

		if (kuadu == 0)
		{
			p = PreMinBay + kuadu;

		}
		else {
			p = PreMinBay + rand() % kuadu;

		}
		Upce = abs(m_JobCoord[CurJob][1] - m_Rows - 1);
		Lowce = abs(m_JobCoord[CurJob][1] - 0);
		Ceb = Upce > Lowce ? p : p + m_Bays;

		//if (Ceb == 12)
		//	cout << "fenpeiyouwu";
		SparkSeq[CurJob] = Ceb;
	}
	
}

void NOperators::CheckSparks( vector<int>& SparkSeq)
{
	int Spark;
	vector <bool>BayArray(2 * m_Bays, false);
	for (int i = 0; i < m_Jobs; i++) {

		Spark = SparkSeq[i];
		while (BayArray[Spark] == true)
		{
			Spark = (Spark + 1) % (2 * m_Bays);
		}
		SparkSeq[i] = Spark;
		BayArray[Spark] = true;
	}
}


double NOperators::FindBestPosToInsertJob_InSeq(vector <int>& JobSeq, vector <int> SparkSeq, int Job, int& bestPos, vector<double>& BestObjects)
{
	double BestFit = INT_MAX;
	vector <int> TempJobSeq = JobSeq;
	vector<double> TempObjects(3);
	double tempfit = 0;
	

	for (int Pos = 0; Pos <= JobSeq.size(); Pos++)
	{
		TempJobSeq.insert(TempJobSeq.begin() + Pos, Job);
		GetSpan(TempJobSeq, SparkSeq,TempObjects, tempfit);
		
		if (tempfit < BestFit)
		{
			BestFit = tempfit;
			BestObjects = TempObjects;
			bestPos = Pos;
		}
		TempJobSeq.erase(TempJobSeq.begin() + Pos);
	}
	return BestFit;//����ֵΪ��ǰ������TotalFlowtime
}



void NOperators::FindJobPos(vector <int>JobSeq, int CurJob, int& Pos)
{
	boolean flag = false;
	for (int j = 0; j< m_Jobs; j++)
	{		
		if (CurJob == JobSeq[j])
		{
			
			Pos =j;
			flag = true;
			break;
		}		
	}
}




double NOperators::FindBestCmaxPosToInsertJob_InSeq(vector <int>& JobSeq, vector <int> SparkSeq, int Job, int& bestPos)
{
	double BestCmax = INT_MAX;
	vector <int> TempJobSeq = JobSeq;
	vector<double> TempObjects(3,0);
	


	for (int Pos = 0; Pos <= JobSeq.size(); Pos++)
	{
		TempJobSeq.insert(TempJobSeq.begin() + Pos, Job);
		GetObjects(TempJobSeq, SparkSeq, TempObjects);

		if (TempObjects[0] < BestCmax)
		{
			BestCmax = TempObjects[0];			
			bestPos = Pos;
		}
		TempJobSeq.erase(TempJobSeq.begin() + Pos);
	}
	return BestCmax;//����ֵΪ��ǰ������TotalFlowtime
}


double NOperators::FindBestTFTPosToInsertJob_InSeq(vector <int>& JobSeq, vector <int> SparkSeq, int Job, int& bestPos)
{
	double BestTFT = INT_MAX;
	vector <int> TempJobSeq = JobSeq;
	vector<double> TempObjects(3);

	for (int Pos = 0; Pos <= JobSeq.size(); Pos++)
	{
		TempJobSeq.insert(TempJobSeq.begin() + Pos, Job);
		GetObjects(TempJobSeq, SparkSeq,TempObjects);

		if (TempObjects[1] < BestTFT)
		{
			BestTFT = TempObjects[1];			
			bestPos = Pos;
		}
		TempJobSeq.erase(TempJobSeq.begin() + Pos);
	}
	return BestTFT;//����ֵΪ��ǰ������TotalFlowtime
}

double NOperators::FindBestECPosToInsertJob_InSeq(vector <int>& JobSeq, vector <int> SparkSeq, int Job, int& bestPos)
{
	double BestEC = INT_MAX;
	vector <int> TempJobSeq = JobSeq;
	vector<double> TempObjects(3);

	

	for (int Pos = 0; Pos <= JobSeq.size(); Pos++)
	{
		TempJobSeq.insert(TempJobSeq.begin() + Pos, Job);
		GetObjects(TempJobSeq, SparkSeq, TempObjects);

		if (TempObjects[2] < BestEC)
		{
			BestEC = TempObjects[2];			
			bestPos = Pos;
		}
		TempJobSeq.erase(TempJobSeq.begin() + Pos);
	}
	return BestEC;//����ֵΪ��ǰ������TotalFlowtime
}

void NOperators::GetSpan(vector <int>JobSeq, vector <int>SparkSeq, vector <double>&Objects, double& fitness)
{
	double Pick = 5, drop = 5, loadperEC = 1.5, uloadperEC = 0.5, startupperEC = 1;
	int cmax = 0, tft = 0; double tec = 0;
	int loadtime = 0, unloadtime = 0, startupcount = 0, sumstartupcount = 0;
	
	overflag.resize(m_Jobs, 0);

	vector<vector<int>> JCTime(m_Jobs);
	for (int j = 0; j < JCTime.size(); j++)
		JCTime[j].resize(2, 0);

	//for (int i = 0; i < m_Jobs; i++) {
	//	int Job = JobSeq[i];
	//	cout << m_Type[Job] << " ";
	//}
	//cout << endl;

	//for (int i = 0; i < m_Jobs; i++) {
	//	int Job = JobSeq[i];
	//	cout << m_RT[Job] << " ";
	//}
	//cout << endl;
	//�����һ�������Ŀ�ʼʱ������ʱ��
	int Job = JobSeq[0];
	if (m_Type[Job] == 'u') {
		JCTime[Job][0] = max(abs(m_JobCoord[Job][0] - m_Startbay[0]), abs(m_JobCoord[Job][1] - m_Startbay[1]));
		unloadtime = unloadtime + JCTime[Job][0];

		JCTime[Job][1] = max(JCTime[Job][0] + Pick + m_JPT[Job][SparkSeq[Job]], m_RT[Job]) + drop;
		loadtime = loadtime + m_JPT[Job][SparkSeq[Job]];

		if (m_BayCoord[SparkSeq[Job]][0] == m_JobCoord[Job][0])startupcount++;
	}
	if (m_Type[Job] == 's') {
		JCTime[Job][0] = max(max(abs(m_BayCoord[SparkSeq[Job]][0] - m_Startbay[0]), abs(m_BayCoord[SparkSeq[Job]][1] - m_Startbay[1])), m_RT[Job]);
		unloadtime = unloadtime + max(abs(m_BayCoord[SparkSeq[Job]][0] - m_Startbay[0]), abs(m_BayCoord[SparkSeq[Job]][1] - m_Startbay[1]));
		
		JCTime[Job][1] = JCTime[Job][0] + Pick + m_JPT[Job][SparkSeq[Job]] + drop;
		loadtime = loadtime + m_JPT[Job][SparkSeq[Job]];

		if (m_BayCoord[SparkSeq[Job]][0] == m_JobCoord[Job][0])startupcount++;
	}

	//�����м乤���Ŀ�ʼʱ������ʱ��
	int len = JobSeq.size();
	for (int i = 1; i < len; i++) {
		int CurJob = JobSeq[i];
		int PreJob = JobSeq[i - 1];
		if ((m_Type[PreJob] == 's') & (m_Type[CurJob] == 's')) {

			JCTime[CurJob][0] = max(JCTime[PreJob][1] + m_JPT[PreJob][SparkSeq[CurJob]], m_RT[CurJob]);
			JCTime[CurJob][1] = JCTime[CurJob][0] + Pick + m_JPT[CurJob][SparkSeq[CurJob]] + drop;
			unloadtime = unloadtime + m_JPT[PreJob][SparkSeq[CurJob]];
			loadtime = loadtime + m_JPT[CurJob][SparkSeq[CurJob]];
			if (m_BayCoord[SparkSeq[CurJob]][0] == m_JobCoord[PreJob][0])startupcount++;
		}

		if ((m_Type[PreJob] == 'u') & (m_Type[CurJob] == 'u')) {

			JCTime[CurJob][0] = JCTime[PreJob][1] + m_JPT[CurJob][SparkSeq[PreJob]];
			JCTime[CurJob][1] = max(JCTime[CurJob][0] + Pick + m_JPT[CurJob][SparkSeq[CurJob]], m_RT[CurJob]) + drop;
			unloadtime = unloadtime + m_JPT[CurJob][SparkSeq[PreJob]];
			loadtime = loadtime + m_JPT[CurJob][SparkSeq[CurJob]];

			if (m_BayCoord[SparkSeq[PreJob]][0] == m_JobCoord[CurJob][0])startupcount++;
		}

		if ((m_Type[PreJob] == 'u') & (m_Type[CurJob] == 's')) {

			JCTime[CurJob][0] = max(JCTime[PreJob][1] + m_PPT[SparkSeq[PreJob]][SparkSeq[CurJob]], m_RT[CurJob]);
			JCTime[CurJob][1] = JCTime[CurJob][0] + Pick + m_JPT[CurJob][SparkSeq[CurJob]] + drop;
			unloadtime = unloadtime + m_PPT[SparkSeq[PreJob]][SparkSeq[CurJob]];
			loadtime = loadtime + m_JPT[CurJob][SparkSeq[CurJob]];

		}

		if ((m_Type[PreJob] == 's') & (m_Type[CurJob] == 'u')) {

			JCTime[CurJob][0] = JCTime[PreJob][1] + m_JJT[PreJob][CurJob];
			JCTime[CurJob][1] = max(JCTime[CurJob][0] + Pick + m_JPT[CurJob][SparkSeq[CurJob]], m_RT[CurJob]) + drop;
			unloadtime = unloadtime + m_JJT[PreJob][CurJob];
			loadtime = loadtime + m_JPT[CurJob][SparkSeq[CurJob]];
		}
		if (m_JobCoord[CurJob][0] == m_BayCoord[SparkSeq[CurJob]][0])
			startupcount++;

	}

	//����YC���Ŀ�ʼʱ������ʱ��
	Job = JobSeq.back();
	if (m_Type[Job] == 'u') {

		cmax = JCTime[Job][1] + max(abs(m_BayCoord[SparkSeq[Job]][0] - m_Finalbay[0]), abs(m_BayCoord[SparkSeq[Job]][1] - m_Finalbay[1]));
		unloadtime = unloadtime + max(abs(m_BayCoord[SparkSeq[Job]][0] - m_Finalbay[0]), abs(m_BayCoord[SparkSeq[Job]][1] - m_Finalbay[1]));
		if (m_JobCoord[Job][0] == m_BayCoord[SparkSeq[Job]][0])startupcount++;
	}
	if (m_Type[Job] == 's') {

		cmax = JCTime[Job][1] + max(abs(m_JobCoord[Job][0] - m_Finalbay[0]), abs(m_JobCoord[Job][1] - m_Finalbay[1]));
		unloadtime = unloadtime + max(abs(m_JobCoord[Job][0] - m_Finalbay[0]), abs(m_JobCoord[Job][1] - m_Finalbay[1]));
	}

	for (int i = 0; i < m_Jobs; i++) {
		tft = tft + JCTime[i][1];
	}
	sumstartupcount = 2 * m_Jobs + 1 - startupcount;
	tec = loadperEC * loadtime + uloadperEC * unloadtime + sumstartupcount * startupperEC;
	Objects[0] = cmax;
	Objects[1] = tft;
	Objects[2] = tec;

	fitness = (cmax - m_RefPoints[0]) + (tft - m_RefPoints[1]) + (tec - m_RefPoints[2]);

	//for (int i = 0; i < len; i++) {
	//
	//	Job = JobSeq[i];
	//	cout<<JCTime[Job][0] <<" "<< JCTime[Job][1] << endl;
	//	if (m_Type[Job] == 'u') 
	//	{
	//		if (JCTime[Job][1] - drop > m_RT[Job])
	//			overflag[Job] = 1;
	//	}
	//	if (m_Type[Job] == 's')
	//	{
	//		if (JCTime[Job][0] > m_RT[Job])
	//			overflag[Job] = 1;
	//	}
	//	/*cout << overflag[Job];*/
	//
	//}

}




void NOperators::GetObjects(vector <int>JobSeq, vector <int>SparkSeq, vector <double>&Objects)
{
	double Pick = 5, drop = 5, loadperEC = 1.5, uloadperEC = 0.5, startupperEC = 1;
	int cmax = 0, tft = 0; double tec = 0;
	int loadtime = 0, unloadtime = 0, startupcount = 0, sumstartupcount = 0;

	vector<vector<int>> JCTime(m_Jobs);
	for (int j = 0; j < JCTime.size(); j++)
		JCTime[j].resize(2, 0);
	//�����һ�������Ŀ�ʼʱ������ʱ��
	int Job = JobSeq[0];
	if (m_Type[Job] == 'u') {
		JCTime[Job][0] = max(abs(m_JobCoord[Job][0] - m_Startbay[0]), abs(m_JobCoord[Job][1] - m_Startbay[1]));
		unloadtime = unloadtime + JCTime[Job][0];

		JCTime[Job][1] = max(JCTime[Job][0] + Pick + m_JPT[Job][SparkSeq[Job]], m_RT[Job]) + drop;
		loadtime = loadtime + m_JPT[Job][SparkSeq[Job]];

		if (m_BayCoord[SparkSeq[Job]][0] == m_JobCoord[Job][0])startupcount++;
	}
	if (m_Type[Job] == 's') {
		JCTime[Job][0] = max(max(abs(m_BayCoord[SparkSeq[Job]][0] - m_Startbay[0]), abs(m_BayCoord[SparkSeq[Job]][1] - m_Startbay[1])), m_RT[Job]);
		unloadtime = unloadtime + max(abs(m_BayCoord[SparkSeq[Job]][0] - m_Startbay[0]), abs(m_BayCoord[SparkSeq[Job]][1] - m_Startbay[1]));

		JCTime[Job][1] = JCTime[Job][0] + Pick + m_JPT[Job][SparkSeq[Job]] + drop;
		loadtime = loadtime + m_JPT[Job][SparkSeq[Job]];

		if (m_BayCoord[SparkSeq[Job]][0] == m_JobCoord[Job][0])startupcount++;
	}

	//�����м乤���Ŀ�ʼʱ������ʱ��
	int len = JobSeq.size();
	for (int i = 1; i < len; i++) {
		int CurJob = JobSeq[i];
		int PreJob = JobSeq[i - 1];
		if ((m_Type[PreJob] == 's') & (m_Type[CurJob] == 's')) {

			JCTime[CurJob][0] = max(JCTime[PreJob][1] + m_JPT[PreJob][SparkSeq[CurJob]], m_RT[CurJob]);
			JCTime[CurJob][1] = JCTime[CurJob][0] + Pick + m_JPT[CurJob][SparkSeq[CurJob]] + drop;
			unloadtime = unloadtime + m_JPT[PreJob][SparkSeq[CurJob]];
			loadtime = loadtime + m_JPT[CurJob][SparkSeq[CurJob]];
			if (m_BayCoord[SparkSeq[CurJob]][0] == m_JobCoord[PreJob][0])startupcount++;
		}

		if ((m_Type[PreJob] == 'u') & (m_Type[CurJob] == 'u')) {

			JCTime[CurJob][0] = JCTime[PreJob][1] + m_JPT[CurJob][SparkSeq[PreJob]];
			JCTime[CurJob][1] = max(JCTime[CurJob][0] + Pick + m_JPT[CurJob][SparkSeq[CurJob]], m_RT[CurJob]) + drop;
			unloadtime = unloadtime + m_JPT[CurJob][SparkSeq[PreJob]];
			loadtime = loadtime + m_JPT[CurJob][SparkSeq[CurJob]];

			if (m_BayCoord[SparkSeq[PreJob]][0] == m_JobCoord[CurJob][0])startupcount++;
		}

		if ((m_Type[PreJob] == 'u') & (m_Type[CurJob] == 's')) {

			JCTime[CurJob][0] = max(JCTime[PreJob][1] + m_PPT[SparkSeq[PreJob]][SparkSeq[CurJob]], m_RT[CurJob]);
			JCTime[CurJob][1] = JCTime[CurJob][0] + Pick + m_JPT[CurJob][SparkSeq[CurJob]] + drop;
			unloadtime = unloadtime + m_PPT[SparkSeq[PreJob]][SparkSeq[CurJob]];
			loadtime = loadtime + m_JPT[CurJob][SparkSeq[CurJob]];

		}

		if ((m_Type[PreJob] == 's') & (m_Type[CurJob] == 'u')) {

			JCTime[CurJob][0] = JCTime[PreJob][1] + m_JJT[PreJob][CurJob];
			JCTime[CurJob][1] = max(JCTime[CurJob][0] + Pick + m_JPT[CurJob][SparkSeq[CurJob]], m_RT[CurJob]) + drop;
			unloadtime = unloadtime + m_JJT[PreJob][CurJob];
			loadtime = loadtime + m_JPT[CurJob][SparkSeq[CurJob]];
		}
		if (m_JobCoord[CurJob][0] == m_BayCoord[SparkSeq[CurJob]][0])
			startupcount++;

	}

	//����YC���Ŀ�ʼʱ������ʱ��
	Job = JobSeq.back();
	if (m_Type[Job] == 'u') {

		cmax = JCTime[Job][1] + max(abs(m_BayCoord[SparkSeq[Job]][0] - m_Finalbay[0]), abs(m_BayCoord[SparkSeq[Job]][1] - m_Finalbay[1]));
		unloadtime = unloadtime + max(abs(m_BayCoord[SparkSeq[Job]][0] - m_Finalbay[0]), abs(m_BayCoord[SparkSeq[Job]][1] - m_Finalbay[1]));
		if (m_JobCoord[Job][0] == m_BayCoord[SparkSeq[Job]][0])startupcount++;
	}
	if (m_Type[Job] == 's') {

		cmax = JCTime[Job][1] + max(abs(m_JobCoord[Job][0] - m_Finalbay[0]), abs(m_JobCoord[Job][1] - m_Finalbay[1]));
		unloadtime = unloadtime + max(abs(m_JobCoord[Job][0] - m_Finalbay[0]), abs(m_JobCoord[Job][1] - m_Finalbay[1]));
	}

	for (int i = 0; i < m_Jobs; i++) {
		tft = tft + JCTime[i][1];
	}
	sumstartupcount = 2 * m_Jobs + 1 - startupcount;
	tec = loadperEC * loadtime + uloadperEC * unloadtime + sumstartupcount * startupperEC;
	Objects[0] = cmax;
	Objects[1] = tft;
	Objects[2] = tec;
	
}


void NOperators::GetCostMatrix(vector<vector<int>>& CostMatrix, vector <int>& SparkSeq) {
	int n = CostMatrix.size();
	for (int i = 0; i <n; i++)CostMatrix[i][i] = RAND_MAX;
	//����i����head�ľ���
	for (int i = 1; i <n; i++) {
		int Job = i - 1;
		if (m_Type[Job] == 'u') {
			CostMatrix[0][i] = max(abs(m_JobCoord[Job][0] - m_Startbay[0]), abs(m_JobCoord[Job][1] - m_Startbay[1]));
			
		}
		if (m_Type[Job] == 's') {
			int a=max(abs(m_BayCoord[SparkSeq[Job]][0]-m_Startbay[0]), abs(m_BayCoord[SparkSeq[Job]][1] - m_Startbay[1]));
			int b= max(abs(m_JobCoord[Job][0] - m_BayCoord[SparkSeq[Job]][0]), abs(m_JobCoord[Job][1] - m_BayCoord[SparkSeq[Job]][1]));
			CostMatrix[0][i] = a + b;
		}
				
	}
	//����i���ص��յ�hail�ľ���
	for (int i = 1; i <n; i++) {		
		int Job = i - 1;
		if (m_Type[Job] == 'u') {	
			//�ȵ�ͣ��λ
			int a = max(abs(m_JobCoord[Job][0] - m_BayCoord[SparkSeq[Job]][0]), abs(m_JobCoord[Job][1] - m_BayCoord[SparkSeq[Job]][1]));
			//ͣ��λ���յ�
			int b = max(abs(m_BayCoord[SparkSeq[Job]][0] - m_Finalbay[0]), abs(m_BayCoord[SparkSeq[Job]][1] - m_Finalbay[1]));
			CostMatrix[i][0] = a + b;
		}
		if (m_Type[Job] == 's') {
			//һ�����յ�
			CostMatrix[i][0] = max(abs(m_JobCoord[Job][0] - m_Finalbay[0]), abs(m_JobCoord[Job][1] - m_Finalbay[1]));
		
		}			
	}
	int PreJob, AfterJob, dis_1, dis_2, dis_3;
	//������������֮��ľ���
	for (int i = 1; i <n; i++) {
		for (int j = 1; j <n; j++) {
			if (i != j) {
				PreJob = i - 1;
				AfterJob = j - 1;
				if ((m_Type[PreJob] == 's') & (m_Type[AfterJob] == 's')) {

					dis_1=max(abs(m_JobCoord[PreJob][0] - m_BayCoord[SparkSeq[AfterJob]][0]), abs(m_JobCoord[PreJob][1] - m_BayCoord[SparkSeq[AfterJob]][1]));
					dis_2 = max(abs(m_JobCoord[AfterJob][0] - m_BayCoord[SparkSeq[AfterJob]][0]), abs(m_JobCoord[AfterJob][1] - m_BayCoord[SparkSeq[AfterJob]][1]));
					dis_3 = 0;
				}
				if ((m_Type[PreJob] == 'u') & (m_Type[AfterJob] == 'u')) {

					dis_1 = max(abs(m_JobCoord[PreJob][0] - m_BayCoord[SparkSeq[PreJob]][0]), abs(m_JobCoord[PreJob][1] - m_BayCoord[SparkSeq[PreJob]][1]));
					dis_2 = max(abs(m_JobCoord[AfterJob][0] - m_BayCoord[SparkSeq[PreJob]][0]), abs(m_JobCoord[AfterJob][1] - m_BayCoord[SparkSeq[PreJob]][1]));
					dis_3 = 0;
				}
				if ((m_Type[PreJob] == 's') & (m_Type[AfterJob] == 'u')) {
					dis_1 = max(abs(m_JobCoord[PreJob][0] - m_JobCoord[AfterJob][0]), abs(m_JobCoord[PreJob][1] - m_JobCoord[AfterJob][1]));
					dis_2 = 0;
					dis_3 = 0;
				}
				if ((m_Type[PreJob] == 'u') & (m_Type[AfterJob] == 's')) {
					
					dis_1 = max(abs(m_JobCoord[PreJob][0] - m_BayCoord[SparkSeq[PreJob]][0]), abs(m_JobCoord[PreJob][1] - m_BayCoord[SparkSeq[PreJob]][1]));
					dis_2 = max(abs(m_BayCoord[SparkSeq[PreJob]][0] - m_BayCoord[SparkSeq[AfterJob]][0]), abs(m_BayCoord[SparkSeq[PreJob]][1] - m_BayCoord[SparkSeq[AfterJob]][1]));
					dis_3 = max(abs(m_JobCoord[AfterJob][0] - m_BayCoord[SparkSeq[AfterJob]][0]), abs(m_JobCoord[AfterJob][1] - m_BayCoord[SparkSeq[AfterJob]][1]));

				}

				CostMatrix[i][j] = dis_1 + dis_2 + dis_3;
			}
		}
	}
}


vector<int> NOperators::ATSP(vector<vector<int>>D)
{
	//��ʼ���������
	int n = D.size();
	vector<int>permutation, temppermutation;
	//��ģ���
	GRBEnv* env = NULL;
	GRBVar** vars = NULL;
	vars = new GRBVar * [n];
	for (int i = 0; i < n; i++)
		vars[i] = new GRBVar[n];
	try
	{
		env = new GRBEnv();
		GRBModel model = GRBModel(*env);

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				vars[i][j] = model.addVar(0.0, 1.0, D[i][j], GRB_BINARY, "xij");
			}
		}
		model.update();
		for (int i = 0; i < n; i++) {
			GRBLinExpr expr = 0;
			for (int j = 0; j < n; j++)
				expr += vars[i][j];
			model.addConstr(expr == 1, "deg1");
		}
		model.update();
		for (int i = 0; i < n; i++) {
			GRBLinExpr expr = 0;
			for (int j = 0; j < n; j++)
				expr += vars[j][i];
			model.addConstr(expr == 1, "deg2");
		}
		model.update();
		for (int i = 0; i < n; i++)
			vars[i][i].set(GRB_DoubleAttr_UB, 0);
		model.update();
		model.set(GRB_IntParam_IntegralityFocus, 1);
		model.update();
		model.optimize();
		double** sol = new double* [n];
		for (int i = 0; i < n; i++)
			sol[i] = new double[n];
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				sol[i][j] = vars[i][j].get(GRB_DoubleAttr_X);
			}
		}
		int Z = model.get(GRB_DoubleAttr_ObjVal);
		//cout << Z << endl;
		int finished = 0;
		int iteration = 0;
		while (finished == 0)
		{
			iteration++;
			//������ģ��
			GRBVar** x = new GRBVar * [n];
			GRBVar* y = new GRBVar[n];
			for (int i = 0; i < n; i++)
				x[i] = new GRBVar[n];
			GRBModel submodel = GRBModel(*env);
			for (int i = 0; i < n; i++) {
				for (int j = 0; j < n; j++) {
					x[i][j] = submodel.addVar(0.0, 1.0, 0, GRB_BINARY, "x");
				}
			}
			for (int i = 0; i < n; i++) {
				y[i] = submodel.addVar(0.0, 1.0, 0, GRB_BINARY, "y");
			}
			GRBLinExpr expr_1 = 0;
			for (int i = 0; i < n; i++) {
				expr_1 = expr_1 + y[i];
			}
			GRBLinExpr expr_2 = 0;
			for (int i = 0; i < n; i++) {
				for (int j = 0; j < n; j++) {
					expr_2 = expr_2 + x[i][j] * sol[i][j];
				}
			}
			submodel.setObjective(expr_1 - expr_2, GRB_MINIMIZE);
			submodel.update();
			GRBLinExpr expr = 0;
			for (int i = 0; i < n; i++) {
				expr = expr + y[i];
			}
			submodel.addConstr(expr <= n - 2);
			submodel.update();
			submodel.addConstr(expr >= 2);
			submodel.update();
			for (int i = 0; i < n; i++) {
				//GRBLinExpr expr = 0;			
				for (int j = 0; j < n; j++) {
					if (i != j) {
						submodel.addConstr(-y[i] + x[i][j] <= 0);
					}
				}

			}
			submodel.update();
			for (int i = 0; i < n; i++) {
				//GRBLinExpr expr = 0;			
				for (int j = 0; j < n; j++) {
					if (i != j) {
						submodel.addConstr(-y[i] + x[j][i] <= 0);
					}
				}
			}
			submodel.update();
			for (int i = 0; i < n; i++) {
				for (int j = 0; j < n; j++) {
					if (i != j) {
						submodel.addConstr(-y[i] - y[j] + x[i][j] >= -1);
					}
				}
			}
			submodel.update();
			for (int i = 0; i < n; i++)
				x[i][i].set(GRB_DoubleAttr_UB, 0);
			submodel.update();
			submodel.set(GRB_IntParam_IntegralityFocus, 1);
			submodel.update();
			submodel.optimize();
			double* yxing = new double[n];
			for (int i = 0; i < n; i++) {
				yxing[i] = y[i].get(GRB_DoubleAttr_X);
			}
			vector<int>Sstar;
			Sstar.clear();
			for (int i = 0; i < n; i++) {
				if (yxing[i] == 1) {
					Sstar.push_back(i);
				}
			}
			int len = Sstar.size();
			GRBLinExpr cut = 0;
			for (int i = 0; i < len; i++) {
				for (int j = 0; j < len; j++) {
					if (i != j) {
						cut = cut + vars[Sstar[i]][Sstar[j]];
					}
				}
			}
			delete x;
			delete y;
			delete yxing;
			if (len > 1) {
				model.addConstr(cut <= len - 1, "cut");
			}
			model.update();
			model.optimize();
			for (int i = 0; i < n; i++) {
				for (int j = 0; j < n; j++) {
					sol[i][j] = vars[i][j].get(GRB_DoubleAttr_X);
				}
			}
			Z = model.get(GRB_DoubleAttr_ObjVal);
			//cout << Z << endl;
			permutation.clear();
			permutation.push_back(0);
			for (int cishu = 0; cishu < n - 1; cishu++) {
				int lastjob = permutation.back();
				for (int i = 0; i < n; i++)
				{
					if (sol[lastjob][i] == 1) {
						permutation.push_back(i);
						break;
					}
				}
			}
			temppermutation = permutation;
			set<int>s(temppermutation.begin(), temppermutation.end());//set���Զ���������
			temppermutation.assign(s.begin(), s.end());
			if (temppermutation.size() == n) {
				finished = 1;
				break;
			}
			else
			{
				finished = 0;
			}
			if (iteration > 50) {
				for (int i = 0; i < n; i++)
					permutation[i] = i;
			}

		}
		
		delete env;

		delete vars;
		delete sol;
		/*for (int i = 0; i < n; i++)
			cout << permutation[i] << "  ";
		cout << "��ȷ";*/
		return permutation;

	}
	catch (GRBException e)
	{
		cout << "Error code=" << e.getErrorCode() << endl;
		cout << e.getMessage() << endl;
		for (int i = 0; i < n; i++)
			permutation[i] = i;
		return permutation;

	}

}


vector<int> NOperators::ATSPT(vector<vector<int>>D)
{
	//��ʼ���������
	int n = D.size();
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
			cout << D[i][j] << " ";
		cout << endl;
	}
	vector<int>permutation, temppermutation;
	//��ģ���
	GRBEnv* env = NULL;
	GRBVar** vars = NULL;
	vars = new GRBVar * [n];
	for (int i = 0; i < n; i++)
		vars[i] = new GRBVar[n];
	//����t����
	GRBVar* t = new GRBVar[n];
	int M = 10000;
	try
	{
		env = new GRBEnv();
		GRBModel model = GRBModel(*env);

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				vars[i][j] = model.addVar(0.0, 1.0, 0, GRB_BINARY, "xij");
			}
		}
		
		for (int i = 0; i < n; i++) {

			t[i] = model.addVar(0.0, GRB_INFINITY, 1, GRB_CONTINUOUS, "t");
		}

		for (int i = 1; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if (i != j) {
					model.addConstr(t[i] >= t[j] + D[j][i] + (vars[j][i] - 1) * M, "deg3");
				}

			}
		}

		model.update();
		for (int i = 0; i < n; i++) {
			GRBLinExpr expr = 0;
			for (int j = 0; j < n; j++)
				expr += vars[i][j];
			model.addConstr(expr == 1, "deg1");
		}
		model.update();
		for (int i = 0; i < n; i++) {
			GRBLinExpr expr = 0;
			for (int j = 0; j < n; j++)
				expr += vars[j][i];
			model.addConstr(expr == 1, "deg2");
		}
		model.update();
		for (int i = 0; i < n; i++)
			vars[i][i].set(GRB_DoubleAttr_UB, 0);
		model.update();
		model.set(GRB_IntParam_IntegralityFocus, 1);
		model.update();
		model.optimize();

		double** sol = new double* [n];
		for (int i = 0; i < n; i++)
			sol[i] = new double[n];
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				sol[i][j] = vars[i][j].get(GRB_DoubleAttr_X);
			}
		}
		int Z = model.get(GRB_DoubleAttr_ObjVal);
		//cout << Z << endl;
		int finished = 0;
		int iteration = 0;
		while (finished == 0)
		{
			iteration++;
			//������ģ��
			GRBVar** x = new GRBVar * [n];
			GRBVar* y = new GRBVar[n];
			for (int i = 0; i < n; i++)
				x[i] = new GRBVar[n];
			GRBModel submodel = GRBModel(*env);
			for (int i = 0; i < n; i++) {
				for (int j = 0; j < n; j++) {
					x[i][j] = submodel.addVar(0.0, 1.0, 0, GRB_BINARY, "x");
				}
			}
			for (int i = 0; i < n; i++) {
				y[i] = submodel.addVar(0.0, 1.0, 0, GRB_BINARY, "y");
			}
			GRBLinExpr expr_1 = 0;
			for (int i = 0; i < n; i++) {
				expr_1 = expr_1 + y[i];
			}
			GRBLinExpr expr_2 = 0;
			for (int i = 0; i < n; i++) {
				for (int j = 0; j < n; j++) {
					expr_2 = expr_2 + x[i][j] * sol[i][j];
				}
			}
			submodel.setObjective(expr_1 - expr_2, GRB_MINIMIZE);
			submodel.update();
			GRBLinExpr expr = 0;
			for (int i = 0; i < n; i++) {
				expr = expr + y[i];
			}
			submodel.addConstr(expr <= n - 2);
			submodel.update();
			submodel.addConstr(expr >= 2);
			submodel.update();
			for (int i = 0; i < n; i++) {
				//GRBLinExpr expr = 0;			
				for (int j = 0; j < n; j++) {
					if (i != j) {
						submodel.addConstr(-y[i] + x[i][j] <= 0);
					}
				}

			}
			submodel.update();
			for (int i = 0; i < n; i++) {
				//GRBLinExpr expr = 0;			
				for (int j = 0; j < n; j++) {
					if (i != j) {
						submodel.addConstr(-y[i] + x[j][i] <= 0);
					}
				}
			}
			submodel.update();
			for (int i = 0; i < n; i++) {
				for (int j = 0; j < n; j++) {
					if (i != j) {
						submodel.addConstr(-y[i] - y[j] + x[i][j] >= -1);
					}
				}
			}
			submodel.update();
			for (int i = 0; i < n; i++)
				x[i][i].set(GRB_DoubleAttr_UB, 0);
			submodel.update();
			submodel.set(GRB_IntParam_IntegralityFocus, 1);
			submodel.update();
			submodel.optimize();
			double* yxing = new double[n];
			for (int i = 0; i < n; i++) {
				yxing[i] = y[i].get(GRB_DoubleAttr_X);
			}
			vector<int>Sstar;
			Sstar.clear();
			for (int i = 0; i < n; i++) {
				if (yxing[i] == 1) {
					Sstar.push_back(i);
				}
			}
			int len = Sstar.size();
			GRBLinExpr cut = 0;
			for (int i = 0; i < len; i++) {
				for (int j = 0; j < len; j++) {
					if (i != j) {
						cut = cut + vars[Sstar[i]][Sstar[j]];
					}
				}
			}
			delete x;
			delete y;
			delete yxing;
			if (len > 1) {
				model.addConstr(cut <= len - 1, "cut");
			}
			model.update();
			model.optimize();
			for (int i = 0; i < n; i++) {
				for (int j = 0; j < n; j++) {
					sol[i][j] = vars[i][j].get(GRB_DoubleAttr_X);
				}
			}
			Z = model.get(GRB_DoubleAttr_ObjVal);
			//cout << Z << endl;
			permutation.clear();
			permutation.push_back(0);
			for (int cishu = 0; cishu < n - 1; cishu++) {
				int lastjob = permutation.back();
				for (int i = 0; i < n; i++)
				{
					if (sol[lastjob][i] == 1) {
						permutation.push_back(i);
						break;
					}
				}
			}
			temppermutation = permutation;
			set<int>s(temppermutation.begin(), temppermutation.end());//set���Զ���������
			temppermutation.assign(s.begin(), s.end());
			if (temppermutation.size() == n) {
				finished = 1;
				break;
			}
			else
			{
				finished = 0;
			}
			if (iteration > 50) {
				for (int i = 0; i < n; i++)
					permutation[i] = i;
			}

		}
		delete env;
		delete vars;
		delete sol;
		/*for (int i = 0; i < n; i++)
			cout << permutation[i] << "  ";
		cout << "��ȷ";*/
		return permutation;

	}
	catch (GRBException e)
	{
		cout << "Error code=" << e.getErrorCode() << endl;
		cout << e.getMessage() << endl;
		for (int i = 0; i < n; i++)
			permutation[i] = i;
		return permutation;

	}

}


vector<int> NOperators::ATSPCandT(vector<vector<int>>D)
{
	//��ʼ���������
	int n = D.size();
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
			cout << D[i][j] << " ";
		cout << endl;
	}
	vector<int>permutation, temppermutation;
	//��ģ���
	GRBEnv* env = NULL;
	GRBVar** vars = NULL;
	vars = new GRBVar * [n];
	for (int i = 0; i < n; i++)
		vars[i] = new GRBVar[n];
	//����t����
	GRBVar* t = new GRBVar[n];
	int M = 10000;
	try
	{
		env = new GRBEnv();
		GRBModel model = GRBModel(*env);

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				vars[i][j] = model.addVar(0.0, 1.0, D[i][j], GRB_BINARY, "xij");
			}
		}

		for (int i = 0; i < n; i++) {

			t[i] = model.addVar(0.0, GRB_INFINITY, 1, GRB_CONTINUOUS, "t");
		}

		for (int i = 1; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if (i != j) {
					model.addConstr(t[i] >= t[j] + D[j][i] + (vars[j][i] - 1) * M, "deg3");
				}

			}
		}

		model.update();
		for (int i = 0; i < n; i++) {
			GRBLinExpr expr = 0;
			for (int j = 0; j < n; j++)
				expr += vars[i][j];
			model.addConstr(expr == 1, "deg1");
		}
		model.update();
		for (int i = 0; i < n; i++) {
			GRBLinExpr expr = 0;
			for (int j = 0; j < n; j++)
				expr += vars[j][i];
			model.addConstr(expr == 1, "deg2");
		}
		model.update();
		for (int i = 0; i < n; i++)
			vars[i][i].set(GRB_DoubleAttr_UB, 0);
		model.update();
		model.set(GRB_IntParam_IntegralityFocus, 1);
		model.update();
		model.optimize();

		double** sol = new double* [n];
		for (int i = 0; i < n; i++)
			sol[i] = new double[n];
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				sol[i][j] = vars[i][j].get(GRB_DoubleAttr_X);
			}
		}
		int Z = model.get(GRB_DoubleAttr_ObjVal);
		//cout << Z << endl;
		int finished = 0;
		int iteration = 0;
		while (finished == 0)
		{
			iteration++;
			//������ģ��
			GRBVar** x = new GRBVar * [n];
			GRBVar* y = new GRBVar[n];
			for (int i = 0; i < n; i++)
				x[i] = new GRBVar[n];
			GRBModel submodel = GRBModel(*env);
			for (int i = 0; i < n; i++) {
				for (int j = 0; j < n; j++) {
					x[i][j] = submodel.addVar(0.0, 1.0, 0, GRB_BINARY, "x");
				}
			}
			for (int i = 0; i < n; i++) {
				y[i] = submodel.addVar(0.0, 1.0, 0, GRB_BINARY, "y");
			}
			GRBLinExpr expr_1 = 0;
			for (int i = 0; i < n; i++) {
				expr_1 = expr_1 + y[i];
			}
			GRBLinExpr expr_2 = 0;
			for (int i = 0; i < n; i++) {
				for (int j = 0; j < n; j++) {
					expr_2 = expr_2 + x[i][j] * sol[i][j];
				}
			}
			submodel.setObjective(expr_1 - expr_2, GRB_MINIMIZE);
			submodel.update();
			GRBLinExpr expr = 0;
			for (int i = 0; i < n; i++) {
				expr = expr + y[i];
			}
			submodel.addConstr(expr <= n - 2);
			submodel.update();
			submodel.addConstr(expr >= 2);
			submodel.update();
			for (int i = 0; i < n; i++) {
				//GRBLinExpr expr = 0;			
				for (int j = 0; j < n; j++) {
					if (i != j) {
						submodel.addConstr(-y[i] + x[i][j] <= 0);
					}
				}

			}
			submodel.update();
			for (int i = 0; i < n; i++) {
				//GRBLinExpr expr = 0;			
				for (int j = 0; j < n; j++) {
					if (i != j) {
						submodel.addConstr(-y[i] + x[j][i] <= 0);
					}
				}
			}
			submodel.update();
			for (int i = 0; i < n; i++) {
				for (int j = 0; j < n; j++) {
					if (i != j) {
						submodel.addConstr(-y[i] - y[j] + x[i][j] >= -1);
					}
				}
			}
			submodel.update();
			for (int i = 0; i < n; i++)
				x[i][i].set(GRB_DoubleAttr_UB, 0);
			submodel.update();
			submodel.set(GRB_IntParam_IntegralityFocus, 1);
			submodel.update();
			submodel.optimize();
			double* yxing = new double[n];
			for (int i = 0; i < n; i++) {
				yxing[i] = y[i].get(GRB_DoubleAttr_X);
			}
			vector<int>Sstar;
			Sstar.clear();
			for (int i = 0; i < n; i++) {
				if (yxing[i] == 1) {
					Sstar.push_back(i);
				}
			}
			int len = Sstar.size();
			GRBLinExpr cut = 0;
			for (int i = 0; i < len; i++) {
				for (int j = 0; j < len; j++) {
					if (i != j) {
						cut = cut + vars[Sstar[i]][Sstar[j]];
					}
				}
			}
			delete x;
			delete y;
			delete yxing;
			if (len > 1) {
				model.addConstr(cut <= len - 1, "cut");
			}
			model.update();
			model.optimize();
			for (int i = 0; i < n; i++) {
				for (int j = 0; j < n; j++) {
					sol[i][j] = vars[i][j].get(GRB_DoubleAttr_X);
				}
			}
			Z = model.get(GRB_DoubleAttr_ObjVal);
			//cout << Z << endl;
			permutation.clear();
			permutation.push_back(0);
			for (int cishu = 0; cishu < n - 1; cishu++) {
				int lastjob = permutation.back();
				for (int i = 0; i < n; i++)
				{
					if (sol[lastjob][i] == 1) {
						permutation.push_back(i);
						break;
					}
				}
			}
			temppermutation = permutation;
			set<int>s(temppermutation.begin(), temppermutation.end());//set���Զ���������
			temppermutation.assign(s.begin(), s.end());
			if (temppermutation.size() == n) {
				finished = 1;
				break;
			}
			else
			{
				finished = 0;
			}
			if (iteration > 50) {
				for (int i = 0; i < n; i++)
					permutation[i] = i;
			}

		}
		delete env;
		delete vars;
		delete sol;
		/*for (int i = 0; i < n; i++)
			cout << permutation[i] << "  ";
		cout << "��ȷ";*/
		return permutation;

	}
	catch (GRBException e)
	{
		cout << "Error code=" << e.getErrorCode() << endl;
		cout << e.getMessage() << endl;
		for (int i = 0; i < n; i++)
			permutation[i] = i;
		return permutation;

	}

}
