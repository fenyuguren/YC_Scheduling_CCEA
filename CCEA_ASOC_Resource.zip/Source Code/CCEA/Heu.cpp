#include "stdafx.h"
#include "Heu.h"


Heu::Heu()
{
}

Heu::~Heu()
{
}

void Heu::SortJob(int SortMethod, vector<int>& JobPrmu) {

	/*JobPrmu.clear();
	JobPrmu.resize(this->m_Jobs);*/
	for (int j = 0; j < this->m_Jobs; j++)
		JobPrmu[j] = j;

	Pair<double>* ch = new Pair<double>[JobPrmu.size()];
	for (int j = 0; j < JobPrmu.size(); j++)
	{
		ch[j].dim = JobPrmu[j];
		ch[j].value = this->m_RT[JobPrmu[j]];
		
	}
	if (SortMethod == 0)
		sort(ch, ch + this->m_Jobs, PairGreater<double>());
	else
		sort(ch, ch + this->m_Jobs, PairLess<double>());
	for (int j = 0; j < this->m_Jobs; j++)
		JobPrmu[j] = ch[j].dim;
	
	delete[]ch;
}
void  Heu::WriteFile(string FileName, vector<unsigned int> FactorLevelsArray, vector<vector<double>> RPIArray)
{
	
}


	
