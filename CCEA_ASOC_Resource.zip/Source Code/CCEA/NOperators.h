#pragma once
#include "Problem.h"
#include "Data.h"
class NOperators :
	virtual public Problem
{
public:
	NOperators();
	virtual ~NOperators();
	void printobject(vector<vector<int>>pop);
	void printcanshu();

	bool dominates(const Solution& a, const Solution& b);
	vector<Solution> findNonDominatedSolutions(const vector<Solution>& solutions);

	void RandSwap(vector<int>& Sol);
	void RandShift(vector<int>& Sol);
	
	
	void FindJobPos(vector <int>JobSeq, int CurJob, int& Pos);
	double FindBestPosToInsertJob_InSeq(vector <int>& JobSeq, vector <int> SparkSeq, int Job, int& bestPos, vector<double>& BestObjects);
	
	void AlignmentSpark(vector<int>JobSeq, vector<int>& SparkSeq);
	void AlignmentAllSpark(vector<int>JobSeq, vector<int>& SparkSeq);
	void RandAssignSpark(vector<int>JobSeq, vector<int>& SparkSeq);
	void AssignSpark_I(vector<int>JobSeq, vector<int>& SparkSeq);
	void AssignSpark_II(vector<int>JobSeq, vector<int>& SparkSeq);
	void CheckSparks(vector<int>& SparkSeq);
	void GetSpan(vector <int>JobSeq, vector <int>SparkSeq, vector <double>& Objects, double& fitness);
	void GetObjects(vector <int>JobSeq, vector <int>SparkSeq,vector <double>& Objects);
	double FindBestCmaxPosToInsertJob_InSeq(vector <int>& JobSeq, vector <int> SparkSeq, int Job, int& bestPos);
	double FindBestTFTPosToInsertJob_InSeq(vector <int>& JobSeq, vector <int> SparkSeq, int Job, int& bestPos);
	double FindBestECPosToInsertJob_InSeq(vector <int>& JobSeq, vector <int> SparkSeq, int Job, int& bestPos);
	void GetCostMatrix(vector<vector<int>>& CostMatrix,vector <int>& SparkSeq);
	vector<int> ATSP(vector<vector<int>>D);
	vector<int> ATSPT(vector<vector<int>>D);
	vector<int> ATSPCandT(vector<vector<int>>D);
};

