//Base.cpp
#include "stdafx.h"
#include "Base.h"


long Base::GetElapsedProcessTime()
{
	FILETIME createTime;
	FILETIME exitTime;
	FILETIME kernelTime;
	FILETIME userTime;

	if (GetProcessTimes(GetCurrentProcess(), &createTime, &exitTime, &kernelTime, &userTime) != 0)
	{
		//  Returns total user time.
		SYSTEMTIME userSystemTime;
		if (FileTimeToSystemTime(&userTime, &userSystemTime) != -1)
			return (userSystemTime.wDay - 1) * 24 * 3600 * 1000
			+ userSystemTime.wHour * 3600 * 1000 +
			userSystemTime.wMinute * 60 * 1000 +
			userSystemTime.wSecond * 1000 +
			userSystemTime.wMilliseconds;
		else
			return 0;

	}
	else
		return 0;
}

vector<int> Base::removeDuplicateRows(vector<vector<double>>& vec2D) {
	set<vector<double>> uniqueRows;
	uniqueRows.clear();
	vector<int> row, indexs;
	indexs.clear();
	int i = 0;
	for (const auto& row : vec2D) {

		if (uniqueRows.insert(row).second) { // �������ɹ�����������Ψһ��            
			indexs.push_back(i);
		}
		i++;
	}
	return indexs;

}