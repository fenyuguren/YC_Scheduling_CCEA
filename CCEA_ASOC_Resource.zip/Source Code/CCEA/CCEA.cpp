#include "stdafx.h"
#include "CCEA.h"

CCEA::CCEA()
{
}

CCEA::~CCEA()
{
}

void CCEA::SetParameters(int RefSize, int PS1, int PS2, int AgeLimit, int DesLen, long TimeLimit) //PS1>RefSize; PS2>RefSize;
{
	m_RefSize = RefSize;
	m_PS1 = PS1;
	m_PS2 = PS2;

	m_AgeLimit = AgeLimit;
	m_DesLen = DesLen;

	m_TimeLimit = TimeLimit;
	m_InitTime = GetElapsedProcessTime();


	/*--------------------------Reference set----------------------------*/
	m_RefJobSeqArray.clear();
	m_RefJobSeqArray.resize(m_RefSize);

	m_RefSparkSeqArray.clear();
	m_RefSparkSeqArray.resize(m_RefSize);

	m_RefObjectArray.clear();
	m_RefObjectArray.resize(m_RefSize);

	m_RefFitnessArray.clear();
	m_RefFitnessArray.resize(m_RefSize);

	m_bFlag1.clear(); // Flag: the RefJob changed;
	m_bFlag1.resize(m_RefSize);

	m_bFlag2.clear();// Flag: the RefPark changed;
	m_bFlag2.resize(m_RefSize);

	/*--------------------------Job sequence population--------------------*/
	m_JobSeqArray.clear();
	m_JobSeqArray.resize(m_PS1);

	m_ObjectArray1.clear();
	m_ObjectArray1.resize(m_PS1);

	m_FitnessArray1.clear();
	m_FitnessArray1.resize(m_PS1);

	m_Map1.clear(); // the corresponding RefPark
	m_Map1.resize(m_PS1);

	m_Age1.clear();
	m_Age1.resize(m_PS1);


	/*--------------------------Spark sequence population--------------------*/
	m_SparkSeqArray.clear();
	m_SparkSeqArray.resize(m_PS2);

	m_ObjectArray2.clear();
	m_ObjectArray2.resize(m_PS2);

	m_FitnessArray2.clear();
	m_FitnessArray2.resize(m_PS2);

	m_Map2.clear();// the corresponding RefJob
	m_Map2.resize(m_PS2);

	m_Age2.clear();
	m_Age2.resize(m_PS2);

	m_RefPoints.clear();
	m_RefPoints.resize(3);

	m_solutions.clear();
	m_uniquesolutions.clear();
	m_AllSolObjects.clear();
	m_nonDominatedSolutions.clear();



}
void CCEA::RefPointEst()
{
	//vector<int>JobSeq(m_Jobs), SparkSeq(m_Jobs);
	//vector<double>Objects(3, 0.0);
	//vector<vector<int>> JCTime(m_Jobs);
	//for (int j = 0; j < JCTime.size(); j++)
	//	JCTime[j].resize(2, 0);



	//double RefObject_0 = INT_MAX;
	//double RefObject_1 = INT_MAX;
	//double RefObject_2 = INT_MAX;

	//int Pos, TempBestPos;
	//double TempBestTFT, TempBestCmax, TempBestEC;
	//vector<int>TempJobSeq, TempSparkSeq;


	//vector<vector<int>> pop_I, pop_II;
	//for (int cishu = 0; cishu < 1000; cishu++)
	//{
	//	if (cishu == 0) {
	//		SortJob(1, JobSeq);
	//	}
	//	else {
	//		RandSwap(JobSeq);
	//	}
	//	/*if (cishu == 50)
	//		cout << "ting";*/
	//	double r = double(rand()) / RAND_MAX;
	//	if (r < 0.5) {
	//		AssignSpark_I(JobSeq, SparkSeq);
	//	}
	//	else {
	//		AssignSpark_II(JobSeq, SparkSeq);
	//	}
	//	CheckSparks(SparkSeq);
	//	pop_I.push_back(JobSeq);
	//	pop_II.push_back(SparkSeq);
	//}
	////first extreme point
	//int cmaxindex = -1;
	//for (int i = 0; i < 1000; i++)
	//{
	//	JobSeq = pop_I[i];
	//	SparkSeq = pop_II[i];
	//	double zuixiaozhi = INT_MAX;
	//	for (int CurJob = 0; CurJob < m_Jobs; CurJob++) {
	//		TempJobSeq = JobSeq;
	//		TempSparkSeq = SparkSeq;
	//		FindJobPos(TempJobSeq, CurJob, Pos);
	//		TempJobSeq.erase(TempJobSeq.begin() + Pos);
	//		TempBestCmax = FindBestCmaxPosToInsertJob_InSeq(TempJobSeq, TempSparkSeq, CurJob, TempBestPos);
	//		TempJobSeq.insert(TempJobSeq.begin() + TempBestPos, CurJob);
	//		if (TempBestCmax < zuixiaozhi)
	//		{
	//			zuixiaozhi = TempBestCmax;
	//			JobSeq = TempJobSeq;
	//			SparkSeq = TempSparkSeq;
	//		}
	//	}

	//	pop_I[i] = JobSeq;
	//	pop_II[i] = SparkSeq;

	//	if (zuixiaozhi < RefObject_0) {
	//		cmaxindex = i;
	//		RefObject_0 = zuixiaozhi;
	//	}
	//	/*	cout << i << "\t";
	//		for (int job : JobSeq)cout << job << " ";
	//		cout << "\t";
	//		for (int spark : SparkSeq)cout << spark << " ";
	//		cout << "\t";
	//		cout << endl;*/


	//}

	//GetObjects(pop_I[cmaxindex], pop_II[cmaxindex], Objects);
	//m_solutions.push_back(Solution(Objects, pop_I[cmaxindex], pop_II[cmaxindex]));
	//m_AllSolObjects.push_back(Objects);

	////second extreme point
	//int tftindex = -1;
	//for (int i = 0; i < 1000; i++)
	//{
	//	JobSeq = pop_I[i];
	//	SparkSeq = pop_II[i];
	//	double zuixiaozhi = INT_MAX;
	//	for (int CurJob = 0; CurJob < m_Jobs; CurJob++) {
	//		TempJobSeq = JobSeq;
	//		TempSparkSeq = SparkSeq;

	//		FindJobPos(TempJobSeq, CurJob, Pos);
	//		TempJobSeq.erase(TempJobSeq.begin() + Pos);
	//		TempBestTFT = FindBestTFTPosToInsertJob_InSeq(TempJobSeq, TempSparkSeq, CurJob, TempBestPos);
	//		TempJobSeq.insert(TempJobSeq.begin() + TempBestPos, CurJob);
	//		if (TempBestTFT < zuixiaozhi)
	//		{
	//			zuixiaozhi = TempBestTFT;
	//			JobSeq = TempJobSeq;
	//			SparkSeq = TempSparkSeq;
	//		}
	//	}

	//	pop_I[i] = JobSeq;
	//	pop_II[i] = SparkSeq;
	//	if (zuixiaozhi < RefObject_1) {
	//		RefObject_1 = zuixiaozhi;
	//		tftindex = i;
	//	}
	//}
	//GetObjects(pop_I[tftindex], pop_II[tftindex], Objects);
	//m_solutions.push_back(Solution(Objects, pop_I[tftindex], pop_II[tftindex]));
	//m_AllSolObjects.push_back(Objects);

	//int ECindex = -1;
	//for (int i = 0; i < 1000; i++)
	//{
	//	JobSeq = pop_I[i];
	//	SparkSeq = pop_II[i];
	//	AlignmentAllSpark(JobSeq, SparkSeq);
	//	CheckSparks(SparkSeq);
	//	double zuixiaozhi = INT_MAX;

	//	for (int CurJob = 0; CurJob < m_Jobs; CurJob++) {
	//		TempJobSeq = JobSeq;
	//		TempSparkSeq = SparkSeq;

	//		FindJobPos(TempJobSeq, CurJob, Pos);
	//		TempJobSeq.erase(TempJobSeq.begin() + Pos);
	//		TempBestEC = FindBestECPosToInsertJob_InSeq(TempJobSeq, TempSparkSeq, CurJob, TempBestPos);
	//		TempJobSeq.insert(TempJobSeq.begin() + TempBestPos, CurJob);
	//		if (TempBestEC < zuixiaozhi)
	//		{
	//			zuixiaozhi = TempBestEC;
	//			JobSeq = TempJobSeq;
	//			SparkSeq = TempSparkSeq;
	//		}
	//	}
	//	pop_I[i] = JobSeq;
	//	pop_II[i] = SparkSeq;

	//	if (zuixiaozhi < RefObject_2) {
	//		RefObject_2 = zuixiaozhi;
	//		ECindex = i;
	//	}
	//}

	//GetObjects(pop_I[ECindex], pop_II[ECindex], Objects);
	//m_solutions.push_back(Solution(Objects, pop_I[ECindex], pop_II[ECindex]));
	//m_AllSolObjects.push_back(Objects);

	m_RefPoints[0] = 0.0;
	m_RefPoints[1] = 0.0;
	m_RefPoints[2] = 0.0;
	/*cout << "�ο��㣺" << endl;
	cout << RefObject_0 << " " << RefObject_1 << " " << RefObject_2 << endl;*/

	/*m_RefPoints[0] = 0;
	m_RefPoints[1] = 0;
	m_RefPoints[2] = 0;*/
}

vector<Solution> CCEA::GetNondominatedSet()
{
	vector<Solution> solutions;
	for (int i = 0; i < m_PS1; i++)
		solutions.push_back(Solution(m_ObjectArray1[i], m_JobSeqArray[i], m_RefSparkSeqArray[m_Map1[i]]));

	for (int i = 0; i < m_PS2; i++)
		solutions.push_back(Solution(m_ObjectArray2[i], m_RefJobSeqArray[m_Map2[i]], m_SparkSeqArray[i]));

	vector<Solution> nonDominatedSolutions = findNonDominatedSolutions(solutions);
	vector<int>seq1, seq2;
	cout << "Non-dominated solutions: \n";
	for (const auto& sol : nonDominatedSolutions) {
		seq1 = sol.jobseq;
		seq2 = sol.sparkseq;
		for (int j : seq1)cout << j << " ";
		cout << "\t";
		for (int j : seq2)cout << j << " ";
		cout << "(" << sol.objectives[0] << ", " << sol.objectives[1] << ", " << sol.objectives[2] << ")\n";
	}
	return nonDominatedSolutions;
}


void CCEA::InitPop()
{
	

	vector<int>JobSeq(m_Jobs), SparkSeq(m_Jobs);
	vector<double>Objects(3, 0);
	double fitness = 0;

	for (int PS = 0; PS < m_RefSize; PS++)
	{
		if (PS == 0) {
			SortJob(1, JobSeq);
		}
		else {
			RandSwap(JobSeq);
		}

		double r = double(rand()) / RAND_MAX;
		if (r < 0.5) {
			AssignSpark_I(JobSeq, SparkSeq);
		}
		else {
			AssignSpark_II(JobSeq, SparkSeq);
		}
		CheckSparks(SparkSeq);
		m_RefJobSeqArray[PS] = JobSeq;
		m_RefSparkSeqArray[PS] = SparkSeq;
		GetSpan(JobSeq, SparkSeq, Objects, fitness);
		m_RefObjectArray[PS] = Objects;
		m_RefFitnessArray[PS] = fitness;

		m_solutions.push_back(Solution(Objects, JobSeq, SparkSeq));
		m_AllSolObjects.push_back(Objects);

	}

	//Initilize job-sequence population, i.e., PS1
	for (int PS = 0; PS < min(m_PS1, m_RefSize); PS++)
	{
		m_JobSeqArray[PS] = m_RefJobSeqArray[PS];
		m_ObjectArray1[PS] = m_RefObjectArray[PS];
		m_FitnessArray1[PS] = m_RefFitnessArray[PS];
		m_Map1[PS] = PS;
	}

	for (int PS = min(m_PS1, m_RefSize); PS < m_PS1; PS++)
	{
		//randomly select a job sequence from reference set and swap
		int r = rand() % m_RefSize;
		m_JobSeqArray[PS] = m_RefJobSeqArray[r];
		RandSwap(m_JobSeqArray[PS]);

		//randomly select a sparking seqence from reference set
		m_Map1[PS] = rand() % m_RefSize;
		GetSpan(m_JobSeqArray[PS], m_RefSparkSeqArray[m_Map1[PS]], Objects, fitness);
		m_ObjectArray1[PS] = Objects;
		m_FitnessArray1[PS] = fitness;

		m_solutions.push_back(Solution(Objects, m_JobSeqArray[PS], m_RefSparkSeqArray[m_Map1[PS]]));
		m_AllSolObjects.push_back(Objects);
	}

	//Initialize spark-sequence population, i.e., PS2
	for (int PS = 0; PS < min(m_PS2, m_RefSize); PS++)
	{
		m_SparkSeqArray[PS] = m_RefSparkSeqArray[PS];
		m_ObjectArray2[PS] = m_RefObjectArray[PS];
		m_FitnessArray2[PS] = m_RefFitnessArray[PS];
		m_Map2[PS] = PS;

	}

	for (int PS = min(m_PS2, m_RefSize); PS < m_PS2; PS++)
	{
		//randomly select a spark sequence from reference set and swap
		int r = rand() % m_RefSize;
		m_SparkSeqArray[PS] = m_RefSparkSeqArray[r];


		//randomly select a job seqence from reference set
		m_Map2[PS] = rand() % m_RefSize;
		AlignmentSpark(m_RefJobSeqArray[m_Map2[PS]], m_SparkSeqArray[PS]);
		CheckSparks(m_SparkSeqArray[PS]);
		GetSpan(m_RefJobSeqArray[m_Map2[PS]], m_SparkSeqArray[PS], Objects, fitness);
		m_ObjectArray2[PS] = Objects;
		m_FitnessArray2[PS] = fitness;

		m_solutions.push_back(Solution(Objects, m_RefJobSeqArray[m_Map2[PS]], m_SparkSeqArray[PS]));
		m_AllSolObjects.push_back(Objects);
	}

}

int CCEA::Destruction_Construction(int Len, vector<int>& JobSeq, vector<int> SparkSeq, vector<double>& Objects)
{
	//Extract Len jobs from jobseq
	vector<int> ExtractFamSeq;
	do {


		int Pos = rand() % JobSeq.size();
		ExtractFamSeq.push_back(JobSeq[Pos]);
		JobSeq.erase(JobSeq.begin() + Pos);

	} while (ExtractFamSeq.size() < Len);
	int bestPos = -1;
	double fitness = -1;
	//construction
	for (int CurJob : ExtractFamSeq) {
		fitness = FindBestPosToInsertJob_InSeq(JobSeq, SparkSeq, CurJob, bestPos, Objects);
		JobSeq.insert(JobSeq.begin() + bestPos, CurJob);
	}

	return fitness;

}



void CCEA::ReInitPop() //reproduce a solution if age Limit is met
{
	for (int PS = 0; PS < m_PS1; PS++)
	{
		if (m_Age1[PS] < m_AgeLimit) continue;
		m_JobSeqArray[PS] = m_RefJobSeqArray[m_Map1[PS]];
		m_FitnessArray1[PS] = Destruction_Construction(m_DesLen, m_JobSeqArray[PS], m_RefSparkSeqArray[m_Map1[PS]], m_ObjectArray1[PS]);
		m_Age1[PS] = 0;

		m_solutions.push_back(Solution(m_ObjectArray1[PS], m_JobSeqArray[PS], m_RefSparkSeqArray[m_Map1[PS]]));
		m_AllSolObjects.push_back(m_ObjectArray1[PS]);
	}

	for (int PS = 0; PS < m_PS2; PS++)
	{
		if (m_Age2[PS] < m_AgeLimit) continue;
		m_SparkSeqArray[PS] = m_RefSparkSeqArray[m_Map2[PS]];

		double r = double(rand()) / RAND_MAX;
		if (r < 0.5) {
			AssignSpark_I(m_RefJobSeqArray[m_Map2[PS]], m_SparkSeqArray[PS]);
		}
		else {
			AssignSpark_II(m_RefJobSeqArray[m_Map2[PS]], m_SparkSeqArray[PS]);
		}
		CheckSparks(m_SparkSeqArray[PS]);
		GetSpan(m_RefJobSeqArray[m_Map2[PS]], m_SparkSeqArray[PS], m_ObjectArray2[PS], m_FitnessArray2[PS]);
		m_Age2[PS] = 0;

		m_solutions.push_back(Solution(m_ObjectArray2[PS], m_RefJobSeqArray[m_Map2[PS]], m_SparkSeqArray[PS]));
		m_AllSolObjects.push_back(m_ObjectArray2[PS]);

	}

}



void CCEA::LocalSearch_I(vector <int>& JobSeq, vector <int> SparkSeq, vector <double>& Objects)
{
	int H = 5;
	//���й����ľ������
	vector<vector<int>>CostMatrix(m_Jobs + 1);
	for (int j = 0; j < m_Jobs + 1; j++) {
		CostMatrix[j].resize(m_Jobs + 1);
	}
	GetCostMatrix(CostMatrix, SparkSeq);

	vector <int>TempJobSeq = JobSeq;
	vector<double>TemObjects = Objects;

	if (m_Jobs > H)
	{
		//���ֹ�������
		vector<int> PartialJobSeq;
		PartialJobSeq.clear();
		int RandPoint = rand() % (m_Jobs - H + 1);
		for (int j = RandPoint; j < RandPoint + H; j++) {
			PartialJobSeq.push_back(TempJobSeq[j]);
		}
		int len = PartialJobSeq.size() + 1;
		vector<vector<int>>PartialCostMatrix(len);
		for (int j = 0; j < len; j++) {
			PartialCostMatrix[j].resize(len);
		}

		//���ֹ������е�ͷ����β��
		int head, tail;
		if (RandPoint == 0) {
			head = -1;
		}
		else {
			head = TempJobSeq[RandPoint - 1];
		}
		if (RandPoint == m_Jobs - H) {
			tail = m_Jobs;
		}
		else {
			tail = TempJobSeq[RandPoint + H];
		}

		for (int i = 0; i < len; i++)PartialCostMatrix[i][i] = RAND_MAX;
		//����famseq�е�fam����head�ľ���
		for (int i = 1; i < len; i++) {
			if (head == -1) {
				PartialCostMatrix[0][i] = CostMatrix[0][PartialJobSeq[i - 1] + 1];
			}
			else {
				PartialCostMatrix[0][i] = CostMatrix[head + 1][PartialJobSeq[i - 1] + 1];
			}
		}
		//����famseq�е�fam���ص�head�ľ���
		for (int i = 1; i < len; i++) {
			if (tail == m_Jobs) {
				PartialCostMatrix[i][0] = CostMatrix[PartialJobSeq[i - 1] + 1][0];
			}
			else {
				PartialCostMatrix[i][0] = CostMatrix[PartialJobSeq[i - 1] + 1][tail + 1];
			}
		}
		//����famseq�е�һ��fam����һ��fam�ľ���
		for (int i = 0; i < len - 1; i++) {
			for (int j = 0; j < len - 1; j++) {
				if (i != j) {
					PartialCostMatrix[i + 1][j + 1] = CostMatrix[PartialJobSeq[i] + 1][PartialJobSeq[j] + 1];
				}
			}
		}

		vector<int>OptimalRing = ATSP(PartialCostMatrix);
		OptimalRing.erase(OptimalRing.begin());
		for (int i = 0; i < len - 1; i++)OptimalRing[i]--;
		int start = 0;
		for (int j = RandPoint; j < RandPoint + H; j++) {
			TempJobSeq[j] = PartialJobSeq[OptimalRing[start]];
			start++;
		}
		GetObjects(TempJobSeq, SparkSeq, TemObjects);

	}
	else {

		vector<int>OptimalRing = ATSP(CostMatrix);
		OptimalRing.erase(OptimalRing.begin());
		for (int i = 0; i < m_Jobs; i++)OptimalRing[i]--;
		TempJobSeq = OptimalRing;
		GetObjects(TempJobSeq, SparkSeq, TemObjects);

	}

	m_solutions.push_back(Solution(TemObjects, TempJobSeq, SparkSeq));
	m_AllSolObjects.push_back(TemObjects);

	if (TemObjects[0] < Objects[0])
	{
		JobSeq = TempJobSeq;
		Objects = TemObjects;

	}

}

void CCEA::LocalSearch_II(vector <int>& JobSeq, vector <int> SparkSeq, vector <double>& Objects)
{

	int H = 5;
	//���й����ľ������
	vector<vector<int>>CostMatrix(m_Jobs + 1);
	for (int j = 0; j < m_Jobs + 1; j++) {
		CostMatrix[j].resize(m_Jobs + 1);
	}
	GetCostMatrix(CostMatrix, SparkSeq);

	for (int i = 0; i < m_Jobs + 1; i++)
	{
		for (int j = 0; j < m_Jobs + 1; j++)
			cout << CostMatrix[i][j] << " ";
		cout << endl;
	}

	vector <int>TempJobSeq = JobSeq;
	vector<double>TemObjects = Objects;

	if (m_Jobs > H)
	{
		//���ֹ�������
		vector<int> PartialJobSeq;
		PartialJobSeq.clear();
		int RandPoint = rand() % (m_Jobs - H + 1);
		for (int j = RandPoint; j < RandPoint + H; j++) {
			PartialJobSeq.push_back(TempJobSeq[j]);
		}
		int len = PartialJobSeq.size() + 1;
		vector<vector<int>>PartialCostMatrix(len);
		for (int j = 0; j < len; j++) {
			PartialCostMatrix[j].resize(len);
		}

		//���ֹ������е�ͷ����β��
		int head, tail;
		if (RandPoint == 0) {
			head = -1;
		}
		else {
			head = TempJobSeq[RandPoint - 1];
		}
		if (RandPoint == m_Jobs - H) {
			tail = m_Jobs;
		}
		else {
			tail = TempJobSeq[RandPoint + H];
		}

		for (int i = 0; i < len; i++)PartialCostMatrix[i][i] = RAND_MAX;
		//����famseq�е�fam����head�ľ���
		for (int i = 1; i < len; i++) {
			if (head == -1) {
				PartialCostMatrix[0][i] = CostMatrix[0][PartialJobSeq[i - 1] + 1];
			}
			else {
				PartialCostMatrix[0][i] = CostMatrix[head + 1][PartialJobSeq[i - 1] + 1];
			}
		}
		//����famseq�е�fam���ص�head�ľ���
		for (int i = 1; i < len; i++) {
			if (tail == m_Jobs) {
				PartialCostMatrix[i][0] = CostMatrix[PartialJobSeq[i - 1] + 1][0];
			}
			else {
				PartialCostMatrix[i][0] = CostMatrix[PartialJobSeq[i - 1] + 1][tail + 1];
			}
		}
		//����famseq�е�һ��fam����һ��fam�ľ���
		for (int i = 0; i < len - 1; i++) {
			for (int j = 0; j < len - 1; j++) {
				if (i != j) {
					PartialCostMatrix[i + 1][j + 1] = CostMatrix[PartialJobSeq[i] + 1][PartialJobSeq[j] + 1];
				}
			}
		}

		vector<int>OptimalRing = ATSPT(PartialCostMatrix);
		OptimalRing.erase(OptimalRing.begin());
		for (int i = 0; i < len - 1; i++)OptimalRing[i]--;
		int start = 0;
		for (int j = RandPoint; j < RandPoint + H; j++) {
			TempJobSeq[j] = PartialJobSeq[OptimalRing[start]];
			start++;
		}
		GetObjects(TempJobSeq, SparkSeq, TemObjects);

	}
	else {

		vector<int>OptimalRing = ATSPT(CostMatrix);
		OptimalRing.erase(OptimalRing.begin());
		for (int i = 0; i < m_Jobs; i++)OptimalRing[i]--;
		TempJobSeq = OptimalRing;
		GetObjects(TempJobSeq, SparkSeq, TemObjects);

	}

	m_solutions.push_back(Solution(TemObjects, TempJobSeq, SparkSeq));
	m_AllSolObjects.push_back(TemObjects);

	if (TemObjects[1] < Objects[1])
	{
		JobSeq = TempJobSeq;
		Objects = TemObjects;

	}

}

void CCEA::GreedyInsert(vector <int>& JobSeq, vector <int> SparkSeq, vector <double>& Objects, double& fitness)
{
	int Pos, TempBestPos, TempBestFit;
	vector<double>TempBestObjects(3, 0);
	vector<int>TempJobSeq;

	for (int CurJob = 0; CurJob < m_Jobs; CurJob++) {
		TempJobSeq = JobSeq;
		FindJobPos(TempJobSeq, CurJob, Pos);
		TempJobSeq.erase(TempJobSeq.begin() + Pos);
		TempBestFit = FindBestPosToInsertJob_InSeq(TempJobSeq, SparkSeq, CurJob, TempBestPos, TempBestObjects);
		TempJobSeq.insert(TempJobSeq.begin() + TempBestPos, CurJob);

		m_solutions.push_back(Solution(TempBestObjects, TempJobSeq, SparkSeq));
		m_AllSolObjects.push_back(TempBestObjects);

		if (TempBestFit < fitness)
		{
			fitness = TempBestFit;
			JobSeq = TempJobSeq;
			Objects = TempBestObjects;

		}

	}
}

void CCEA::GreedySwap(vector <int>& JobSeq, vector <int> SparkSeq, vector <double>& Objects, double& fitness)
{

	int x = -1, y = -1;
	vector<double> TempObjects(3);
	double tempfit = 0;
	double MinFit = fitness;
	for (int i = 0; i < m_Jobs - 1; i++) {
		for (int j = i + 1; j < m_Jobs; j++) {
			vector <int> TemJobSeq = JobSeq;
			int Job = TemJobSeq[i];
			TemJobSeq[i] = TemJobSeq[j];
			TemJobSeq[j] = Job;
			GetSpan(TemJobSeq, SparkSeq, TempObjects, tempfit);

			m_solutions.push_back(Solution(TempObjects, TemJobSeq, SparkSeq));
			m_AllSolObjects.push_back(TempObjects);

			if (tempfit < MinFit) {
				MinFit = tempfit;
				x = i;
				y = j;
			}
		}
	}
	if (x != -1 && y != -1) {
		int Job = JobSeq[x];
		JobSeq[x] = JobSeq[y];
		JobSeq[y] = Job;
		GetSpan(JobSeq, SparkSeq, Objects, fitness);
	}

}

void CCEA::CCRandInsert(vector <int>& JobSeq, vector <int> SparkSeq, vector <double>& Objects, double& fitness)
{
	int Pos, TempBestPos;
	double TempBestFit;
	vector<double>TempBestObjects(3, 0);
	vector<int>TempJobSeq = JobSeq;

	Pos = rand() % m_Jobs;
	int CurJob = TempJobSeq[Pos];
	TempJobSeq.erase(TempJobSeq.begin() + Pos);
	TempBestFit = FindBestPosToInsertJob_InSeq(TempJobSeq, SparkSeq, CurJob, TempBestPos, TempBestObjects);
	TempJobSeq.insert(TempJobSeq.begin() + TempBestPos, CurJob);

	m_solutions.push_back(Solution(TempBestObjects, TempJobSeq, SparkSeq));
	m_AllSolObjects.push_back(TempBestObjects);
	if (TempBestFit < fitness)
	{
		fitness = TempBestFit;
		JobSeq = TempJobSeq;
		Objects = TempBestObjects;

	}

}

void CCEA::CCRandSwap(vector <int>& JobSeq, vector <int> SparkSeq, vector <double>& Objects, double& fitness)
{

	vector <int> TemJobSeq = JobSeq;
	vector<double> TempObjects(3);
	double tempfit = 0;
	int Pos1, Pos2;
	do {
		Pos1 = rand() % TemJobSeq.size();
		Pos2 = rand() % TemJobSeq.size();
	} while (Pos1 == Pos2);
	int Job = TemJobSeq[Pos1];
	TemJobSeq[Pos1] = TemJobSeq[Pos2];
	TemJobSeq[Pos2] = Job;
	GetSpan(TemJobSeq, SparkSeq, TempObjects, tempfit);
	m_solutions.push_back(Solution(TempObjects, TemJobSeq, SparkSeq));
	m_AllSolObjects.push_back(TempObjects);
	if (tempfit < fitness) {
		fitness = tempfit;
		Objects = TempObjects;
		JobSeq = TemJobSeq;

	}

}


void CCEA::FLocalSearch_I(vector <int>& JobSeq, vector <int> SparkSeq, vector <double>& Objects, double& Fitness)
{
	int H = m_H;
	//���й����ľ������
	vector<vector<int>>CostMatrix(m_Jobs + 1);
	for (int j = 0; j < m_Jobs + 1; j++) {
		CostMatrix[j].resize(m_Jobs + 1);
	}
	GetCostMatrix(CostMatrix, SparkSeq);

	vector <int>TempJobSeq = JobSeq;
	vector<double>TemObjects = Objects;
	double TempFitness = Fitness;

	if (m_Jobs > H)
	{
		//���ֹ�������
		vector<int> PartialJobSeq;
		PartialJobSeq.clear();
		//srand((unsigned)time(NULL));
		/*int RandPoint = rand() % (m_Jobs - H + 1);*/
		/*random_device rd;
		mt19937 gen(rd());
		uniform_int_distribution<>dis(0, m_Jobs - H);
		int RandPoint = dis(gen);*/
		int RandPoint = rand() % (m_Jobs - H + 1);
		for (int j = RandPoint; j < RandPoint + H; j++) {
			PartialJobSeq.push_back(TempJobSeq[j]);
		}
		int len = PartialJobSeq.size() + 1;
		vector<vector<int>>PartialCostMatrix(len);
		for (int j = 0; j < len; j++) {
			PartialCostMatrix[j].resize(len);
		}

		//���ֹ������е�ͷ����β��
		int head, tail;
		if (RandPoint == 0) {
			head = -1;
		}
		else {
			head = TempJobSeq[RandPoint - 1];
		}
		if (RandPoint == m_Jobs - H) {
			tail = m_Jobs;
		}
		else {
			tail = TempJobSeq[RandPoint + H];
		}

		for (int i = 0; i < len; i++)PartialCostMatrix[i][i] = RAND_MAX;
		//����famseq�е�fam����head�ľ���
		for (int i = 1; i < len; i++) {
			if (head == -1) {
				PartialCostMatrix[0][i] = CostMatrix[0][PartialJobSeq[i - 1] + 1];
			}
			else {
				PartialCostMatrix[0][i] = CostMatrix[head + 1][PartialJobSeq[i - 1] + 1];
			}
		}
		//����famseq�е�fam���ص�head�ľ���
		for (int i = 1; i < len; i++) {
			if (tail == m_Jobs) {
				PartialCostMatrix[i][0] = CostMatrix[PartialJobSeq[i - 1] + 1][0];
			}
			else {
				PartialCostMatrix[i][0] = CostMatrix[PartialJobSeq[i - 1] + 1][tail + 1];
			}
		}
		//����famseq�е�һ��fam����һ��fam�ľ���
		for (int i = 0; i < len - 1; i++) {
			for (int j = 0; j < len - 1; j++) {
				if (i != j) {
					PartialCostMatrix[i + 1][j + 1] = CostMatrix[PartialJobSeq[i] + 1][PartialJobSeq[j] + 1];
				}
			}
		}

		vector<int>OptimalRing = ATSP(PartialCostMatrix);
		OptimalRing.erase(OptimalRing.begin());
		for (int i = 0; i < len - 1; i++)OptimalRing[i]--;
		int start = 0;
		for (int j = RandPoint; j < RandPoint + H; j++) {
			TempJobSeq[j] = PartialJobSeq[OptimalRing[start]];
			start++;
		}
		GetSpan(TempJobSeq, SparkSeq, TemObjects, TempFitness);

	}
	else {

		vector<int>OptimalRing = ATSP(CostMatrix);
		OptimalRing.erase(OptimalRing.begin());
		for (int i = 0; i < m_Jobs; i++)OptimalRing[i]--;
		TempJobSeq = OptimalRing;
		GetSpan(TempJobSeq, SparkSeq, TemObjects, TempFitness);

	}

	m_solutions.push_back(Solution(TemObjects, TempJobSeq, SparkSeq));
	m_AllSolObjects.push_back(TemObjects);

	if (TempFitness < Fitness)
	{
		JobSeq = TempJobSeq;
		Objects = TemObjects;
		Fitness = TempFitness;

	}

}

void CCEA::FLocalSearch_II(vector <int>& JobSeq, vector <int> SparkSeq, vector <double>& Objects, double& Fitness)
{

	int H = m_H;
	//���й����ľ������
	vector<vector<int>>CostMatrix(m_Jobs + 1);
	for (int j = 0; j < m_Jobs + 1; j++) {
		CostMatrix[j].resize(m_Jobs + 1);
	}
	GetCostMatrix(CostMatrix, SparkSeq);

	//for (int i = 0; i < m_Jobs + 1; i++)
	//{
	//	for (int j = 0; j < m_Jobs + 1; j++)
	//		cout << CostMatrix[i][j] << " ";
	//	cout << endl;
	//}

	vector <int>TempJobSeq = JobSeq;
	vector<double>TemObjects = Objects;
	double TempFitness = Fitness;
	if (m_Jobs > H)
	{
		//���ֹ�������
		vector<int> PartialJobSeq;
		PartialJobSeq.clear();
		//srand((unsigned)time(NULL));

		/*random_device rd;
		mt19937 gen(rd());
		uniform_int_distribution<>dis(0, m_Jobs - H);
		int RandPoint = dis(gen);*/



		int RandPoint = rand() % (m_Jobs - H + 1);
		for (int j = RandPoint; j < RandPoint + H; j++) {
			PartialJobSeq.push_back(TempJobSeq[j]);
		}
		int len = PartialJobSeq.size() + 1;
		vector<vector<int>>PartialCostMatrix(len);
		for (int j = 0; j < len; j++) {
			PartialCostMatrix[j].resize(len);
		}

		//���ֹ������е�ͷ����β��
		int head, tail;
		if (RandPoint == 0) {
			head = -1;
		}
		else {
			head = TempJobSeq[RandPoint - 1];
		}
		if (RandPoint == m_Jobs - H) {
			tail = m_Jobs;
		}
		else {
			tail = TempJobSeq[RandPoint + H];
		}

		for (int i = 0; i < len; i++)PartialCostMatrix[i][i] = RAND_MAX;
		//����famseq�е�fam����head�ľ���
		for (int i = 1; i < len; i++) {
			if (head == -1) {
				PartialCostMatrix[0][i] = CostMatrix[0][PartialJobSeq[i - 1] + 1];
			}
			else {
				PartialCostMatrix[0][i] = CostMatrix[head + 1][PartialJobSeq[i - 1] + 1];
			}
		}
		//����famseq�е�fam���ص�head�ľ���
		for (int i = 1; i < len; i++) {
			if (tail == m_Jobs) {
				PartialCostMatrix[i][0] = CostMatrix[PartialJobSeq[i - 1] + 1][0];
			}
			else {
				PartialCostMatrix[i][0] = CostMatrix[PartialJobSeq[i - 1] + 1][tail + 1];
			}
		}
		//����famseq�е�һ��fam����һ��fam�ľ���
		for (int i = 0; i < len - 1; i++) {
			for (int j = 0; j < len - 1; j++) {
				if (i != j) {
					PartialCostMatrix[i + 1][j + 1] = CostMatrix[PartialJobSeq[i] + 1][PartialJobSeq[j] + 1];
				}
			}
		}

		vector<int>OptimalRing = ATSPT(PartialCostMatrix);
		OptimalRing.erase(OptimalRing.begin());
		for (int i = 0; i < len - 1; i++)OptimalRing[i]--;
		int start = 0;
		for (int j = RandPoint; j < RandPoint + H; j++) {
			TempJobSeq[j] = PartialJobSeq[OptimalRing[start]];
			start++;
		}
		GetSpan(TempJobSeq, SparkSeq, TemObjects, TempFitness);

	}
	else {

		vector<int>OptimalRing = ATSPT(CostMatrix);
		OptimalRing.erase(OptimalRing.begin());
		for (int i = 0; i < m_Jobs; i++)OptimalRing[i]--;
		TempJobSeq = OptimalRing;
		GetSpan(TempJobSeq, SparkSeq, TemObjects, TempFitness);

	}

	m_solutions.push_back(Solution(TemObjects, TempJobSeq, SparkSeq));
	m_AllSolObjects.push_back(TemObjects);

	if (TempFitness < Fitness)
	{
		JobSeq = TempJobSeq;
		Objects = TemObjects;
		Fitness = TempFitness;

	}

}

void CCEA::FLocalSearch_III(vector <int>& JobSeq, vector <int> SparkSeq, vector <double>& Objects, double& Fitness)
{
	int H = m_H;
	//���й����ľ������
	vector<vector<int>>CostMatrix(m_Jobs + 1);
	for (int j = 0; j < m_Jobs + 1; j++) {
		CostMatrix[j].resize(m_Jobs + 1);
	}
	GetCostMatrix(CostMatrix, SparkSeq);
	vector <int>TempJobSeq = JobSeq;
	vector<double>TemObjects = Objects;
	double TempFitness = Fitness;

	if (m_Jobs > H)
	{

		//���ֹ�������
		vector<int> PartialJobSeq;
		PartialJobSeq.clear();
		//srand((unsigned)time(NULL));
		/*int RandPoint = rand() % (m_Jobs - H + 1);*/
		/*random_device rd;
		mt19937 gen(rd());
		uniform_int_distribution<>dis(0, m_Jobs - H);
		int RandPoint = dis(gen);*/
		int RandPoint = m_Jobs - H;
		for (int j = RandPoint; j < RandPoint + H; j++) {
			PartialJobSeq.push_back(TempJobSeq[j]);
		}
		int len = PartialJobSeq.size() + 1;
		vector<vector<int>>PartialCostMatrix(len);
		for (int j = 0; j < len; j++) {
			PartialCostMatrix[j].resize(len);
		}

		//���ֹ������е�ͷ����β��
		int head, tail;
		if (RandPoint == 0) {
			head = -1;
		}
		else {
			head = TempJobSeq[RandPoint - 1];
		}
		if (RandPoint == m_Jobs - H) {
			tail = m_Jobs;
		}
		else {
			tail = TempJobSeq[RandPoint + H];
		}

		for (int i = 0; i < len; i++)PartialCostMatrix[i][i] = RAND_MAX;
		//����famseq�е�fam����head�ľ���
		for (int i = 1; i < len; i++) {
			if (head == -1) {
				PartialCostMatrix[0][i] = CostMatrix[0][PartialJobSeq[i - 1] + 1];
			}
			else {
				PartialCostMatrix[0][i] = CostMatrix[head + 1][PartialJobSeq[i - 1] + 1];
			}
		}
		//����famseq�е�fam���ص�head�ľ���
		for (int i = 1; i < len; i++) {
			if (tail == m_Jobs) {
				PartialCostMatrix[i][0] = CostMatrix[PartialJobSeq[i - 1] + 1][0];
			}
			else {
				PartialCostMatrix[i][0] = CostMatrix[PartialJobSeq[i - 1] + 1][tail + 1];
			}
		}
		//����famseq�е�һ��fam����һ��fam�ľ���
		for (int i = 0; i < len - 1; i++) {
			for (int j = 0; j < len - 1; j++) {
				if (i != j) {
					PartialCostMatrix[i + 1][j + 1] = CostMatrix[PartialJobSeq[i] + 1][PartialJobSeq[j] + 1];
				}
			}
		}

		vector<int>OptimalRing = ATSPCandT(PartialCostMatrix);
		OptimalRing.erase(OptimalRing.begin());
		for (int i = 0; i < len - 1; i++)OptimalRing[i]--;
		int start = 0;
		for (int j = RandPoint; j < RandPoint + H; j++) {
			TempJobSeq[j] = PartialJobSeq[OptimalRing[start]];
			start++;
		}
		GetSpan(TempJobSeq, SparkSeq, TemObjects, TempFitness);
	}
	else {

		vector<int>OptimalRing = ATSPCandT(CostMatrix);
		OptimalRing.erase(OptimalRing.begin());
		for (int i = 0; i < m_Jobs; i++)OptimalRing[i]--;
		TempJobSeq = OptimalRing;
		GetSpan(TempJobSeq, SparkSeq, TemObjects, TempFitness);
	
	}
	
	m_solutions.push_back(Solution(TemObjects, TempJobSeq, SparkSeq));
	m_AllSolObjects.push_back(TemObjects);

	if (TempFitness < Fitness)
	{
		JobSeq = TempJobSeq;
		Objects = TemObjects;
		Fitness = TempFitness;

	}
}

void CCEA::SaveNS(int CPUFactor, int ins, int Rep)
{

	/*ofstream ofile;
	ostringstream ostr;*/

	ofstream ofile_I;
	ostringstream ostr_I;

	/*ostr.str("");
	ostr.clear();*/

	ostr_I.str("");
	ostr_I.clear();

	/*ostr << ".\\Results\\CCEALocl_" << CPUFactor << "_" << ins << "_" << Rep + 1 << ".txt";
	ofile.open(ostr.str());

	if (!ofile.is_open()) {
		std::cerr << "Failed to open file: " << ostr.str() << std::endl;

	}*/

	ostr_I << ".\\Results\\CCEALT_" << CPUFactor << "_" << ins << "_" << Rep + 1 << ".txt";
	ofile_I.open(ostr_I.str());

	if (!ofile_I.is_open()) {
		std::cerr << "Failed to open file: " << ostr_I.str() << std::endl;

	}

	vector<double>objects(3, 0), tmepobjects(3, 0);
	vector<int>seq1, seq2;
	//cout << "Non-dominated solutions: \n";
	for (const auto& sol : m_nonDominatedSolutions) {

		objects = sol.objectives;
		seq1 = sol.jobseq;
		seq2 = sol.sparkseq;
		GetObjects(seq1, seq2, tmepobjects);
		if ((tmepobjects[0] == objects[0]) && (tmepobjects[1] == objects[1]) && (tmepobjects[2] == objects[2])) {

			cout << "��ȷ" << endl;
		}
		else {
			cout << "����" << endl;
		}
		//for (int i : seq1) {
		//	//cout << i << " ";
		//	ofile << i << " ";
		//}
		////cout << "\t";
		//ofile << "\t";

		//for (int i : seq2) {
		//	//cout << i << " ";
		//	ofile << i << " ";
		//}
		////cout << "\t";
		//ofile << "\t";

		//cout << "(" << objects[0] << ", " << objects[1] << ", " << objects[2] << ")\n";
		/*ofile << "(" << objects[0] << ", " << objects[1] << ", " << objects[2] << ")\n";*/
		ofile_I << objects[0] << " " << objects[1] << " " << objects[2] << "\n";
	}
	/*ofile.flush();*/
	ofile_I.flush();


	/*file.close();*/
	ofile_I.close();

}





//20190519-
void CCEA::Evolution()//Evolution2 without ReInitPop;
{
	/*vector<int>jobseq={ 3, 2, 1, 0, 4};
	vector<int>sparkseq = { 2, 8, 7, 1, 3 };
	vector<double>objects(3, 0);
	GetObjects(jobseq, sparkseq, objects);*/
	m_RecordSpan.clear();
	int Record = 1;

	vector<int>JobSeq(m_Jobs), SparkSeq(m_Jobs);
	vector<double>Objects(3, 0);
	double fitness = 0;
	while (true)
	{
		//----------Evolution for job Populaiton------------
		for (int PS = 0; PS < m_PS1; PS++)
		{

			JobSeq = m_JobSeqArray[PS];
			int Map1 = rand() % m_RefSize;
			GetSpan(JobSeq, m_RefSparkSeqArray[Map1], Objects, fitness);
			m_solutions.push_back(Solution(Objects, JobSeq, m_RefSparkSeqArray[Map1]));
			m_AllSolObjects.push_back(Objects);
			CCRandInsert(JobSeq, m_RefSparkSeqArray[Map1], Objects, fitness);
			CCRandSwap(JobSeq, m_RefSparkSeqArray[Map1], Objects, fitness);
			/*double rr = double(rand()) / RAND_MAX;
			if (rr < 0.1) {
				m_H = 4;
				FLocalSearch_III(JobSeq, m_RefSparkSeqArray[Map1], Objects, fitness);
			}	*/		
			if (((!m_bFlag2[m_Map1[PS]]) && (fitness < m_FitnessArray1[PS])) || (m_bFlag2[m_Map1[PS]]))
			{
				m_FitnessArray1[PS] = fitness;
				m_ObjectArray1[PS] = Objects;
				m_JobSeqArray[PS] = JobSeq;
				m_Map1[PS] = Map1;
				m_Age1[PS] = 0;
			}
			//Update RefSet;
			if (fitness < m_RefFitnessArray[Map1])
			{
				m_RefFitnessArray[Map1] = fitness;
				m_RefObjectArray[Map1] = Objects;
				m_RefJobSeqArray[Map1] = JobSeq;
				m_bFlag1[Map1] = true;
			}
			m_Age1[PS]++;
		}


		//Reset m_bFlag2; 
		for (int PS = 0; PS < m_RefSize; PS++)
			m_bFlag2[PS] = false;

		//------------Evolution for spark populaiton -----------
		for (int PS = 0; PS < m_PS2; PS++)
		{
			SparkSeq = m_SparkSeqArray[PS];
			int Map2 = rand() % m_RefSize;//form a solution by randomly selecting a ReFacFamseq	
			double r = double(rand()) / RAND_MAX;
			if (r < 0.5)
				RandAssignSpark(m_RefJobSeqArray[Map2], SparkSeq);
			else
				AlignmentSpark(m_RefJobSeqArray[Map2], SparkSeq);
			CheckSparks(SparkSeq);

			GetSpan(m_RefJobSeqArray[Map2], SparkSeq, Objects, fitness);
			m_solutions.push_back(Solution(Objects, m_RefJobSeqArray[Map2], SparkSeq));
			m_AllSolObjects.push_back(Objects);
			//1: The original Maping Reference FamSeq is not changed; 2. Changed. reset corresponding relations
			if (((!m_bFlag1[m_Map2[PS]]) && (fitness < m_FitnessArray2[PS])) || (m_bFlag1[m_Map1[PS]]))//Update solution
			{
				m_FitnessArray2[PS] = fitness;
				m_ObjectArray2[PS] = Objects;
				m_SparkSeqArray[PS] = SparkSeq;
				m_Map2[PS] = Map2;
				m_Age2[PS] = 0;
			}
			m_Age2[PS]++;

			//Update RefSet;
			if (fitness < m_RefFitnessArray[Map2])
			{
				m_RefFitnessArray[Map2] = fitness;
				m_RefObjectArray[Map2] = Objects;
				m_RefSparkSeqArray[Map2] = SparkSeq;
				m_bFlag2[Map2] = true;
			}
			m_Age2[PS]++;

		}
		//Reset m_bFlag1;
		for (int PS = 0; PS < m_RefSize; PS++)
			m_bFlag1[PS] = false;

		//ReInitPop();

		long CurTime = GetElapsedProcessTime();
		long ElapsedTime = CurTime - m_InitTime;
		if (ElapsedTime >= m_TimeLimit) break;

		/*if ((ElapsedTime >= m_TimeLimit * 0.6)&&(m_Jobs>5)) {*/
		/*if (ElapsedTime >= m_TimeLimit * 0.8) {*/
			//�Բο������оֲ�����
		/*	double min_RefFitness = RAND_MAX;
			int min_Index;
			for (int PS = 0; PS < m_RefSize; PS++)
			{
				if (m_RefFitnessArray[PS] < min_RefFitness)
				{
					min_RefFitness = m_RefFitnessArray[PS];
					min_Index = PS;
				}
			}*/
			//int min_Index = rand() % m_RefSize;
			//JobSeq = m_RefJobSeqArray[min_Index];
			//SparkSeq = m_RefSparkSeqArray[min_Index];
			//Objects = m_RefObjectArray[min_Index];
			//fitness = m_RefFitnessArray[min_Index];
			//double min_RefFitness = fitness;
			//
			//RandAssignSpark(JobSeq, SparkSeq);			
			//CheckSparks(SparkSeq);
			//GetSpan(JobSeq, SparkSeq, Objects, fitness);

			//m_H = 5;
			///*	FLocalSearch_I(JobSeq, SparkSeq, Objects, fitness);
			//	FLocalSearch_II(JobSeq, SparkSeq, Objects, fitness);*/
			//FLocalSearch_III(JobSeq, SparkSeq, Objects, fitness);
			//if (fitness < min_RefFitness)
			//{
			//	m_RefJobSeqArray[min_Index] = JobSeq;
			//	m_RefSparkSeqArray[min_Index] = SparkSeq;
			//	m_RefObjectArray[min_Index] = Objects;
			//	m_RefFitnessArray[min_Index] = fitness;
			//	m_bFlag1[min_Index] = true;
			//	m_bFlag2[min_Index] = true;
			//}
		/*}*/

	}

	vector<int>indexs = removeDuplicateRows(m_AllSolObjects);
	for (int i = 0; i < indexs.size(); i++)
	{
		m_uniquesolutions.push_back(m_solutions[indexs[i]]);
	}
	m_nonDominatedSolutions = findNonDominatedSolutions(m_uniquesolutions);

}





void CCEA::RunEvolution_OneConf(int CPUFactor, int Reps) //the same as Evolution2 except only one Reference, 
{

	int RefSize = 5;
	int PS1 = 10;
	int PS2 = 10;
	int AgeLimit = 5;
	int DesLen = 4;
	//double Rate = 1.0;
	int Instances = 100;
	vector<vector<int>> RefPoints;
	RefPoints.clear();

	//ofstream ofile;
	//ostringstream ostr;
	//ostr.str("");
	//ostr.clear();
	////ostr << ".\\Results\\û�м�ֵ�����Ĳο���.txt";
	//ostr << "��������.txt";
	//ofile.open(ostr.str());


	for (int ins = 1; ins <= Instances; ins++)
	{
		ReadInstance(ins);
		/*ofile << m_Bays << " "<< m_Rows << " "<< m_Jobs<< " "<< ins<<endl;*/


		for (int Rep = 0; Rep < Reps; Rep++) {
			m_solutions.clear();
			m_uniquesolutions.clear();
			m_AllSolObjects.clear();
			m_nonDominatedSolutions.clear();


			srand(100 * ins + Rep);
			long StartTime_Ins = ::GetElapsedProcessTime();
			SetParameters(RefSize, PS1, PS2, AgeLimit, DesLen, CPUFactor * m_Bays * m_Rows * m_Jobs);
			RefPointEst();
			//RefPoints.push_back(m_RefPoints);
			InitPop();
			Evolution();
			SaveNS(CPUFactor, ins, Rep);
		}

	}
	//SaveRefPoint(RefPoints);
	/*ofile.close();*/
}

void CCEA::SaveRefPoint(vector<vector<int>> RefPoints) {

	ofstream ofile;
	ostringstream ostr;
	ostr.str("");
	ostr.clear();
	//ostr << ".\\Results\\û�м�ֵ�����Ĳο���.txt";
	ostr << ".\\Results\\�ο���.txt";
	ofile.open(ostr.str());
	for (int i = 0; i < RefPoints.size(); i++) {
		for (int j = 0; j < 3; j++) {
			ofile << RefPoints[i][j] << " ";
		}
		ofile << endl;
	}
	ofile.close();
}


