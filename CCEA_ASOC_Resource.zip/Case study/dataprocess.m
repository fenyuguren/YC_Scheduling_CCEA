% 清除环境变量和命令行
clear; clc;

% 1. 设置文件路径和读取Excel数据
% 请确保 'CaseStudy_Data_5.xlsx' 和本脚本在同一目录下
filename = 'CaseStudy_Data.xlsx'; 
data = readtable(filename, 'PreserveVariableNames', true);

% 2. 提取基础参数
num_jobs = height(data);

% 提取坐标信息 (假设 Yard Location 格式如 A16252: A为堆场, 16为Bay, 2为Row等)
yard_locations = data.("Yard Location");
bays = zeros(num_jobs, 1);
rows = zeros(num_jobs, 1);
job_types_char = strings(num_jobs, 1);

for i = 1:num_jobs
    loc_str = char(yard_locations{i});
    % 提取 Bay (第2和第3个字符)
    bays(i) = str2double(loc_str(2:3));
    
    % 提取 Row (真正的列号在第5个字符)
    row_char = loc_str(5); 
    rows(i) = str2double(row_char);
   
    
    % 提取作业类型
    job_type_str = char(data.("Job Type"){i});
    if contains(job_type_str, 'S') || contains(job_type_str, 'Stacking')
        job_types_char(i) = 's';
    else
        job_types_char(i) = 'u';
    end
end

% 计算最大 Bay 和 Row
max_bay = max(bays);
max_row = max(rows);

% 3. 处理 AGV 到达时间 (相对分钟数)
% 基准时间设定为 13:00:00
time_format = 'HH:mm:ss';
t0_datetime = datetime('13:00:00', 'InputFormat', time_format);

agv_ready_times = data.("AGV Ready Time");
relative_minutes = zeros(1, num_jobs);

for i = 1:num_jobs
    % 判断时间格式并转换
    if isdatetime(agv_ready_times(i))
        dt = agv_ready_times(i);
    elseif iscell(agv_ready_times(i))
        dt = datetime(agv_ready_times{i}, 'InputFormat', time_format);
    else
        dt = datetime(char(agv_ready_times(i)), 'InputFormat', time_format);
    end
    
    % 如果日期部分不一致，强制将日期设置为与 t0 相同
    dt.Year = t0_datetime.Year;
    dt.Month = t0_datetime.Month;
    dt.Day = t0_datetime.Day;
    
    % 计算时间差（秒）
    diff_sec = seconds(dt - t0_datetime);
    
    % 防止跨天情况（如果有时间早于13点的情况）
    if diff_sec < 0
        diff_sec = diff_sec + 24 * 3600;
    end
    
    % 转化为分钟并四舍五入
    relative_minutes(i) = round(diff_sec / 60);
end

% 4. 输出数据并写入 TXT 文件
output_txt_file = 'YC_CaseStudy.txt';
fileID = fopen(output_txt_file, 'w');

% 第一行：Max_Bay Max_Row Num_Jobs
fprintf(fileID, '%d %d %d\n', max_bay, max_row, num_jobs);
fprintf('%d %d %d\n', max_bay, max_row, num_jobs);

% 第二行：相对到达时间 (分钟)
fprintf(fileID, '%d ', relative_minutes);
fprintf(fileID, '\n');
disp(strjoin(string(relative_minutes), ' '));

% 第三行：作业类型序列 (s 或 u)
fprintf(fileID, '%s ', job_types_char);
fprintf(fileID, '\n');
disp(strjoin(job_types_char, ' '));

% 第四行及以后：坐标矩阵 (Row Bay)
for i = 1:num_jobs
    fprintf(fileID, '%d %d\n', rows(i), bays(i));
    fprintf('%d %d\n', rows(i), bays(i));
end

fclose(fileID);
disp(['Data extraction complete. The file has been saved as: ', output_txt_file]);