clc;
clear all;
format long g

for i=0:0
    data=[];
    for cishu=1:5
        PStr=sprintf('CCEALT_10_%s',int2str(i));
        file_name=[PStr,'_',int2str(cishu)];
        file=sprintf('Results\\%s.txt',file_name);
        data=[data;dlmread(file)];
    end
    objects=data(:,21:23);
    [uniobjects, ia, ic]=unique(objects,'rows');
    
    unique_pop_size=size(uniobjects,1);
    particle=CreateEmptyParticle(unique_pop_size);
    unique_data=data(ia,:);
    for j=1:unique_pop_size
        particle(j).Cost=unique_data(j,21:23);
        particle(j).Solution=unique_data(j,1:20);
        particle(j).Dominated=false;
    end
    particle=DetermineDomination(particle);
    rep=GetNonDominatedParticles(particle);
    npop_size=numel(rep);
    shujuchuli=zeros(npop_size,23);
    for m=1:npop_size
        shujuchuli(m,:)=[rep(m).Solution,rep(m).Cost];
    end
    shujuchuli(:,1:10)=shujuchuli(:,1:10)+1
    % file=sprintf('���ݴ�������ļ�\\%s.txt',PStr);
    % save(file, 'shujuchuli', '-ascii');
    xlswrite('CaseStudyResult.xlsx', shujuchuli);
end


